(() => {
const MODULE_RE = /(?<![\w$])define\(\s*(["'])((?:DS\/|[\w-]+!|[\w.-]+\/)[^"']+)\1\s*,\s*(?:\[([^\]]*)\]\s*,\s*)?(?:function\s*\(([^)]*)\)|\(([^)]*)\)\s*=>)?/g;
const ANON_RE = /(?<![\w$])define\(\s*(?:\[([^\]]*)\]\s*,\s*)?(?:function\s*\(([^)]*)\)|\(([^)]*)\)\s*=>)/;
const DEP_RE = /["']([^"']+)["']/g;
const FRAME_RE = /^\s*at (?:async )?(?:(.*?) \()?(.+?):(\d+):(\d+)\)?$/;
const PRIMARY_RE = /^ENOCh(?:g|ange)/i;
const FILE_KINDS = { js: 'js', mjs: 'js', html: 'html', htm: 'html', json: 'json', css: 'css' };
const FILE_NAME_MODES = {
  contains: (name, term) => name.includes(term),
  exact: (name, term) => name === term,
  start: (name, term) => name.startsWith(term),
  end: (name, term) => name.endsWith(term),
};
const MAX_MATCH = 200;
const WORD = '[\\w$]';
const MODE_PATTERNS = {
  contains: (q) => q,
  start: (q) => `(?<!${WORD})${q}`,
  end: (q) => `${q}(?!${WORD})`,
  word: (q) => `(?<!${WORD})${q}(?!${WORD})`,
};

function inferModuleId(url = '') {
  const m = stripQuery(url).match(/\/webapps\/([^/]+\/.+?)\.js$/i);
  return m ? `DS/${m[1]}` : null;
}

function buildModuleIndex(text, url = '') {
  const found = [...text.matchAll(MODULE_RE)].map((m) => {
    const rawParams = m[4] ?? m[5];
    return {
      id: m[2],
      start: m.index,
      deps: m[3] === undefined ? [] : [...m[3].matchAll(DEP_RE)].map((d) => d[1]),
      params: rawParams === undefined ? [] : rawParams.split(',').map((p) => p.trim()).filter(Boolean),
    };
  });
  if (!found.length) {
    const id = inferModuleId(url);
    const anon = id && text.match(ANON_RE);
    if (anon) {
      const rawParams = anon[2] ?? anon[3];
      return [{
        id,
        start: anon.index,
        end: text.length,
        deps: anon[1] === undefined ? [] : [...anon[1].matchAll(DEP_RE)].map((d) => d[1]),
        params: rawParams === undefined ? [] : rawParams.split(',').map((p) => p.trim()).filter(Boolean),
      }];
    }
  }
  return found.map((mod, i) => ({ ...mod, end: i + 1 < found.length ? found[i + 1].start : text.length }));
}

function floorIndex(sorted, value, get) {
  let lo = 0;
  let hi = sorted.length - 1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (get(sorted[mid]) <= value) lo = mid + 1;
    else hi = mid - 1;
  }
  return hi;
}

function findModule(modules, offset) {
  const mod = modules[floorIndex(modules, offset, (m) => m.start)];
  return mod && offset < mod.end ? mod : null;
}

function getLineStarts(text) {
  const starts = [0];
  for (let i = text.indexOf('\n'); i !== -1; i = text.indexOf('\n', i + 1)) starts.push(i + 1);
  return starts;
}

function toOffset(lineStarts, line, column) {
  return lineStarts[line - 1] + column - 1;
}

function toLineColumn(lineStarts, offset) {
  const i = floorIndex(lineStarts, offset, (s) => s);
  return { line: i + 1, column: offset - lineStarts[i] + 1 };
}

function parseStack(stack) {
  return stack
    .split('\n')
    .map((line) => line.match(FRAME_RE))
    .filter(Boolean)
    .map((m) => ({ fn: m[1] ?? '', url: m[2], line: Number(m[3]), column: Number(m[4]) }));
}

function escapeRe(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function stripPlugin(id) {
  return id.replace(/^[\w-]+!/, '');
}

function stripQuery(url) {
  return url.split(/[?#]/)[0];
}

function packageOf(url) {
  const clean = stripQuery(url);
  return clean.match(/\/webapps\/([^/]+)\//i)?.[1] ?? clean.match(/\/3dspace\/(?!webapps\/|common\/)([^/]+)\//i)?.[1] ?? null;
}

function isTargetUrl(url) {
  if (typeof url !== 'string' || !/\.js$/i.test(stripQuery(url))) return false;
  return PRIMARY_RE.test(packageOf(url) ?? '');
}

function fileKind(url, type = '') {
  const ext = stripQuery(url).match(/\.([a-z0-9]+)$/i)?.[1].toLowerCase();
  if (ext && FILE_KINDS[ext]) return FILE_KINDS[ext];
  return { script: 'js', document: 'html', stylesheet: 'css' }[type] ?? null;
}

function fileMatcher(raw, mode = 'contains') {
  const text = (raw ?? '').trim();
  if (!text) return { test: () => true };
  if (mode === 'regex') {
    try {
      const re = new RegExp(text, 'i');
      return { test: (name) => re.test(name) };
    } catch (e) {
      return { error: e.message };
    }
  }
  const terms = text
    .split(',')
    .map((t) => t.trim().toLowerCase())
    .filter(Boolean);
  const check = FILE_NAME_MODES[mode] ?? FILE_NAME_MODES.contains;
  return {
    test: (name) => {
      const full = name.toLowerCase();
      const base = full.replace(/\.[^.]+$/, '');
      return terms.some((t) => check(full, t) || check(base, t));
    },
  };
}

function createMatcher(query, { mode = 'contains', caseSensitive = false } = {}) {
  const q = escapeRe(query);
  const source = mode === 'regex' ? query : (MODE_PATTERNS[mode] ?? MODE_PATTERNS.contains)(q);
  const flags = caseSensitive ? '' : 'i';
  try {
    return { global: new RegExp(source, `g${flags}`), single: new RegExp(source, flags) };
  } catch (e) {
    return { error: e.message };
  }
}

function resolveFrames(bundles, frames) {
  const chain = [];
  for (const f of frames ?? []) {
    const b = bundles.find((x) => stripQuery(x.url) === stripQuery(f.url));
    const mod = b && findModule(b.modules, toOffset(b.lineStarts, f.line, f.column));
    if (mod && !chain.some((c) => c.module === mod.id)) chain.push({ module: mod.id, fn: f.fn, file: b.name, url: b.url, line: f.line, column: f.column });
  }
  return chain;
}

function searchInBundles(bundles, matcher, limit = 30) {
  const hits = [];
  for (const b of bundles) {
    if (hits.length >= limit) break;
    const file = b.name ?? stripQuery(b.url).split('/').at(-1);
    const kind = b.kind ?? fileKind(b.url);
    const lineStarts = b.lineStarts ?? getLineStarts(b.text);
    const re = new RegExp(matcher.global.source, matcher.global.flags);
    for (let found = re.exec(b.text); found && hits.length < limit; found = re.exec(b.text)) {
      const i = found.index;
      const length = found[0].length;
      if (!length) {
        re.lastIndex += 1;
        continue;
      }
      const loc = toLineColumn(lineStarts, i);
      const lineEnd = lineStarts[loc.line] ? lineStarts[loc.line] - 1 : b.text.length;
      const from = Math.max(lineStarts[loc.line - 1], i - 40);
      const to = Math.min(lineEnd, i + length + 60);
      const collapse = (s) => s.replace(/\s+/g, ' ');
      const before = collapse(b.text.slice(from, i)).trimStart();
      const after = collapse(b.text.slice(i + length, to)).trimEnd();
      const match = length > MAX_MATCH ? `${found[0].slice(0, MAX_MATCH)}…` : found[0];
      const mod = findModule(b.modules ?? [], i);
      hits.push({ module: mod?.id ?? file, inModule: Boolean(mod), file, kind, url: b.url, line: loc.line, column: loc.column, length, before, match, after, snippet: `${before}${match}${after}` });
    }
  }
  return hits;
}

const STATIC_RESOURCE_TYPES = new Set(['document', 'script', 'stylesheet', 'image', 'font', 'media', 'manifest', 'texttrack']);
const XHR_RESOURCE_TYPES = new Set(['xhr', 'fetch']);
const STATIC_EXT_RE = /\.(?:js|mjs|css|png|jpe?g|gif|svg|webp|ico|woff2?|ttf|eot|map|html?)($|[?#])/i;
const REGEX_TOKEN_RE = /^\/((?:[^/\\]|\\.)+)\/([imsuy]*)$/;

function stripHash(url) {
  return String(url ?? '').split('#')[0];
}

function parseUrlParts(url) {
  const raw = String(url ?? '');
  try {
    const u = new URL(raw, 'http://localhost');
    const cleanPath = u.pathname || '/';
    const segment = cleanPath.split('/').filter(Boolean).at(-1);
    const name = segment ? `${segment}${u.search}` : `${u.host || raw}${u.search}`;
    return { name, path: cleanPath, host: u.host, search: u.search };
  } catch {
    const noHash = stripHash(raw);
    const qIndex = noHash.indexOf('?');
    const base = qIndex === -1 ? noHash : noHash.slice(0, qIndex);
    const search = qIndex === -1 ? '' : noHash.slice(qIndex);
    const segment = base.split('/').filter(Boolean).at(-1) || base || raw;
    return { name: `${segment}${search}`, path: base, host: '', search };
  }
}

function parseQueryParams(url) {
  try {
    const u = new URL(String(url ?? ''), 'http://localhost');
    return [...u.searchParams.entries()].map(([key, value]) => ({ key, value }));
  } catch {
    return [];
  }
}

function isXhrOrFetchResource(item) {
  if (!item) return false;
  if (item.fromPageHook || XHR_RESOURCE_TYPES.has(item.resourceType)) return true;
  if (STATIC_RESOURCE_TYPES.has(item.resourceType)) return false;
  const headers = item.requestHeaders ?? [];
  if (headers.some((h) => h.name?.toLowerCase() === 'x-requested-with' && h.value?.toLowerCase() === 'xmlhttprequest')) return true;
  return Boolean((item.method && item.method !== 'GET') || !STATIC_EXT_RE.test(item.url ?? ''));
}

function splitFilterPatterns(raw) {
  return String(raw ?? '')
    .split(/[,\n]/)
    .map((s) => s.trim())
    .filter(Boolean);
}

function matchesPattern(text, pattern) {
  const regexMatch = pattern.match(REGEX_TOKEN_RE);
  if (regexMatch) {
    try {
      return new RegExp(regexMatch[1], regexMatch[2].replace(/[gy]/g, '') || 'i').test(text);
    } catch {
      return text.toLowerCase().includes(pattern.toLowerCase());
    }
  }
  return text.toLowerCase().includes(pattern.toLowerCase());
}

function matchesStatusGroup(item, statusGroup) {
  if (!statusGroup || statusGroup === 'ALL') return true;
  if (statusGroup === 'pending') return Boolean(item.isPending);
  if (item.isPending) return false;
  const code = Number(item.status);
  if (statusGroup === '2xx') return code >= 200 && code < 300;
  if (statusGroup === '3xx') return code >= 300 && code < 400;
  if (statusGroup === 'error') return item.state === 'error' || item.state === 'aborted' || code === 0 || code >= 400;
  return true;
}

function matchesNetworkFilter(item, filter = {}) {
  if (filter.onlyXhr && !isXhrOrFetchResource(item)) return false;
  if (filter.method && filter.method !== 'ALL' && item.method !== filter.method) return false;
  if (!matchesStatusGroup(item, filter.statusGroup)) return false;
  const target = `${item.url ?? ''}\n${item.name ?? ''}\n${item.path ?? ''}\n${item.initiatorText ?? ''}`;
  const includeTokens = splitFilterPatterns(filter.include);
  if (includeTokens.length && !includeTokens.some((token) => matchesPattern(target, token))) return false;
  const excludeTokens = splitFilterPatterns(filter.exclude);
  if (excludeTokens.some((token) => matchesPattern(target, token))) return false;
  const query = String(filter.query ?? '').trim();
  if (!query) return true;
  const bodyTarget = filter.searchBody ? `${target}\n${item.postDataText ?? ''}\n${item.responseText ?? ''}` : target;
  return query.split(/\s+/).every((term) => {
    const negated = term.length > 1 && term.startsWith('-');
    const token = negated ? term.slice(1) : term;
    const hit = matchesPattern(bodyTarget, token);
    return negated ? !hit : hit;
  });
}

function closestMatch(list, incoming, eligible) {
  const cleanUrl = stripHash(incoming.url);
  let best = -1;
  let bestScore = null;
  list.forEach((item, i) => {
    if (item.method !== incoming.method || stripHash(item.url) !== cleanUrl) return;
    const gap = Math.abs((item.startedAt ?? 0) - (incoming.startedAt ?? 0));
    if (!eligible(item, gap)) return;
    const score = [incoming.postDataText != null && item.postDataText === incoming.postDataText ? 0 : 1, gap];
    if (!bestScore || score[0] < bestScore[0] || (score[0] === bestScore[0] && score[1] < bestScore[1])) {
      best = i;
      bestScore = score;
    }
  });
  return best;
}

function findMatchingNetworkIndex(list, incoming, toleranceMs = 10000) {
  if (incoming.source === 'har') {
    return closestMatch(list, incoming, (item, gap) => !item.harMatched && (item.isPending || gap <= toleranceMs));
  }
  if (incoming.source === 'page') {
    const samePageIdx = list.findIndex((item) => item.pageId === incoming.pageId);
    if (samePageIdx !== -1) return samePageIdx;
    return closestMatch(list, incoming, (item, gap) => item.harMatched && !item.pageMatched && gap <= toleranceMs);
  }
  return -1;
}

const CDP_LEVELS = { error: 'error', assert: 'error', warning: 'warn', info: 'info', debug: 'debug', verbose: 'debug' };
const PREVIEW_SUBTYPES = new Set(['array', 'map', 'set']);

const isPageFrame = (f) => !f.url.startsWith('chrome-extension://');

function levelOf(type) {
  return CDP_LEVELS[type] ?? 'log';
}

function cdpFrames(stackTrace) {
  return (stackTrace?.callFrames ?? []).filter(isPageFrame).map((f) => ({ fn: f.functionName ?? '', url: f.url, line: f.lineNumber + 1, column: f.columnNumber + 1 }));
}

function errorFrames(description) {
  return parseStack(String(description ?? '')).filter(isPageFrame);
}

function functionName(source) {
  const name = String(source ?? '').match(/^(?:async\s+)?(?:function\s*\*?\s*|class\s+)?([\w$]+)\s*[({]/)?.[1];
  return name && name !== 'function' && name !== 'async' ? name : 'anonymous';
}

function previewItem(p) {
  if (p.type === 'string') return JSON.stringify(p.value);
  if (p.type === 'function') return 'ƒ';
  if (p.type !== 'object') return p.value;
  if (p.subtype === 'null') return 'null';
  return p.subtype ? p.value : '{…}';
}

function previewText(p) {
  if (p.type !== 'object') return p.type === 'string' ? JSON.stringify(p.description) : p.description;
  const more = p.overflow ? ', …' : '';
  if (p.entries) return `${p.description} {${p.entries.map((e) => (e.key ? `${previewText(e.key)} => ${previewText(e.value)}` : previewText(e.value))).join(', ')}${more}}`;
  if (p.subtype === 'array') return `[${p.properties.map(previewItem).join(', ')}${more}]`;
  const prefix = p.description && p.description !== 'Object' ? `${p.description} ` : '';
  return `${prefix}{${p.properties.map((x) => `${x.name}: ${previewItem(x)}`).join(', ')}${more}}`;
}

function remoteText(obj) {
  if (!obj) return 'undefined';
  if (obj.type === 'string') return obj.value;
  if (obj.type === 'undefined') return 'undefined';
  if (obj.type === 'function') return `ƒ ${functionName(obj.description)}()`;
  if (obj.type !== 'object') return obj.unserializableValue ?? obj.description ?? String(obj.value);
  if (obj.subtype === 'null') return 'null';
  if (obj.subtype === 'error') return String(obj.description ?? 'Error').split('\n')[0];
  if (obj.subtype === 'node') return `<${obj.description}>`;
  return obj.preview && (!obj.subtype || PREVIEW_SUBTYPES.has(obj.subtype)) ? previewText(obj.preview) : obj.description ?? 'Object';
}

function formatLogArgs(args) {
  const rest = [...args];
  const head = [];
  if (rest[0]?.type === 'string' && rest.length > 1 && /%[sdifoOc]/.test(rest[0].value)) {
    const fmt = rest.shift().value;
    head.push(
      fmt.replace(/%([sdifoOc%])/g, (m, k) => {
        if (k === '%') return '%';
        if (!rest.length) return m;
        const v = rest.shift();
        if (k === 'c') return '';
        if (k === 'd' || k === 'i') return String(parseInt(v.value ?? v.description, 10));
        if (k === 'f') return String(parseFloat(v.value ?? v.description));
        return remoteText(v);
      }),
    );
  }
  return [...head, ...rest.map(remoteText)].join(' ');
}

function exceptionText(details) {
  return details.exception ? `${details.text} ${remoteText(details.exception)}` : details.text;
}

function exceptionFrames(details) {
  const frames = cdpFrames(details.stackTrace);
  if (frames.length) return frames;
  const parsed = errorFrames(details.exception?.description);
  if (parsed.length || !details.url) return parsed;
  return [{ fn: '', url: details.url, line: details.lineNumber + 1, column: details.columnNumber + 1 }];
}

function moduleSelected(chain, selection) {
  return chain.some((c) => selection.some((s) => (s.endsWith('/') ? c.module.startsWith(s) : c.module === s)));
}

function filterLogs(entries, { modules = [], excludes = [], levels = [], browser = true, text = null } = {}) {
  const off = excludes.filter((x) => x instanceof RegExp || x.trim()).map((x) => (x instanceof RegExp ? x : new RegExp(escapeRe(x.trim()), 'i')));
  const counts = {};
  const shown = [];
  for (const e of entries) {
    if (modules.length ? !(e.chain && moduleSelected(e.chain, modules)) : !e.kind && off.some((re) => re.test(e.file))) continue;
    if (text && ![e.text, e.file, ...(e.chain ?? []).map((c) => c.module)].some((s) => s.search(text) >= 0)) continue;
    if (e.kind === 'browser') {
      if (levels.includes(e.level)) counts.browser = (counts.browser ?? 0) + 1;
      if (!browser) continue;
    }
    counts[e.level] = (counts[e.level] ?? 0) + 1;
    if (levels.includes(e.level)) shown.push(e);
  }
  return { shown, counts };
}

function groupLogs(entries, merge = true) {
  if (!merge) return entries.map((entry) => ({ key: entry.id, entry, count: 1 }));
  const groups = new Map();
  for (const entry of entries) {
    const key = `${entry.level}\n${entry.text}\n${entry.file}:${entry.line}:${entry.column}`;
    const group = groups.get(key);
    if (group) {
      group.count += 1;
      group.entry = entry;
    } else {
      groups.set(key, { key, entry, count: 1 });
    }
  }
  return [...groups.values()];
}

function countModules(entries) {
  const counts = new Map();
  for (const e of entries) (e.chain ?? []).forEach((c) => counts.set(c.module, (counts.get(c.module) ?? 0) + 1));
  return [...counts].map(([id, count]) => ({ id, count })).sort((a, b) => b.count - a.count || a.id.localeCompare(b.id));
}


const MAX_NET_EVENTS = 250;
const STACK_LIMIT = 50;
const LEASE_MS = 30000;
const RENEW_MS = 20000;

const epoch = `${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
const selfUrl = parseStack(new Error().stack ?? '')[0]?.url ?? '';
let idSeq = 0;

function safely(task) {
  try {
    task();
  } catch {}
}

function wrap(owner, name, fn) {
  const original = owner[name];
  if (typeof original !== 'function') return;
  const replacement = function (...args) {
    if (new.target) return Reflect.construct(original, args, new.target);
    return fn.call(this, original, args);
  };
  if (original.prototype) replacement.prototype = original.prototype;
  owner[name] = replacement;
}

function captureStack(depth = STACK_LIMIT) {
  const limit = Error.stackTraceLimit;
  Error.stackTraceLimit = depth;
  const stack = new Error().stack;
  Error.stackTraceLimit = limit;
  return stack;
}

function pageFrames(stack) {
  return parseStack(stack ?? '').filter((f) => f.url !== selfUrl && !f.url.startsWith('chrome-extension://'));
}

function absUrl(raw) {
  try {
    return new URL(String(raw ?? ''), document.baseURI).href;
  } catch {
    return String(raw ?? '');
  }
}

function serializeNetBody(body) {
  if (body === undefined || body === null) return null;
  if (typeof body === 'string') return body.length > 200000 ? `${body.slice(0, 200000)}\n... (truncated)` : body;
  if (typeof URLSearchParams !== 'undefined' && body instanceof URLSearchParams) return body.toString();
  if (typeof FormData !== 'undefined' && body instanceof FormData) {
    return [...body.entries()].map(([k, v]) => `${k}=${typeof v === 'string' ? v : `[File: ${v?.name || 'blob'}]`}`).join('&');
  }
  return '[Binary/Stream]';
}

function readLease(key) {
  try {
    return Number(sessionStorage.getItem(key)) || 0;
  } catch {
    return 0;
  }
}

function createTracker(key, max, evictIndex = () => 0) {
  const events = [];
  let until = readLease(key);
  let written = until;
  let seq = 0;
  let cursor = -1;
  let dropped = 0;
  const writeLease = (next) => {
    written = next;
    try {
      if (next) sessionStorage.setItem(key, String(next));
      else sessionStorage.removeItem(key);
    } catch {}
  };
  const active = () => {
    if (!until) return false;
    if (Date.now() < until) return true;
    until = 0;
    events.length = 0;
    return false;
  };
  return {
    active,
    nextId: () => `${epoch}:${++idSeq}`,
    bump(item) {
      item.seq = ++seq;
    },
    push(item) {
      if (!active()) return false;
      item.seq = ++seq;
      events.push(item);
      if (events.length > max) {
        const [evicted] = events.splice(Math.max(0, evictIndex(events)), 1);
        if (evicted.seq > cursor) dropped += 1;
      }
      return true;
    },
    track(enabled) {
      until = enabled ? Date.now() + LEASE_MS : 0;
      if (!enabled) events.length = 0;
      writeLease(until);
      return { epoch, enabled: active(), seq };
    },
    drain(afterSeq, from, shape) {
      const after = from && from !== epoch ? -1 : Number(afterSeq ?? -1);
      if (active()) {
        until = Date.now() + LEASE_MS;
        if (written - Date.now() < RENEW_MS) writeLease(until);
      }
      const lost = dropped;
      dropped = 0;
      const out = events.filter((e) => e.seq > after).map(shape);
      cursor = seq;
      return { epoch, seq, enabled: active(), dropped: lost, events: out };
    },
  };
}

const net = createTracker('3di.netTrackUntil', MAX_NET_EVENTS, (events) => events.findIndex((e) => e.state !== 'pending'));

function startRequest(method, url, resourceType, postDataText) {
  const req = {
    id: net.nextId(),
    method,
    url,
    frameUrl: location.href,
    resourceType,
    startedAt: Date.now(),
    endedAt: null,
    duration: null,
    httpStatus: null,
    state: 'pending',
    postDataText,
    stack: captureStack(),
  };
  net.push(req);
  return req;
}

function settleRequest(req, state, httpStatus) {
  if (!req || req.state !== 'pending') return;
  const endedAt = Date.now();
  req.state = state;
  req.httpStatus = httpStatus;
  req.endedAt = endedAt;
  req.duration = Math.max(0, endedAt - req.startedAt);
  net.bump(req);
}

function netTrack(enabled) {
  return net.track(enabled);
}

function netDrain(afterSeq = -1, from = '') {
  return net.drain(afterSeq, from, ({ stack, ...e }) => ({ ...e, rawStack: pageFrames(stack) }));
}

function watchXhrSettle(xhr, req) {
  const handlers = {};
  const finish = (state, status) => {
    Object.entries(handlers).forEach(([t, h]) => xhr.removeEventListener(t, h));
    settleRequest(req, state, status);
  };
  handlers.load = () => finish('done', xhr.status);
  handlers.error = () => finish('error', xhr.status || 0);
  handlers.abort = () => finish('aborted', 0);
  handlers.timeout = () => finish('error', 0);
  Object.entries(handlers).forEach(([t, h]) => xhr.addEventListener(t, h));
}

function installNetwork() {
  if (typeof XMLHttpRequest !== 'undefined') {
    wrap(XMLHttpRequest.prototype, 'open', function (original, args) {
      safely(() => {
        this.__3diMethod = String(args[0] ?? 'GET').toUpperCase();
        this.__3diRawUrl = args[1] instanceof URL ? args[1].href : String(args[1] ?? '');
      });
      return original.apply(this, args);
    });
    wrap(XMLHttpRequest.prototype, 'send', function (original, args) {
      safely(() => {
        if (!net.active()) return;
        const req = startRequest(this.__3diMethod || 'GET', absUrl(this.__3diRawUrl), 'xhr', serializeNetBody(args[0]));
        if (typeof this.addEventListener === 'function') watchXhrSettle(this, req);
      });
      return original.apply(this, args);
    });
  }
  if (typeof window.fetch === 'function') {
    wrap(window, 'fetch', function (original, args) {
      let req = null;
      safely(() => {
        if (!net.active()) return;
        const [input, init] = args;
        const rawUrl = typeof input === 'string' ? input : input instanceof URL ? input.href : input?.url ?? '';
        const method = String(init?.method || (input && typeof input === 'object' && !(input instanceof URL) ? input.method : '') || 'GET').toUpperCase();
        req = startRequest(method, absUrl(rawUrl), 'fetch', serializeNetBody(init?.body));
      });
      if (!req) return original.apply(this, args);
      try {
        const promise = original.apply(this, args);
        if (typeof promise?.then !== 'function') return promise;
        return promise.then(
          (res) => {
            safely(() => settleRequest(req, 'done', res?.status ?? 0));
            return res;
          },
          (err) => {
            safely(() => settleRequest(req, err?.name === 'AbortError' ? 'aborted' : 'error', 0));
            throw err;
          },
        );
      } catch (err) {
        safely(() => settleRequest(req, 'error', 0));
        throw err;
      }
    });
  }
}

if (!window.__3di) {
  installNetwork();
  Object.defineProperty(window, '__3di', {
    configurable: true,
    enumerable: false,
    writable: false,
    value: { netTrack, netDrain },
  });
}
})();
