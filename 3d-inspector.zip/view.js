import { escapeRe } from './core.js';
import { tokenLines } from './highlight.js';
import { iconSvg, setIcon } from './icons.js';

export function el(tag, cls, ...children) {
  const node = document.createElement(tag);
  if (cls) node.className = cls;
  node.append(...children.filter((c) => c !== null && c !== undefined && c !== false));
  return node;
}

export function applyTheme() {
  const scheme = matchMedia('(prefers-color-scheme: dark)');
  const apply = () => {
    document.documentElement.dataset.theme = scheme.matches ? 'dark' : 'light';
  };
  apply();
  scheme.addEventListener('change', apply);
}

export function copyWithFeedback(button, getText, { iconOnly = false, label = '' } = {}) {
  const text = typeof getText === 'function' ? getText() : getText;
  if (!text) return;
  navigator.clipboard?.writeText(text).catch(() => {});
  clearTimeout(button._copyTimer);
  if (iconOnly) {
    const prev = button.innerHTML;
    setIcon(button, 'check', 13);
    button.classList.add('ghost-on');
    button._copyTimer = setTimeout(() => {
      button.innerHTML = prev;
      button.classList.remove('ghost-on');
    }, 1000);
    return;
  }
  const prev = button.innerHTML;
  button.innerHTML = `${iconSvg('check', 12)}<span>복사됨</span>`;
  button.classList.add('ghost-on');
  button._copyTimer = setTimeout(() => {
    button.innerHTML = prev || label;
    button.classList.remove('ghost-on');
  }, 1000);
}

function tokenNodes(tokens, mark) {
  let pos = 0;
  return tokens.flatMap((t) => {
    const start = pos;
    pos += t.text.length;
    const cuts = mark ? [start, Math.min(Math.max(mark.start, start), pos), Math.min(Math.max(mark.end, start), pos), pos] : [start, start, start, pos];
    return [0, 1, 2].flatMap((k) => {
      if (cuts[k + 1] <= cuts[k]) return [];
      const text = t.text.slice(cuts[k] - start, cuts[k + 1] - start);
      const node = t.type === 'plain' ? document.createTextNode(text) : el('span', `t-${t.type}`, text);
      return [k === 1 ? el('mark', null, node) : node];
    });
  });
}

function lineNlsHint(tokens, nlsMap) {
  if (!nlsMap?.size) return null;
  for (const tok of tokens) {
    if (tok.type !== 'property' || !/^[A-Z][A-Z0-9_]{2,}$/.test(tok.text)) continue;
    const val = nlsMap.get(tok.text);
    if (!val) continue;
    const clipped = val.length > 48 ? `${val.slice(0, 48)}…` : val;
    const hint = el('span', 'nls-hint', `NLS: "${clipped}"`);
    hint.title = `${tok.text} = ${val}`;
    return hint;
  }
  return null;
}

export function renderCode(container, text, { kind = 'js', firstLine = 1, focusLine = null, mark = null, nlsMap = null, onLineClick = null } = {}) {
  const lines = tokenLines(text, kind);
  const width = String(firstLine + lines.length - 1).length;
  const rows = lines.map((tokens, i) => {
    const no = firstLine + i;
    const ln = el('span', 'ln', String(no).padStart(width));
    if (onLineClick) {
      ln.title = `${no}줄 동기화`;
      ln.addEventListener('click', () => onLineClick(no));
    }
    const hint = kind === 'js' ? lineNlsHint(tokens, nlsMap) : null;
    const row = el('div', no === focusLine ? 'code-row focus' : 'code-row', ln, el('span', 'lc', ...tokenNodes(tokens, mark?.line === no ? mark : null)), hint);
    row.dataset.line = String(no);
    return row;
  });
  container.replaceChildren(el('div', 'code-lines', ...rows));
  return container.querySelector('.code-row.focus');
}

export function highlightCodeLine(container, lineNo) {
  container.querySelectorAll('.code-row.focus').forEach((r) => r.classList.remove('focus'));
  const target = container.querySelector(`.code-row[data-line="${lineNo}"]`);
  target?.classList.add('focus');
  return target ?? null;
}

export function scrollToRow(scroller, row) {
  if (row) scroller.scrollTop = Math.max(0, row.offsetTop - scroller.clientHeight / 2);
  else scroller.scrollTop = 0;
}

function link(cls, text, title, onClick) {
  const a = el('a', cls, text);
  a.href = '#';
  a.title = title;
  a.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    onClick();
  });
  return a;
}

function moduleLink(id, handlers) {
  return link('mod', id, '모듈 코드 보기', () => handlers.onModule(id));
}

function badge(text, cls) {
  return el('span', `badge ${cls}`, text);
}

function locRow(cls, h, handlers, ...content) {
  const row = el('div', `${cls} clickable`, ...content);
  row.title = `${h.file}:${h.line}:${h.column} 코드 보기`;
  row.addEventListener('click', () => handlers.onLocation(h.file, h.line, h.column, row));
  return row;
}

function section(title, count, ...items) {
  return el('section', 'group', el('h3', 'group-head', el('span', null, title), count === null ? null : el('span', 'count', String(count))), ...items);
}

function groupBlock(g, handlers) {
  const head = el(
    'summary',
    'mod-head',
    badge((g.kind ?? 'file').toUpperCase(), `k-${g.kind ?? 'file'}`),
    g.inModule ? moduleLink(g.module, handlers) : el('span', 'file-title', g.module),
    g.inModule ? el('span', 'file-name', g.file) : null,
    el('span', 'count', String(g.hits.length)),
  );
  const users = g.users ? el('div', 'users', '← 사용: ', ...(g.users.length ? g.users.flatMap((u, i) => [i ? ', ' : null, moduleLink(u, handlers)]) : ['미확인'])) : null;
  const rows = g.hits.map((h) => {
    const row = locRow('hit', h, handlers, el('span', 'loc', `${h.line}:${h.column}`), el('code', 'snippet', h.before, el('mark', null, h.match), h.after));
    row.dataset.filter = `${h.before}${h.match}${h.after}`.toLowerCase();
    return row;
  });
  const block = el('details', 'mod-block', head, users, ...rows);
  block.dataset.kind = g.kind ?? 'file';
  if (g.primary) block.dataset.primary = 'true';
  block.dataset.filter = [g.module, g.file, ...(g.users ?? [])].join('\n').toLowerCase();
  block.open = true;
  return block;
}

function message(text, cls = 'message') {
  return el('div', cls, ...String(text).split('\n').flatMap((line, i) => [i ? el('br') : null, line]));
}

export function setPressed(button, on) {
  button.classList.toggle('on', on);
  button.setAttribute('aria-pressed', String(on));
}

export function togglePressed(button) {
  setPressed(button, !button.classList.contains('on'));
}

export function syncClearButton(input) {
  input?._syncClear?.();
}

export function bindClearButton(input, button, onClear = null) {
  const sync = () => {
    button.hidden = !input.value;
  };
  input._syncClear = sync;
  input.addEventListener('input', sync);
  input.addEventListener('change', sync);
  button.addEventListener('mousedown', (e) => e.preventDefault());
  button.addEventListener('click', () => {
    input.value = '';
    sync();
    input.dispatchEvent(new Event('input', { bubbles: true }));
    onClear?.();
    input.focus();
  });
  sync();
  return button;
}

export function makeClearable(input, { inline = false, onClear = null } = {}) {
  const btn = setIcon(el('button', 'icon input-clear'), 'x', 12);
  btn.type = 'button';
  btn.title = '입력 지우기';
  bindClearButton(input, btn, onClear);
  if (inline) {
    input.after(btn);
    return input.parentElement;
  }
  const wrap = el('span', 'clear-wrap');
  if (input.parentNode) input.replaceWith(wrap);
  wrap.append(input, btn);
  return wrap;
}

export function findPattern(input, regexBtn, query) {
  const isRegex = regexBtn.classList.contains('on');
  try {
    const re = query ? new RegExp(isRegex ? query : escapeRe(query), 'gi') : null;
    input.classList.remove('invalid');
    input.title = input.dataset.title;
    return re;
  } catch (e) {
    input.classList.add('invalid');
    input.title = `정규식 오류: ${e.message}`;
    return null;
  }
}

export function regexToggle(onChange) {
  const button = el('button', 'toggle regex-toggle', '.*');
  button.type = 'button';
  button.title = '정규식 사용';
  button.setAttribute('aria-pressed', 'false');
  button.addEventListener('mousedown', (e) => e.preventDefault());
  button.addEventListener('click', () => {
    const on = button.classList.toggle('on');
    button.setAttribute('aria-pressed', String(on));
    onChange();
  });
  return button;
}

function resultFilter(container) {
  const input = el('input', 'find-input result-filter');
  input.placeholder = '결과 내 필터';
  input.dataset.title = '모듈 ID, 파일 이름, 코드에 이 글자가 있는 결과만 봅니다 (Esc: 지우기)';
  input.title = input.dataset.title;
  const count = el('span', 'find-count');
  const apply = () => {
    const q = input.value.trim();
    const re = findPattern(input, regexBtn, q);
    const has = (text) => !re || text.search(re) >= 0;
    let shown = 0;
    let total = 0;
    container.querySelectorAll('.mod-block').forEach((block) => {
      const whole = has(block.dataset.filter);
      const rows = [...block.querySelectorAll('.hit')];
      rows.forEach((row) => (row.hidden = !whole && !has(row.dataset.filter)));
      const visible = rows.filter((row) => !row.hidden).length;
      block.hidden = !visible;
      shown += visible;
      total += rows.length;
    });
    count.textContent = q ? `${shown}/${total}` : '';
  };
  input.addEventListener('input', apply);
  input.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    input.value = '';
    syncClearButton(input);
    apply();
  });
  const regexBtn = regexToggle(apply);
  const wrap = makeClearable(input);
  wrap.append(regexBtn);
  return el('span', 'result-filter-box', wrap, count);
}

function foldButton(container, open, label) {
  const button = el('button', 'fold', label);
  button.addEventListener('click', () => container.querySelectorAll('.mod-block').forEach((block) => (block.open = open)));
  return button;
}

export function renderResults(container, r, handlers) {
  if (r.error) return container.replaceChildren(message(r.error));
  if (!r.groups.length) return container.replaceChildren(message(`"${r.query}" ${r.how} 검색: 일치 없음`));
  const moreBar =
    r.truncated && handlers.onMore
      ? (() => {
          const next = (r.limit ?? 100) + 200;
          const moreBtn = el('button', null, `더 보기 (+200)`);
          moreBtn.addEventListener('click', () => handlers.onMore(next));
          const allBtn = el('button', 'ghost', '전체 검색');
          allBtn.title = '상한 없이 로드된 파일 전체에서 모두 찾습니다';
          allBtn.addEventListener('click', () => handlers.onMore(Infinity));
          return el('div', 'more-bar', el('span', 'muted', `${r.total}곳에서 멈췄습니다 (성능 보호)`), moreBtn, allBtn);
        })()
      : null;
  const result = section(`"${r.query}" ${r.how}`, `${r.total}${r.truncated ? '+' : ''}`, ...r.groups.map((g) => groupBlock(g, handlers)), moreBar);
  const head = result.querySelector('.group-head');
  head.classList.add('result-head');
  head.append(resultFilter(result), foldButton(result, false, '모두 접기'), foldButton(result, true, '모두 펼치기'));
  container.replaceChildren(result);
}

export function renderInspect(container, r, handlers) {
  if (r.error) return container.replaceChildren(message(r.error));
  const head = el('div', 'inspect-head', el('div', 'inspect-label', r.label), r.text ? el('div', 'inspect-text', `"${r.text}"`) : null);
  const parts = r.tokens.map((t) => section(`"${t.token}"`, null, ...t.groups.map((g) => groupBlock(g, handlers))));
  container.replaceChildren(head, ...(parts.length ? parts : [message('일치 없음: 이 요소의 문구와 클래스명이 검색한 파일에 없습니다. 부모 요소를 선택하거나 3D Inspector 탭에서 다른 단어로 검색하세요.')]));
}

export function renderHelp(container, lines) {
  container.replaceChildren(el('div', 'help', el('h3', 'group-head', el('span', null, '사용법')), el('ul', null, ...lines.map((line) => el('li', null, line)))));
}

export function animateSize(change) {
  document.body.classList.add('animate-size');
  change();
  clearTimeout(animateSize.timer);
  animateSize.timer = setTimeout(() => {
    document.body.classList.remove('animate-size');
    document.getAnimations?.().forEach((a) => {
      if (a.transitionProperty === 'flex-basis') a.finish();
    });
  }, 250);
}

export function transitionLayout(change, when = true) {
  if (!when || !document.startViewTransition || matchMedia('(prefers-reduced-motion: reduce)').matches) return change();
  document.startViewTransition(change).ready.catch(() => {});
}

export function bindResizer(handle, key, axis, apply, fallback, minPx) {
  const clamp = (v, min = 10) => Math.min(100 - min, Math.max(min, v));
  let pct = clamp(Number(localStorage.getItem(key)) || fallback);
  apply(pct);
  handle.addEventListener('dblclick', () => {
    pct = fallback;
    animateSize(() => apply(pct));
    localStorage.removeItem(key);
  });
  handle.addEventListener('mousedown', (e) => {
    e.preventDefault();
    const box = handle.parentElement.getBoundingClientRect();
    const size = axis === 'x' ? box.width : box.height;
    const minPct = Math.min(50, (minPx / Math.max(size, 1)) * 100);
    handle.classList.add('dragging');
    document.body.classList.add(axis === 'x' ? 'resizing-x' : 'resizing-y');
    const move = (ev) => {
      pct = clamp(axis === 'x' ? ((ev.clientX - box.left) / box.width) * 100 : ((box.bottom - ev.clientY) / box.height) * 100, minPct);
      apply(pct);
    };
    const up = () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
      handle.classList.remove('dragging');
      document.body.classList.remove('resizing-x', 'resizing-y');
      localStorage.setItem(key, String(Math.round(pct * 10) / 10));
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  });
}

function textRanges(row, re) {
  const nodes = [];
  const walker = document.createTreeWalker(row, NodeFilter.SHOW_TEXT);
  let total = '';
  for (let node = walker.nextNode(); node; node = walker.nextNode()) {
    nodes.push({ node, start: total.length });
    total += node.data;
  }
  const at = (offset) => {
    const found = nodes.findLast((n) => n.start <= offset) ?? nodes[0];
    return [found.node, Math.min(offset - found.start, found.node.data.length)];
  };
  const ranges = [];
  for (const match of total.matchAll(re)) {
    if (!match[0]) continue;
    const range = new Range();
    range.setStart(...at(match.index));
    range.setEnd(...at(match.index + match[0].length));
    ranges.push(range);
  }
  return ranges;
}

export function createFinder(name, codeRoot, scroller) {
  const input = el('input', 'find-input');
  input.placeholder = '찾기';
  input.dataset.title = 'Enter: 다음, Shift+Enter: 이전, Esc: 지우기';
  input.title = input.dataset.title;
  const count = el('span', 'find-count');
  const prev = setIcon(el('button', 'icon'), 'chevronUp', 13);
  const next = setIcon(el('button', 'icon'), 'chevronDown', 13);
  prev.title = '이전';
  next.title = '다음';
  let ranges = [];
  let index = -1;
  const paint = (scroll) => {
    if (!globalThis.CSS?.highlights) return;
    CSS.highlights.set(`find-${name}`, new Highlight(...ranges));
    CSS.highlights.set(`find-${name}-current`, new Highlight(...(index >= 0 ? [ranges[index]] : [])));
    count.textContent = input.value ? `${ranges.length ? index + 1 : 0}/${ranges.length}` : '';
    if (!scroll || index < 0) return;
    const r = ranges[index].getBoundingClientRect();
    const box = scroller.getBoundingClientRect();
    scroller.scrollTop += r.top - box.top - scroller.clientHeight / 2;
    if (r.left < box.left + 60 || r.right > box.right - 20) scroller.scrollLeft += r.left - box.left - scroller.clientWidth / 3;
  };
  const run = (scroll) => {
    const re = findPattern(input, regexBtn, input.value);
    ranges = re ? [...codeRoot.querySelectorAll('.lc')].flatMap((row) => textRanges(row, re)) : [];
    index = ranges.length ? 0 : -1;
    paint(scroll);
  };
  const step = (delta) => {
    if (!ranges.length) return;
    index = (index + delta + ranges.length) % ranges.length;
    paint(true);
  };
  input.addEventListener('input', () => run(true));
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') step(e.shiftKey ? -1 : 1);
    if (e.key === 'Escape') {
      input.value = '';
      syncClearButton(input);
      run(false);
    }
  });
  prev.addEventListener('click', () => step(-1));
  next.addEventListener('click', () => step(1));
  const clearBtn = setIcon(el('button', 'icon input-clear'), 'x', 12);
  clearBtn.type = 'button';
  clearBtn.title = '입력 지우기';
  bindClearButton(input, clearBtn);
  const regexBtn = regexToggle(() => run(true));
  return { node: el('div', 'find', el('span', 'find-box', input, count, clearBtn, regexBtn), prev, next), refresh: () => run(false), count: () => ranges.length, current: () => index };
}
