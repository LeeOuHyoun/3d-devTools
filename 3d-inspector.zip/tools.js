import { Parser } from './vendor/acorn.js';
import { generate } from './vendor/astring.js';
import { createMatcher, fileKind, findModule, isTargetUrl, searchInBundles, stripPlugin, stripQuery, toLineColumn } from './core.js';

const PARSE_OPTIONS = { ecmaVersion: 'latest' };
const MAX_HITS = 100;
const MAX_ALL_HITS = 5000;
const MAX_LISTED_FILES = 10;
const CONTEXT_LINES = 100;
const MAX_LINE = 20000;
const MODE_LABELS = { contains: '포함', start: '시작', end: '끝', word: '단어 일치', regex: '정규식' };
const NO_BUNDLES = [
  '검색할 파일을 찾지 못했습니다.',
  '- 위젯 화면이 열린 탭에서 개발자도구를 열었는지 확인하세요.',
  '- 파일 이름 조건과 파일 종류(JS, HTML, JSON, CSS) 체크를 확인하세요. 이름 칸을 비우면 로드된 파일 전체를 검색합니다.',
].join('\n');
const FUNCTION_TYPES = new Set(['FunctionExpression', 'FunctionDeclaration', 'ArrowFunctionExpression']);
const META_KEYS = new Set(['type', 'start', 'end', 'loc', 'range']);
const KEY_OWNERS = new Set(['MemberExpression', 'Property', 'MethodDefinition', 'PropertyDefinition']);
const RESERVED = new Set('arguments await break case catch class const continue debugger default delete do else enum eval export extends false finally for function if implements import in instanceof interface let new null package private protected public return static super switch this throw true try typeof var void while with yield'.split(' '));
const NLS_URL_RE = /(?:_(?:ko|en|ja|zh|de|fr|es)\.js$|\/nls\/)/i;
const EVENT_METHODS = new Set(['publish', 'subscribe', 'publishEvent', 'addEvent']);

function usersOf(bundles, id) {
  const clean = stripPlugin(id);
  return bundles.flatMap((b) => b.modules.filter((m) => m.id !== id && m.deps.some((d) => stripPlugin(d) === clean)).map((m) => m.id));
}

export function moduleRelations(bundles, id) {
  for (const b of bundles) {
    const mod = b.modules.find((m) => m.id === id);
    if (mod) return { deps: mod.deps.map(stripPlugin), usedBy: usersOf(bundles, id) };
  }
  return { deps: [], usedBy: [] };
}

export function listModules(bundles) {
  return bundles.flatMap((b) => b.modules.map((m) => ({ id: m.id, file: b.name, primary: isTargetUrl(b.url) })));
}

function groupHits(bundles, hits) {
  const groups = new Map();
  hits.forEach((h) => {
    const key = `${h.module}\n${h.url}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(h);
  });
  return [...groups.values()].map((list) => ({
    module: list[0].module,
    inModule: list[0].inModule,
    file: list[0].file,
    url: list[0].url,
    kind: list[0].kind,
    primary: isTargetUrl(list[0].url),
    users: list[0].module.includes('!') ? usersOf(bundles, list[0].module) : null,
    hits: list,
  }));
}

export function bundleSummary(bundles) {
  if (!bundles.length) return NO_BUNDLES;
  if (bundles.length <= MAX_LISTED_FILES) return `검색한 파일 ${bundles.length}개: ${bundles.map((b) => b.name).join(', ')}`;
  const counts = Object.entries(bundles.reduce((acc, b) => ({ ...acc, [b.kind]: (acc[b.kind] ?? 0) + 1 }), {}));
  return `검색한 파일 ${bundles.length}개 (${counts.map(([kind, n]) => `${String(kind).toUpperCase()} ${n}`).join(', ')})`;
}

export function searchMatcher(query, options = {}) {
  const q = (query ?? '').trim();
  return q ? createMatcher(q, options) : { error: '검색어를 입력하세요. (화면 문구, 키, 모듈 ID, 클래스명, 코드 문자열)' };
}

export function searchResults(bundles, query, options = {}) {
  const q = (query ?? '').trim();
  const matcher = searchMatcher(q, options);
  if (matcher.error) return { error: q ? `정규식 오류: ${matcher.error}` : matcher.error };
  if (!bundles.length) return { error: NO_BUNDLES };
  const limit = Math.min(options.limit ?? MAX_HITS, MAX_ALL_HITS);
  const rawHits = searchInBundles(bundles, matcher, limit + 1);
  const truncated = rawHits.length > limit;
  const hits = truncated ? rawHits.slice(0, limit) : rawHits;
  return {
    query: q,
    how: `${MODE_LABELS[options.mode] ?? MODE_LABELS.contains}${options.caseSensitive ? ', 대소문자 구분' : ''}`,
    groups: groupHits(bundles, hits),
    total: hits.length,
    limit,
    max: MAX_ALL_HITS,
    truncated,
  };
}

export function matchLengthAt(text, offset, matcher) {
  const sticky = (source, flags) => {
    const re = new RegExp(source, `${flags.replace('g', '')}y`);
    re.lastIndex = offset;
    return re.exec(text)?.[0].length || 0;
  };
  return (matcher?.global && sticky(matcher.global.source, matcher.global.flags)) || sticky('[\\w$]+', '') || 1;
}

export function originalView(bundle, offset, length = 0) {
  const { text, lineStarts } = bundle;
  const size = Math.min(length, MAX_LINE);
  const mod = findModule(bundle.modules, offset);
  const { line } = toLineColumn(lineStarts, offset);
  const lastLine = Math.min(lineStarts.length, line + CONTEXT_LINES);
  const from = mod ? mod.start : lineStarts[Math.max(0, line - 1 - CONTEXT_LINES)];
  const to = mod ? mod.end : lastLine < lineStarts.length ? lineStarts[lastLine] - 1 : text.length;
  const firstLine = toLineColumn(lineStarts, from).line;
  let start = from;
  let mark = null;
  const lines = text
    .slice(from, to)
    .split('\n')
    .map((raw, i) => {
      const lineStart = start;
      start += raw.length + 1;
      const content = raw.replace(/\r$/, '');
      if (firstLine + i !== line) return content.length > MAX_LINE ? `${content.slice(0, MAX_LINE)}…` : content;
      const col = offset - lineStart;
      const cut = content.length > MAX_LINE ? Math.max(0, col - MAX_LINE / 2) : 0;
      const end = content.length > MAX_LINE ? Math.min(content.length, col + size + MAX_LINE / 2) : content.length;
      const prefix = cut ? '…' : '';
      mark = { line, start: prefix.length + col - cut, end: prefix.length + col - cut + size };
      return `${prefix}${content.slice(cut, end)}${end < content.length ? '…' : ''}`;
    });
  return { text: lines.join('\n'), firstLine, line, mark: length ? mark : null, module: mod?.id ?? null };
}

export function elementClues(el) {
  if (!(el instanceof Element)) return null;
  const skip = new Set(['active', 'selected', 'disabled', 'hidden', 'open', 'show', 'hide', 'button', 'title', 'label', 'container', 'wrapper', 'content', 'header', 'footer']);
  const textOf = (n) =>
    [n.textContent, n.getAttribute('title'), n.getAttribute('placeholder'), n.getAttribute('aria-label')]
      .map((t) => t?.replace(/\s+/g, ' ').trim())
      .find((t) => t && t.length <= 100) ?? '';
  const tokens = new Set();
  for (let n = el, d = 0; n instanceof Element && d < 3; n = n.parentElement, d++) {
    if (n.id && n.id.length > 2) tokens.add(n.id);
    for (const attr of ['data-command', 'data-id', 'data-name', 'name', 'command']) {
      const v = n.getAttribute(attr)?.trim();
      if (v && v.length > 2) tokens.add(v);
    }
    if (typeof n.className === 'string') {
      n.className
        .split(/\s+/)
        .filter((c) => c.length > 4 && !skip.has(c) && !/^(?:wux-controls-|wux-layouts-|wux-windows-|uwa-)/.test(c))
        .forEach((c) => tokens.add(c));
    }
  }
  const id = el.id ? `#${el.id}` : '';
  const cls = typeof el.className === 'string' && el.className.trim() ? `.${el.className.trim().split(/\s+/).join('.')}` : '';
  return { label: `${el.tagName.toLowerCase()}${id}${cls}`, text: textOf(el), tokens: [...tokens].slice(0, 6) };
}

export function inspectResults(bundles, clue, limit = 3) {
  if (!clue) return { error: 'Elements 탭에서 요소를 선택하세요.' };
  if (!bundles.length) return { error: NO_BUNDLES };
  const terms = [...new Set([clue.text, ...clue.tokens].filter((t) => t && t.length >= 2))];
  return {
    label: clue.label,
    text: clue.text,
    tokens: terms.map((token) => ({ token, groups: groupHits(bundles, searchInBundles(bundles, createMatcher(token), limit)) })).filter((t) => t.groups.length),
  };
}

function children(node) {
  return Object.entries(node)
    .filter(([key]) => !META_KEYS.has(key))
    .flatMap(([key, value]) => (Array.isArray(value) ? value : [value]).filter((c) => typeof c?.type === 'string').map((c) => [key, c]));
}

function patternNames(node) {
  switch (node?.type) {
    case 'Identifier':
      return [node.name];
    case 'ObjectPattern':
      return node.properties.flatMap((p) => patternNames(p.type === 'RestElement' ? p : p.value));
    case 'ArrayPattern':
      return node.elements.flatMap(patternNames);
    case 'AssignmentPattern':
      return patternNames(node.left);
    case 'RestElement':
      return patternNames(node.argument);
    default:
      return [];
  }
}

function tagged(names, kind) {
  return names.map((name) => [name, kind]);
}

function varNames(node) {
  return children(node).flatMap(([, c]) => {
    if (FUNCTION_TYPES.has(c.type) || c.type === 'StaticBlock') return [];
    const own = c.type === 'VariableDeclaration' && c.kind === 'var' ? tagged(c.declarations.flatMap((d) => patternNames(d.id)), 'v') : [];
    return [...own, ...varNames(c)];
  });
}

function lexicalNames(statements) {
  return statements.flatMap((s) => {
    if (s.type === 'VariableDeclaration' && s.kind !== 'var') return tagged(s.declarations.flatMap((d) => patternNames(d.id)), 'v');
    if (!s.id) return [];
    return s.type === 'ClassDeclaration' ? [[s.id.name, 'C']] : s.type === 'FunctionDeclaration' ? [[s.id.name, 'f']] : [];
  });
}

function loopNames(declaration) {
  return declaration?.type === 'VariableDeclaration' && declaration.kind !== 'var' ? lexicalNames([declaration]) : [];
}

function bindings(node) {
  if (FUNCTION_TYPES.has(node.type)) {
    const body = node.body.type === 'BlockStatement' ? varNames(node.body) : [];
    return [...(node.type === 'FunctionExpression' && node.id ? [[node.id.name, 'f']] : []), ...tagged(node.params.flatMap(patternNames), 'p'), ...body];
  }
  switch (node.type) {
    case 'BlockStatement':
      return lexicalNames(node.body);
    case 'StaticBlock':
      return [...varNames(node), ...lexicalNames(node.body)];
    case 'SwitchStatement':
      return lexicalNames(node.cases.flatMap((c) => c.consequent));
    case 'ForStatement':
      return loopNames(node.init);
    case 'ForInStatement':
    case 'ForOfStatement':
      return loopNames(node.left);
    case 'CatchClause':
      return tagged(patternNames(node.param), 'v');
    case 'ClassExpression':
      return node.id ? [[node.id.name, 'C']] : [];
    default:
      return [];
  }
}

function isReference(parent, key) {
  if (KEY_OWNERS.has(parent.type) && (key === 'key' || (parent.type === 'MemberExpression' && key === 'property'))) return parent.computed;
  return key !== 'label' && parent.type !== 'MetaProperty';
}

function outerKey(node, key) {
  return (node.type === 'SwitchStatement' && key === 'discriminant') || (node.type === 'FunctionDeclaration' && key === 'id');
}

function rename(node, env, pick) {
  const own = new Map();
  bindings(node).forEach(([name, kind]) => own.has(name) || own.set(name, pick(node, name, kind)));
  const scope = own.size ? new Map([...env, ...own]) : env;
  if (node.type === 'Property' && node.value?.type === 'AssignmentPattern') node.shorthand = false;
  children(node).forEach(([key, child]) => {
    const visible = outerKey(node, key) ? env : scope;
    if (child.type !== 'Identifier') return rename(child, visible, pick);
    const to = isReference(node, key) ? visible.get(child.name) : null;
    if (!to) return;
    child.name = to;
    if (node.type === 'Property') node.shorthand = false;
  });
}

function identifierNames(node, found = new Set()) {
  if (node.type === 'Identifier') found.add(node.name);
  children(node).forEach(([, c]) => identifierNames(c, found));
  return found;
}

function nameOf(dep) {
  const base = stripPlugin(dep).split('/').at(-1).replace(/[^\w$]/g, '_');
  return !base || /^\d/.test(base) || RESERVED.has(base) ? `_${base}` : base;
}

function restoreNames(call, locals) {
  const factory = call.arguments.find((a) => FUNCTION_TYPES.has(a.type));
  const deps = call.arguments.find((a) => a.type === 'ArrayExpression')?.elements.map((e) => e?.value) ?? [];
  const used = identifierNames(call);
  const names = new Map();
  const header = (factory?.params ?? []).flatMap((p, i) => {
    if (p.type !== 'Identifier' || typeof deps[i] !== 'string') return [];
    let name = nameOf(deps[i]);
    while (used.has(name)) name += '$';
    used.add(name);
    names.set(p.name, name);
    return [`// ${p.name} → ${name} = ${deps[i]}`];
  });
  const counts = {};
  const fresh = (kind) => {
    let name;
    do name = `${kind}${(counts[kind] = (counts[kind] ?? 0) + 1)}`;
    while (used.has(name));
    used.add(name);
    return name;
  };
  let renamed = 0;
  const pick = (node, name, kind) => {
    if (node === factory && names.has(name)) return names.get(name);
    if (!locals?.test(name)) return null;
    renamed += 1;
    return fresh(kind);
  };
  if (factory) rename(factory, new Map(), pick);
  return locals ? [...header, `// 지역 이름 ${renamed}개 바꿈 /${locals.source}/ (v 변수, f 함수, p 매개변수, C 클래스)`] : header;
}

function attachOffsets(node) {
  node.loc = { start: node.start };
  children(node).forEach(([, c]) => attachOffsets(c));
}

function parseModuleCall(bundle, id) {
  const mod = bundle.modules.find((m) => m.id === id);
  if (!mod) return null;
  const parser = new Parser(PARSE_OPTIONS, bundle.text.slice(mod.start, mod.end));
  parser.nextToken();
  return { mod, call: parser.parseMaybeAssign() };
}

export function offsetToGeneratedLine(modStart, marks, offset) {
  if (offset === null || !marks?.length) return null;
  const target = offset - modStart;
  const best = marks.reduce((acc, m) => (m[0] <= target && (!acc || m[0] >= acc[0]) ? m : acc), null);
  return best?.[1] ?? 1;
}

export function generatedLineToOffset(modStart, marks, line) {
  if (!marks?.length) return modStart;
  const exact = marks.find((m) => m[1] === line);
  if (exact) return modStart + exact[0];
  const before = marks.reduce((acc, m) => (m[1] <= line && (!acc || m[1] >= acc[1]) ? m : acc), null);
  return modStart + (before?.[0] ?? 0);
}

function buildModuleView(bundle, id, { rename = true, locals = null, offset = null } = {}) {
  const parsed = parseModuleCall(bundle, id);
  if (!parsed) return null;
  const { mod, call } = parsed;
  const header = [`// [3di module] ${id} (${bundle.name}, ${rename ? '이름 풀기' : '포맷'})`, ...(rename ? restoreNames(call, locals) : [])];
  attachOffsets(call);
  const marks = [];
  const code = generate(call, { sourceMap: { addMapping: (m) => marks.push([m.original, m.generated.line]) } });
  return {
    head: header.join('\n'),
    code,
    line: offsetToGeneratedLine(mod.start, marks, offset),
    modStart: mod.start,
    marks,
    deps: mod.deps.map(stripPlugin),
  };
}

export function moduleView(bundle, id, options) {
  try {
    return buildModuleView(bundle, id, options);
  } catch (e) {
    return { error: `${id}: 코드를 해석하지 못해 포맷/이름 풀기 보기를 만들 수 없습니다 (${e.message}). 원본 코드나 Sources를 이용하세요.` };
  }
}

export function restoreModule(bundle, id) {
  const view = moduleView(bundle, id);
  if (!view) return `[3di module] ${id}: 모듈 없음`;
  return view.error ?? `${view.head}\n${view.code}`;
}

function propKeyName(node) {
  if (!node) return null;
  if (node.type === 'Identifier') return node.name;
  if (node.type === 'Literal' && typeof node.value === 'string') return node.value;
  return null;
}

export function moduleOutline(bundle, id) {
  const parsed = parseModuleCall(bundle, id);
  if (!parsed) return { methods: [], events: [], nls: [] };
  const { mod, call } = parsed;
  const factory = call.arguments.find((a) => FUNCTION_TYPES.has(a.type));
  const deps = call.arguments.find((a) => a.type === 'ArrayExpression')?.elements.map((e) => e?.value) ?? [];
  const nlsParams = new Set(
    (factory?.params ?? [])
      .flatMap((p, i) => (p.type === 'Identifier' && typeof deps[i] === 'string' && deps[i].startsWith('i18n!') ? [p.name] : [])),
  );
  const methods = [];
  const events = [];
  const nls = [];
  const seenNls = new Set();
  const walk = (node) => {
    if (node.type === 'FunctionDeclaration' && node.id) {
      methods.push({ name: node.id.name, offset: mod.start + node.start });
    } else if (node.type === 'MethodDefinition' || (node.type === 'Property' && FUNCTION_TYPES.has(node.value?.type))) {
      const name = propKeyName(node.key);
      if (name) methods.push({ name, offset: mod.start + node.start });
    } else if (node.type === 'VariableDeclarator' && node.id?.type === 'Identifier' && FUNCTION_TYPES.has(node.init?.type)) {
      methods.push({ name: node.id.name, offset: mod.start + node.start });
    } else if (node.type === 'CallExpression' && node.callee?.type === 'MemberExpression' && !node.callee.computed) {
      const mName = node.callee.property?.name;
      const arg0 = node.arguments[0];
      if (EVENT_METHODS.has(mName) && arg0?.type === 'Literal' && typeof arg0.value === 'string') {
        events.push({ name: `${mName}("${arg0.value}")`, offset: mod.start + node.start });
      }
    } else if (node.type === 'MemberExpression' && !node.computed && node.object?.type === 'Identifier' && node.property?.type === 'Identifier') {
      const obj = node.object.name;
      if ((nlsParams.has(obj) || /nls$/i.test(obj)) && !seenNls.has(`${node.property.name}@${node.start}`)) {
        seenNls.add(`${node.property.name}@${node.start}`);
        nls.push({ name: node.property.name, offset: mod.start + node.start });
      }
    }
    children(node).forEach(([, c]) => walk(c));
  };
  walk(factory ?? call);
  return { methods, events, nls };
}

function collectObjectStrings(node, out) {
  if (!node) return;
  if (node.type === 'ObjectExpression') {
    for (const prop of node.properties) {
      const key = propKeyName(prop.key);
      if (key && prop.value?.type === 'Literal' && typeof prop.value.value === 'string') {
        out.set(key, prop.value.value);
      } else if (prop.value?.type === 'ObjectExpression') {
        collectObjectStrings(prop.value, out);
      }
    }
    return;
  }
  children(node).forEach(([, c]) => collectObjectStrings(c, out));
}

export function buildNlsIndex(bundles) {
  const map = new Map();
  const sorted = [...bundles].sort((a, b) => (/_ko\.js$/i.test(a.name) ? 1 : 0) - (/_ko\.js$/i.test(b.name) ? 1 : 0));
  for (const b of sorted) {
    const cleanUrl = stripQuery(b.url ?? b.name ?? '');
    const kind = b.kind ?? fileKind(cleanUrl);
    const isNls = NLS_URL_RE.test(b.name ?? '') || NLS_URL_RE.test(cleanUrl) || b.modules?.some((m) => /\/nls\//i.test(m.id));
    if (!isNls) continue;
    if (kind === 'json') {
      try {
        const parsed = JSON.parse(b.text);
        if (parsed && typeof parsed === 'object') {
          Object.entries(parsed).forEach(([k, v]) => typeof v === 'string' && map.set(k, v));
        }
      } catch {}
      continue;
    }
    if (kind === 'js') {
      try {
        const ast = Parser.parse(b.text, PARSE_OPTIONS);
        collectObjectStrings(ast, map);
      } catch {}
    }
  }
  return map;
}
