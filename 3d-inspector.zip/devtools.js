import { fileKind } from './core.js';
import { DETECT_DASHBOARD_EXPR, focusDevtoolsWindow, isDashboardResourceUrl, sendInspectorAction, showLocateOverlay } from './devtools-lib.js';

const MAX_BUFFER = 500;
const PRESERVE_KEY = '3di.net.preserveLog';
const RETRY_DELAYS = [300, 800, 1500, 3000];
const harBuffer = [];
let client = null;
let panelsCreated = false;
let dashboardActive = false;
let detectTimer = null;
let detectGen = 0;
let port = null;
let reconnectTimer = null;
let activePanelWin = null;

function isPreserveLog() {
  try {
    return localStorage.getItem(PRESERVE_KEY) === 'true';
  } catch {
    return false;
  }
}

function attachClient(nextClient) {
  if (client !== nextClient) client = nextClient;
  if (harBuffer.length) client.onHarBatch(harBuffer.splice(0));
}

const hostApi = {
  attach: attachClient,
};

function handleIdentifyDevtools() {
  focusDevtoolsWindow();
  if (activePanelWin?.document) showLocateOverlay(activePanelWin.document);
}

function postPortState() {
  if (!port) return;
  try {
    port.postMessage({ action: 'SET_DASHBOARD_ACTIVE', active: dashboardActive });
  } catch {}
}

function connectPort() {
  if (port || !chrome.runtime?.connect) return;
  const tabId = chrome.devtools?.inspectedWindow?.tabId;
  if (tabId == null) return;
  clearTimeout(reconnectTimer);
  try {
    port = chrome.runtime.connect({ name: `3di-devtools-${tabId}` });
  } catch {
    port = null;
    return;
  }
  port.onMessage.addListener((msg) => {
    if (msg?.action === 'IDENTIFY_DEVTOOLS') handleIdentifyDevtools();
  });
  port.onDisconnect.addListener(() => {
    port = null;
    if (!dashboardActive) return;
    reconnectTimer = setTimeout(connectPort, 1000);
  });
  postPortState();
}

function setDashboardActive(active) {
  dashboardActive = active;
  if (active && !port) connectPort();
  else postPortState();
}

function bindPanelWindow(panel, onShow, onHide) {
  let shownWin = null;
  panel.onShown.addListener((win) => {
    shownWin = win;
    activePanelWin = win;
    onShow?.(win);
  });
  panel.onHidden.addListener(() => {
    if (activePanelWin === shownWin) activePanelWin = null;
    onHide?.(shownWin);
  });
}

function openResourceIn(panel, resource, line = 1, column = 1) {
  if (fileKind(resource.url, resource.type) !== 'js') {
    chrome.devtools.panels.openResource(resource.url, line - 1, column - 1, () => {});
    return;
  }
  panel.show?.();
  sendInspectorAction({ type: 'openLocation', url: resource.url, line, column });
}

function createPanels() {
  if (panelsCreated) return;
  panelsCreated = true;
  chrome.devtools.panels.create('3D Inspector', 'icons/icon-32.png', 'panel.html', (panel) => {
    bindPanelWindow(panel);
    chrome.devtools.panels.setOpenResourceHandler?.((resource, line, column) => openResourceIn(panel, resource, line, column));
  });
  chrome.devtools.panels.create('3D Network', 'icons/icon-32.png', 'network.html', (panel) => {
    bindPanelWindow(
      panel,
      (win) => {
        if (win.__3diOnHostReady) win.__3diOnHostReady(hostApi);
        else win.__3diDevtoolsHost = hostApi;
        client?.onShown?.();
      },
      () => client?.onHidden?.(),
    );
  });
  chrome.devtools.panels.create('3D Console', 'icons/icon-32.png', 'console.html', (panel) => {
    bindPanelWindow(panel);
  });
  chrome.devtools.panels.create('3D Icons', 'icons/icon-32.png', 'glyphs.html', (panel) => {
    bindPanelWindow(panel);
  });
  chrome.devtools.panels.elements.createSidebarPane('3D Inspector', (pane) => pane.setPage('sidebar.html'));
}

function checkDashboard(done) {
  let settled = false;
  const finish = (ok) => {
    if (settled) return;
    settled = true;
    done(ok);
  };
  chrome.devtools.inspectedWindow.eval(DETECT_DASHBOARD_EXPR, {}, (hit, err) => {
    if (!err && hit) return finish(true);
    chrome.devtools.inspectedWindow.getResources((list) => {
      finish(Array.isArray(list) && list.some((r) => isDashboardResourceUrl(r.url)));
    });
  });
}

function detectDashboard(attempt = 0) {
  const gen = detectGen;
  clearTimeout(detectTimer);
  checkDashboard((isDashboard) => {
    if (gen !== detectGen) return;
    if (isDashboard) {
      setDashboardActive(true);
      createPanels();
      return;
    }
    if (attempt === 0 && dashboardActive) setDashboardActive(false);
    if (attempt < RETRY_DELAYS.length) {
      detectTimer = setTimeout(() => detectDashboard(attempt + 1), RETRY_DELAYS[attempt]);
      return;
    }
  });
}

chrome.devtools.network.onRequestFinished.addListener((request) => {
  if (client) {
    client.onHar(request);
    return;
  }
  harBuffer.push(request);
  if (harBuffer.length > MAX_BUFFER) harBuffer.shift();
});

chrome.devtools.network.onNavigated.addListener((url) => {
  detectGen += 1;
  detectDashboard(0);
  if (client) {
    client.onNavigated(url);
    return;
  }
  if (!isPreserveLog()) harBuffer.length = 0;
});

chrome.runtime?.onMessage?.addListener?.((msg, sender, sendResponse) => {
  const fromTabId = msg?.tabId ?? sender?.tab?.id;
  if (msg?.action === 'IDENTIFY_DEVTOOLS' && fromTabId === chrome.devtools?.inspectedWindow?.tabId && dashboardActive) {
    handleIdentifyDevtools();
    sendResponse?.({ ok: true });
  }
});

detectDashboard(0);
