const KEYWORDS = new Set(
  'async await break case catch class const continue debugger default delete do else export extends finally for function if import in instanceof let new of return static super switch this throw try typeof var void while with yield'.split(' '),
);
const LITERALS = new Set(['true', 'false', 'null', 'undefined', 'NaN', 'Infinity']);
const REGEX_PREV_KEYWORDS = new Set(['return', 'throw', 'case', 'in', 'of', 'typeof', 'void', 'delete', 'await', 'yield', 'else', 'do', 'new']);
const REGEX_LIT_RE = /\/(?:\\.|\[(?:\\.|[^\]\\\n])*\]|[^\/\\\n])+\/[dgimsuvy]*/y;
const JS_RULES = [
  ['comment', /\/\/[^\n]*|\/\*[\s\S]*?(?:\*\/|$)/y],
  ['string', /"(?:\\.|[^"\\\n])*"?|'(?:\\.|[^'\\\n])*'?|`(?:\\[\s\S]|[^`\\])*`?/y],
  ['number', /(?:0[xX][\da-fA-F]+|\d[\d_]*(?:\.\d+)?(?:[eE][+-]?\d+)?)(?![\w$])/y],
  ['word', /[A-Za-z_$][\w$]*/y],
  ['space', /\s+/y],
  ['punct', /[^\sA-Za-z_$\d"'`]/y],
];
const CSS_RULES = [
  ['comment', /\/\*[\s\S]*?(?:\*\/|$)/y],
  ['string', /"[^"\n]*"?|'[^'\n]*'?/y],
  ['property', /[\w-]+(?=\s*:[^:])/y],
  ['number', /#[\da-fA-F]{3,8}(?![\w-])|-?\d*\.?\d+(?:px|em|rem|%|vh|vw|ms|s|deg|fr)?(?![\w-])/y],
  ['plain', /[\w-]+/y],
  ['space', /\s+/y],
  ['punct', /./y],
];
const TAG_RULES = [
  ['tag', /<\/?[A-Za-z][\w:-]*|\/?>/y],
  ['string', /"[^"]*"?|'[^']*'?/y],
  ['attr', /[^\s"'<>\/=]+/y],
  ['space', /\s+/y],
  ['punct', /./y],
];

function scan(text, rules, at = 0, end = text.length) {
  const tokens = [];
  for (let i = at; i < end; ) {
    const [type, value] = rules.reduce((found, [t, re]) => {
      if (found) return found;
      re.lastIndex = i;
      const m = re.exec(text);
      return m && m[0] && m.index === i ? [t, m[0].slice(0, end - i)] : null;
    }, null) ?? ['plain', text[i]];
    tokens.push({ type, text: value });
    i += value.length;
  }
  return tokens;
}

const NEXT_RE = /\s*(\S)?/y;

function nextChar(text, from) {
  NEXT_RE.lastIndex = from;
  return NEXT_RE.exec(text)?.[1] ?? '';
}

function canStartRegex(prev) {
  if (!prev || REGEX_PREV_KEYWORDS.has(prev)) return true;
  return '[({,;:!?&|~^+-*%<>='.includes(prev);
}

function scanJs(text, json) {
  const tokens = [];
  let prev = '';
  for (let i = 0; i < text.length; ) {
    if (!json && text[i] === '/' && text[i + 1] !== '/' && text[i + 1] !== '*' && canStartRegex(prev)) {
      REGEX_LIT_RE.lastIndex = i;
      const rm = REGEX_LIT_RE.exec(text);
      if (rm) {
        tokens.push({ type: 'regex', text: rm[0] });
        prev = rm[0];
        i += rm[0].length;
        continue;
      }
    }
    const [rawType, value] = JS_RULES.reduce((found, [t, re]) => {
      if (found) return found;
      re.lastIndex = i;
      const m = re.exec(text);
      return m && m[0] && m.index === i ? [t, m[0]] : null;
    }, null) ?? ['plain', text[i]];
    i += value.length;
    let type = rawType;
    if (rawType === 'word') {
      const next = nextChar(text, i);
      if (KEYWORDS.has(value)) type = 'keyword';
      else if (LITERALS.has(value)) type = 'literal';
      else if (next === '(') type = 'function';
      else if (prev === '.') type = 'property';
      else type = 'plain';
    } else if (rawType === 'string' && json && nextChar(text, i) === ':') {
      type = 'property';
    }
    if (rawType !== 'space') prev = value;
    tokens.push({ type, text: value });
  }
  return tokens;
}

function scanHtml(text) {
  const tokens = [];
  const re = /<!--[\s\S]*?(?:-->|$)|<\/?[A-Za-z][^>]*>?|[^<]+|</g;
  for (const m of text.matchAll(re)) {
    if (m[0].startsWith('<!--')) tokens.push({ type: 'comment', text: m[0] });
    else if (/^<\/?[A-Za-z]/.test(m[0])) tokens.push(...scan(m[0], TAG_RULES));
    else tokens.push({ type: 'plain', text: m[0] });
  }
  return tokens;
}

function rawTokens(text, kind) {
  if (kind === 'html' || kind === 'xml') return scanHtml(text);
  if (kind === 'css') {
    let depth = 0;
    return scan(text, CSS_RULES).map((t) => {
      if (t.text === '{') depth += 1;
      if (t.text === '}') depth = Math.max(0, depth - 1);
      return !depth && (t.type === 'property' || t.type === 'plain') ? { type: 'tag', text: t.text } : t;
    });
  }
  return scanJs(text, kind === 'json');
}

export function tokenize(text, kind = 'js') {
  return rawTokens(text, kind).map((t) => (t.type === 'space' || t.type === 'punct' ? { type: 'plain', text: t.text } : t));
}

export function tokenLines(text, kind = 'js') {
  const lines = [[]];
  for (const tok of tokenize(text, kind)) {
    tok.text.split('\n').forEach((part, i) => {
      if (i) lines.push([]);
      if (part) lines.at(-1).push({ type: tok.type, text: part });
    });
  }
  return lines;
}
