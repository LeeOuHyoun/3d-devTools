import { fileKind, stripQuery } from './core.js';
import { resources, setupIdentify } from './devtools-lib.js';
import { base64ToBuffer, collectGlyphSources, filterGlyphs } from './glyph-tools.js';
import { iconSvg, setIcon } from './icons.js';
import { applyTheme, copyWithFeedback, el, makeClearable, renderHelp, setPressed, transitionLayout } from './view.js';
import { setupInfo } from './info.js';

const KEYS = { family: '3di.glyphs.family', size: '3di.glyphs.size', sourcesOpen: '3di.glyphs.sourcesOpen' };
const NAV_RELOAD_MS = 1500;
const FONT_STATES = {
  loading: '글꼴 읽는 중',
  page: '화면에서 읽은 글꼴',
  server: '서버에서 받은 글꼴',
  failed: '글꼴을 받지 못함 (이름만 표시)',
  none: '이 화면에서 로드되지 않음',
};
const USAGE = [
  '화면(iframe 포함)에 로드된 아이콘 CSS(wux-3ds-fonticons.css, UIKIT.css, UWA icons.css 등)를 읽어 아이콘 이름과 코드를 보여줍니다. 서버에 있는 그 버전 그대로입니다.',
  '글꼴은 화면이 이미 받은 파일을 쓰고, 화면에 아직 쓰이지 않아 받지 않은 글꼴은 CSS에 적힌 주소에서 받습니다.',
  '같은 아이콘 CSS가 여러 곳에서 로드되면 글꼴 줄에서 출처를 고릅니다. 기본은 3DSpace webapps 쪽입니다.',
  '아이콘을 누르면 오른쪽에 클래스 이름과 컨트롤에서 지정하는 코드가 나오고, 복사할 수 있습니다.',
  '위젯을 연 뒤에 로드된 CSS나 글꼴은 다시 읽기 단추로 반영합니다.',
];
const $ = (id) => document.getElementById(id);

function load(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw === null ? fallback : JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function save(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {}
}

const state = { family: load(KEYS.family, 'all'), size: load(KEYS.size, 28), sourcesOpen: load(KEYS.sourcesOpen, true), query: '', groups: [], selected: null, loading: false };
const faces = new Map();
let generation = 0;
let queryTimer = null;

function contentOf(resource) {
  return new Promise((resolve) => resource.getContent((content, encoding) => resolve({ content: content ?? null, encoding: encoding ?? '' })));
}

function fileName(url) {
  return stripQuery(url).split('/').at(-1);
}

async function applyFace(group, buffer) {
  try {
    const face = await new FontFace(`3di-glyph-${group.family.id}`, buffer).load();
    if (faces.has(group.family.id)) document.fonts.delete(faces.get(group.family.id));
    document.fonts.add(face);
    faces.set(group.family.id, face);
    return true;
  } catch {
    return false;
  }
}

async function readFont(group, list, gen) {
  const source = group.sources[group.pick];
  const done = (font, fontUrl = '') => {
    if (gen !== generation) return;
    Object.assign(group, { font, fontUrl });
    render();
  };
  if (!source) return done('none');
  done('loading');
  for (const url of source.fontUrls) {
    const resource = list.find((r) => stripQuery(r.url) === stripQuery(url));
    if (!resource) continue;
    const { content, encoding } = await contentOf(resource);
    if (content && encoding === 'base64' && (await applyFace(group, base64ToBuffer(content)))) return done('page', url);
  }
  for (const url of source.fontUrls) {
    try {
      const res = await fetch(url, { credentials: 'include' });
      if (res.ok && (await applyFace(group, await res.arrayBuffer()))) return done('server', url);
    } catch {}
  }
  done('failed');
}

async function reload() {
  const gen = ++generation;
  state.loading = true;
  state.selected = null;
  render();
  const list = (await resources()).filter((r) => /^https?:/i.test(r.url));
  const cssList = [...new Map(list.filter((r) => fileKind(r.url, r.type) === 'css').map((r) => [stripQuery(r.url), r])).values()];
  const sheets = await Promise.all(cssList.map(async (r) => ({ url: r.url, text: (await contentOf(r)).content })));
  if (gen !== generation) return;
  state.groups = collectGlyphSources(sheets.filter((s) => s.text)).map((g) => ({ ...g, pick: 0, font: g.sources.length ? 'loading' : 'none', fontUrl: '' }));
  state.loading = false;
  render();
  state.groups.forEach((g) => readFont(g, list, gen));
  reload.list = list;
}

function iconsOf(group) {
  return group.sources[group.pick]?.icons ?? [];
}

function familyFlags(group) {
  const failed = group.font === 'failed';
  const multi = group.sources.length > 1;
  const flags = [];
  if (failed) flags.push(Object.assign(el('span', 'flag flag-failed'), { title: FONT_STATES.failed }));
  if (multi) {
    const flag = el('span', 'flag flag-multi');
    flag.innerHTML = iconSvg('gitFork', 11);
    flags.push(flag);
  }
  return flags;
}

function familyTitle(group) {
  const source = group.sources[group.pick];
  if (!source) return `${group.family.label} · ${FONT_STATES.none}`;
  const parts = [group.family.label, FONT_STATES[group.font], `출처: ${new URL(source.url).pathname}`];
  if (group.sources.length > 1) parts.push(`출처 ${group.sources.length}곳 중 선택 가능`);
  return parts.join('\n');
}

function renderFamilies() {
  const total = state.groups.reduce((sum, g) => sum + iconsOf(g).length, 0);
  const allButton = el('button', null, '전체', el('span', 'n', String(total)));
  allButton.dataset.family = 'all';
  const buttons = [
    allButton,
    ...state.groups.map((g) => {
      const button = el('button', null, g.family.label, el('span', 'n', String(iconsOf(g).length)), ...familyFlags(g));
      button.dataset.family = g.family.id;
      button.title = familyTitle(g);
      return button;
    }),
  ];
  buttons.forEach((button) => setPressed(button, state.family === button.dataset.family));
  $('families').replaceChildren(...buttons);
}

function syncSourcesToggle() {
  const button = $('sourcesToggleBtn');
  const failed = state.groups.filter((g) => g.font === 'failed').length;
  const multi = state.groups.filter((g) => g.sources.length > 1).length;
  const notes = [failed && `실패 ${failed}`, multi && `선택 ${multi}`].filter(Boolean);
  const summary = !state.sourcesOpen && notes.length ? `<span class="source-summary">· ${notes.join(' · ')}</span>` : '';
  $('sources').hidden = !state.sourcesOpen;
  button.setAttribute('aria-expanded', String(state.sourcesOpen));
  button.classList.toggle('source-warn', !state.sourcesOpen && failed > 0);
  button.title = state.sourcesOpen ? '글꼴 출처 접기' : '글꼴 출처 펼치기';
  button.innerHTML = `<span>출처</span>${summary}${iconSvg(state.sourcesOpen ? 'chevronUp' : 'chevronDown', 13)}`;
}

function renderSources() {
  $('sources').replaceChildren(
    ...state.groups.map((g) => {
      const source = g.sources[g.pick];
      const row = el('div', `source-row font-${g.font}`, el('span', 'source-label', g.family.label), el('span', 'source-state', FONT_STATES[g.font]));
      if (!source) return row;
      if (g.sources.length > 1) {
        const select = el('select', 'styled-select', ...g.sources.map((s, i) => Object.assign(el('option', null, `${new URL(s.url).pathname} (${s.icons.length})`), { value: String(i), title: s.url })));
        select.value = String(g.pick);
        select.dataset.family = g.family.id;
        select.title = source.url;
        row.append(select);
      } else {
        row.append(Object.assign(el('span', 'source-url muted', fileName(source.url)), { title: source.url }));
      }
      if (g.fontUrl) row.append(Object.assign(el('span', 'source-url muted', `글꼴: ${fileName(g.fontUrl)}`), { title: g.fontUrl }));
      return row;
    }),
  );
}

function card(group, [name, code], ready) {
  const button = el('button', 'glyph-card', ready ? el('span', 'glyph', String.fromCodePoint(code)) : null, el('span', 'glyph-name', name));
  if (ready) button.firstChild.style.fontFamily = `"3di-glyph-${group.family.id}"`;
  button.dataset.family = group.family.id;
  button.dataset.name = name;
  button.title = name;
  if (state.selected?.family === group.family.id && state.selected.name === name) button.classList.add('on');
  return button;
}

function renderList() {
  const list = $('list');
  list.style.setProperty('--glyph-size', `${state.size}px`);
  if (state.loading) return list.replaceChildren(el('div', 'muted pad', '화면의 CSS를 읽는 중…'));
  if (!state.groups.some((g) => g.sources.length)) {
    renderHelp(list, ['이 화면에서 아이콘 CSS를 찾지 못했습니다. 위젯이 열린 탭인지 확인하고 다시 읽기를 누르세요.', ...USAGE]);
    return;
  }
  const sections = state.groups
    .filter((g) => state.family === 'all' || g.family.id === state.family)
    .map((g) => ({ g, icons: filterGlyphs(iconsOf(g), state.query) }))
    .filter(({ icons }) => icons.length);
  if (!sections.length) return list.replaceChildren(el('div', 'muted pad', state.query ? '찾는 아이콘이 없습니다.' : '이 글꼴은 이 화면에서 로드되지 않았습니다.'));
  list.replaceChildren(
    ...sections.map(({ g, icons }) => {
      const ready = g.font === 'page' || g.font === 'server';
      const grid = el('div', 'glyph-grid', ...icons.map((icon) => card(g, icon, ready)));
      return el('section', 'group', el('h3', 'group-head', el('span', null, g.family.label), el('span', 'muted', `${icons.length}개`)), grid);
    }),
  );
}

function selectGlyph(next, cardEl = null) {
  const changed = Boolean(state.selected) !== Boolean(next);
  transitionLayout(() => {
    state.selected = next;
    $('list').querySelectorAll('.glyph-card.on').forEach((n) => n.classList.remove('on'));
    cardEl?.classList.add('on');
    renderDetail();
  }, changed);
}

function renderDetail() {
  const box = $('detail');
  const group = state.selected && state.groups.find((g) => g.family.id === state.selected.family);
  const icon = group && iconsOf(group).find(([name]) => name === state.selected.name);
  box.hidden = !icon;
  if (!icon) return box.replaceChildren();
  const [name, code] = icon;
  const ready = group.font === 'page' || group.font === 'server';
  const close = setIcon(el('button', 'icon detail-close'), 'x', 13);
  close.title = '닫기';
  const big = ready ? el('div', 'glyph-big', String.fromCodePoint(code)) : null;
  if (big) big.style.fontFamily = `"3di-glyph-${group.family.id}"`;
  const usageRows = [['이름', name], ...group.family.usage(name)].map(([label, text]) => {
    const copy = setIcon(el('button', 'icon'), 'copy', 12);
    copy.title = '복사';
    copy.addEventListener('click', () => copyWithFeedback(copy, text, { iconOnly: true }));
    return el('div', 'usage-row', el('div', 'usage-head', el('span', null, label), copy), el('code', null, text));
  });
  const source = group.sources[group.pick];
  box.replaceChildren(
    close,
    big,
    el('div', 'detail-name', name),
    el('div', 'muted', `${group.family.label} · \\${code.toString(16)}`),
    ...usageRows,
    Object.assign(el('div', 'muted detail-src', `CSS: ${fileName(source.url)}`), { title: source.url }),
  );
  close.addEventListener('click', () => selectGlyph(null));
}

function renderStatus() {
  const visible = state.groups.filter((g) => state.family === 'all' || g.family.id === state.family);
  const shown = visible.reduce((sum, g) => sum + filterGlyphs(iconsOf(g), state.query).length, 0);
  const loaded = state.groups.filter((g) => g.sources.length);
  const ready = loaded.filter((g) => g.font === 'page' || g.font === 'server').length;
  $('status').textContent = state.loading ? '읽는 중…' : `아이콘 ${shown}개  ·  아이콘 CSS ${loaded.length}종  ·  글꼴 ${ready}/${loaded.length}`;
}

function render() {
  renderFamilies();
  syncSourcesToggle();
  renderSources();
  renderList();
  renderDetail();
  renderStatus();
}

function bindEvents() {
  $('families').addEventListener('click', (e) => {
    const button = e.target.closest('button[data-family]');
    if (!button || state.family === button.dataset.family) return;
    transitionLayout(() => {
      state.family = button.dataset.family;
      save(KEYS.family, state.family);
      render();
    });
  });
  $('sourcesToggleBtn').addEventListener('click', () => {
    transitionLayout(() => {
      state.sourcesOpen = !state.sourcesOpen;
      save(KEYS.sourcesOpen, state.sourcesOpen);
      syncSourcesToggle();
    });
  });
  $('sources').addEventListener('change', (e) => {
    const group = state.groups.find((g) => g.family.id === e.target.dataset.family);
    if (!group) return;
    const hadDetail = Boolean(state.selected);
    group.pick = Number(e.target.value);
    state.selected = null;
    transitionLayout(() => {
      readFont(group, reload.list ?? [], generation);
    }, hadDetail);
  });
  $('query').addEventListener('input', () => {
    clearTimeout(queryTimer);
    queryTimer = setTimeout(() => {
      state.query = $('query').value;
      render();
    }, 120);
  });
  $('size').addEventListener('input', () => {
    state.size = Number($('size').value);
    $('sizeValue').textContent = `${state.size}px`;
    save(KEYS.size, state.size);
    $('list').style.setProperty('--glyph-size', `${state.size}px`);
  });
  $('list').addEventListener('click', (e) => {
    const button = e.target.closest('.glyph-card');
    if (!button) return;
    selectGlyph({ family: button.dataset.family, name: button.dataset.name }, button);
  });
  $('reloadBtn').addEventListener('click', reload);
  chrome.devtools?.network?.onNavigated?.addListener(() => {
    generation += 1;
    setTimeout(reload, NAV_RELOAD_MS);
  });
}

applyTheme();
setupInfo(document.querySelector('.status-bar'));
setupIdentify();
syncSourcesToggle();
$('reloadBtn').innerHTML = `${iconSvg('refresh', 13)}<span>다시 읽기</span>`;
$('size').value = String(state.size);
$('sizeValue').textContent = `${state.size}px`;
makeClearable($('query'), { inline: true });
bindEvents();
reload();
