import { buildModuleIndex, fileKind, fileMatcher, getLineStarts, isTargetUrl, resolveFrames, stripQuery } from './core.js';

const LINK_RE = /(\b[\w.-]+\.(?:js|html?|json|css):\d+:\d+\b)|(\bDS\/[\w./-]+[\w/-])/g;
const DASHBOARD_URL_RE = /\/3ddashboard(?:\/|$|\?)|\/webapps\/(?:(?:AmdLoader|UWA\d*|Dashboard|TopBar|Compass|Platform)(?:\/|$)|ENOCh(?:g|ange)|DS\/)/i;
const SCOPE_KEY = '3di.scope';
const ACTION_KEY = '3di.pendingAction';
const BUS_NAME = '3di-bus';
const MODULE_BUS = '3di-module';
const MODULE_KEY = '3di.currentModule';
const FRAME_REFRESH_MS = 2000;
export const FILE_KINDS = ['js', 'html', 'json', 'css'];
export const DETECT_DASHBOARD_EXPR = `(() => {
  try {
    if (/\\/3ddashboard(?:\\/|$|\\?)/i.test(location.pathname)) return true;
    if (typeof UWA === 'object' && UWA && (typeof UWA.is === 'function' || UWA.Environment || UWA.Widgets)) return true;
    const defined = globalThis.require?.s?.contexts?._?.defined;
    if (defined && Object.keys(defined).some((k) => k.startsWith('DS/'))) return true;
    if (typeof ds === 'object' && ds && typeof widget === 'object' && widget) return true;
    return false;
  } catch {
    return false;
  }
})()`;
const bundleCache = new Map();

export function isDashboardResourceUrl(url = '') {
  return DASHBOARD_URL_RE.test(stripQuery(url));
}

globalThis.chrome?.devtools?.network?.onNavigated?.addListener(() => bundleCache.clear());

export function clearBundleCache() {
  bundleCache.clear();
}

export function evalIn(expression, frameURL) {
  return new Promise((resolve, reject) => {
    chrome.devtools.inspectedWindow.eval(expression, frameURL ? { frameURL } : {}, (value, error) => {
      if (error) reject(new Error(error.isException ? error.value : error.description));
      else resolve(value);
    });
  });
}

export function resources() {
  return new Promise((resolve) => chrome.devtools.inspectedWindow.getResources(resolve));
}

function contentOf(resource) {
  return new Promise((resolve) => resource.getContent((content) => resolve(content ?? null)));
}

export function fileScope() {
  try {
    const saved = JSON.parse(localStorage.getItem(SCOPE_KEY) ?? '{}');
    return { names: String(saved.names ?? ''), mode: saved.mode ?? 'contains', kinds: Array.isArray(saved.kinds) ? saved.kinds : FILE_KINDS };
  } catch {
    return { names: '', mode: 'contains', kinds: FILE_KINDS };
  }
}

export function setFileScope(scope) {
  try {
    localStorage.setItem(SCOPE_KEY, JSON.stringify(scope));
  } catch {}
}

function nameOf(url) {
  const key = stripQuery(url);
  return key.split('/').at(-1) || key;
}

export async function loadBundles(scope = fileScope()) {
  const matcher = fileMatcher(scope.names, scope.mode);
  if (matcher.error) throw new Error(`파일 이름 정규식 오류: ${matcher.error}`);
  const bundles = await readBundles((r) => scope.kinds.includes(fileKind(r.url, r.type)) && matcher.test(nameOf(r.url)));
  return [...bundles.filter((b) => isTargetUrl(b.url)), ...bundles.filter((b) => !isTargetUrl(b.url))];
}

export function cachedBundles() {
  const bundles = [...bundleCache.values()];
  return [...bundles.filter((b) => isTargetUrl(b.url)), ...bundles.filter((b) => !isTargetUrl(b.url))];
}

export async function readBundles(select) {
  const list = (await resources()).filter((r) => /^https?:/i.test(r.url) && select(r));
  const unique = [...new Map(list.map((r) => [stripQuery(r.url), r])).values()];
  await Promise.all(
    unique.map(async (r) => {
      const key = stripQuery(r.url);
      if (bundleCache.has(key)) return;
      const text = await contentOf(r);
      if (typeof text !== 'string') return;
      const kind = fileKind(r.url, r.type);
      bundleCache.set(key, { url: r.url, name: nameOf(r.url), kind, text, modules: kind === 'js' ? buildModuleIndex(text, r.url) : [], lineStarts: getLineStarts(text) });
    }),
  );
  return unique.map((r) => bundleCache.get(stripQuery(r.url))).filter(Boolean);
}

export async function findBundle(id) {
  const has = (b) => b.modules.some((m) => m.id === id);
  return [...bundleCache.values()].find(has) ?? (await readBundles((r) => fileKind(r.url, r.type) === 'js')).find(has) ?? null;
}

export async function findBundleByFile(name) {
  const [bundle] = await readBundles((r) => fileKind(r.url, r.type) !== null && nameOf(r.url) === name);
  return bundle ?? null;
}

export async function resolveStacks(stacks) {
  const urls = new Set(stacks.flat().map((f) => stripQuery(f.url)));
  const bundles = await readBundles((r) => urls.has(stripQuery(r.url)));
  return stacks.map((frames) => resolveFrames(bundles, frames));
}

export async function documentUrls() {
  return (await resources()).filter((r) => r.type === 'document').map((r) => r.url);
}

export function createFramePoller(name, onResults) {
  const cursors = new Map();
  let frames = [undefined];
  let refreshedAt = 0;
  let busy = false;
  let queued = false;
  const refresh = async (force) => {
    const now = Date.now();
    if (!force && now - refreshedAt < FRAME_REFRESH_MS) return;
    refreshedAt = now;
    frames = [undefined, ...new Set(await documentUrls().catch(() => []))];
  };
  const track = async (enabled) => {
    await refresh(true);
    await Promise.all(frames.map((url) => evalIn(`window.__3di?.${name}Track?.(${enabled})`, url).catch(() => null)));
  };
  const tick = async () => {
    if (busy) {
      queued = true;
      return;
    }
    busy = true;
    try {
      await refresh(false);
      const results = await Promise.all(
        frames.map(async (frameUrl) => {
          const key = frameUrl ?? '__top__';
          const cursor = cursors.get(key) ?? { epoch: '', seq: -1 };
          const res = await evalIn(`window.__3di?.${name}Drain ? window.__3di.${name}Drain(${cursor.seq}, ${JSON.stringify(cursor.epoch)}) : null`, frameUrl).catch(() => null);
          if (!res) return null;
          if (res.enabled === false) evalIn(`window.__3di?.${name}Track?.(true)`, frameUrl).catch(() => null);
          cursors.set(key, { epoch: res.epoch, seq: res.seq });
          return { frameUrl, res };
        }),
      );
      onResults(results.filter(Boolean));
    } finally {
      busy = false;
      if (queued) {
        queued = false;
        tick();
      }
    }
  };
  const reset = () => {
    cursors.clear();
    refreshedAt = 0;
  };
  return { track, tick, reset };
}

export async function selectionFrame() {
  for (const url of [undefined, ...new Set(await documentUrls())]) {
    const selected = await evalIn('typeof $0 !== "undefined" && $0 instanceof Node && $0.ownerDocument === document', url).catch(() => false);
    if (selected) return { url };
  }
  return null;
}

export async function openSourceLocation(fileName, line, column) {
  if (!chrome.devtools?.panels?.openResource) return false;
  const list = await resources();
  const target = list.find((r) => {
    const clean = stripQuery(r.url);
    return clean === fileName || clean.endsWith(`/${fileName}`);
  });
  if (!target) return false;
  const lineIndex = Math.max(0, Number(line) - 1);
  try {
    chrome.devtools.panels.openResource(target.url, lineIndex, Math.max(0, Number(column) - 1), () => {});
  } catch {
    chrome.devtools.panels.openResource(target.url, lineIndex, () => {});
  }
  return true;
}

export function renderLinkedText(container, text, { onModule, onLocation = openSourceLocation } = {}) {
  const raw = String(text ?? '');
  container.replaceChildren();
  let last = 0;
  for (const m of raw.matchAll(LINK_RE)) {
    if (m.index > last) container.append(raw.slice(last, m.index));
    const token = m[0];
    const a = document.createElement('a');
    a.textContent = token;
    a.href = '#';
    if (m[1]) {
      const [file, line, column] = token.split(':');
      a.className = 'link-loc';
      a.title = '이 위치의 코드 보기';
      a.addEventListener('click', (e) => {
        e.preventDefault();
        onLocation(file, line, column);
      });
    } else {
      a.className = 'link-mod';
      a.title = '이 모듈 코드 보기 (이름 풀기)';
      a.addEventListener('click', (e) => {
        e.preventDefault();
        onModule?.(token);
      });
    }
    container.append(a);
    last = m.index + token.length;
  }
  if (last < raw.length) container.append(raw.slice(last));
}

export function sendInspectorAction(action) {
  const payload = { ...action, ts: Date.now() };
  try {
    localStorage.setItem(ACTION_KEY, JSON.stringify(payload));
  } catch {}
  try {
    const ch = new BroadcastChannel(BUS_NAME);
    ch.postMessage(payload);
    ch.close();
  } catch {}
}

export function consumeInspectorAction() {
  try {
    const raw = localStorage.getItem(ACTION_KEY);
    if (!raw) return null;
    localStorage.removeItem(ACTION_KEY);
    const parsed = JSON.parse(raw);
    return Date.now() - (parsed?.ts ?? 0) < 120000 ? parsed : null;
  } catch {
    return null;
  }
}

export function listenInspectorAction(onAction, { replay = true } = {}) {
  const pending = replay ? consumeInspectorAction() : null;
  if (pending) onAction(pending);
  if (typeof BroadcastChannel === 'undefined') return () => {};
  const ch = new BroadcastChannel(BUS_NAME);
  ch.addEventListener('message', (e) => {
    try {
      localStorage.removeItem(ACTION_KEY);
    } catch {}
    if (e.data) onAction(e.data);
  });
  return () => ch.close();
}

export function announceModule(id) {
  try {
    localStorage.setItem(MODULE_KEY, id);
  } catch {}
  try {
    const ch = new BroadcastChannel(MODULE_BUS);
    ch.postMessage(id);
    ch.close();
  } catch {}
}

export function lastAnnouncedModule() {
  try {
    return localStorage.getItem(MODULE_KEY);
  } catch {
    return null;
  }
}

export function listenModuleAnnounce(onModule) {
  if (typeof BroadcastChannel === 'undefined') return;
  new BroadcastChannel(MODULE_BUS).addEventListener('message', (e) => e.data && onModule(e.data));
}

export function showLocateOverlay(doc = document) {
  const root = doc.body || doc.documentElement;
  if (!root) return;
  const view = doc.defaultView || window;
  const prev = doc.getElementById('_3di_locate_overlay');
  if (prev && Date.now() - Number(prev.dataset.ts || 0) < 150) return;
  prev?.remove();
  const box = doc.createElement('div');
  box.id = '_3di_locate_overlay';
  box.dataset.ts = String(Date.now());
  Object.assign(box.style, {
    position: 'fixed',
    bottom: 'clamp(12px, 4vh, 40px)',
    left: 'clamp(12px, 4vw, 40px)',
    width: 'min(220px, calc(100vw - 24px))',
    height: 'min(220px, calc(100vh - 24px))',
    backgroundColor: 'rgba(13, 56, 87, 0.88)',
    border: '1px solid rgba(255, 255, 255, 0.2)',
    borderRadius: '36px',
    boxShadow: '0 12px 32px rgba(0, 0, 0, 0.35)',
    zIndex: '2147483647',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    color: 'white',
    font: '600 13px/1.2 system-ui, sans-serif',
    pointerEvents: 'none',
    opacity: '0',
    transform: 'scale(0.6)',
    transition: 'opacity 0.35s ease, transform 0.35s cubic-bezier(0.34, 1.56, 0.64, 1)',
  });
  const label = doc.createElement('span');
  label.textContent = '3D Inspector';
  box.innerHTML = '<svg width="132" height="132" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="2" y1="12" x2="5" y2="12"/><line x1="19" y1="12" x2="22" y2="12"/><line x1="12" y1="2" x2="12" y2="5"/><line x1="12" y1="19" x2="12" y2="22"/><circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="3"/></svg>';
  box.append(label);
  root.append(box);
  const reveal = () => {
    box.style.opacity = '1';
    box.style.transform = 'scale(1)';
  };
  view.requestAnimationFrame(reveal);
  view.setTimeout(reveal, 40);
  view.setTimeout(() => {
    box.style.opacity = '0';
    box.style.transform = 'scale(1.15)';
    view.setTimeout(() => box.remove(), 350);
  }, 1800);
}

export function focusDevtoolsWindow() {
  if (document.activeElement && document.activeElement.tagName !== 'BODY') {
    document.activeElement.blur?.();
  }
  chrome.windows?.getCurrent?.((win) => {
    if (chrome.runtime?.lastError || !win?.id) return;
    const props = win.state === 'minimized' ? { focused: true, state: 'normal' } : { focused: true };
    chrome.windows.update(win.id, props);
    chrome.runtime?.sendMessage?.({ action: 'FOCUS_DEVTOOLS_WINDOW', windowId: win.id }, () => {
      void chrome.runtime?.lastError;
    });
  });
}

export function identifyTargetTab() {
  const tabId = chrome.devtools?.inspectedWindow?.tabId;
  if (tabId == null) return;
  const fallbackOverlay = () => evalIn(`(${showLocateOverlay})()`).catch(() => {});
  if (!chrome.runtime?.sendMessage) return fallbackOverlay();
  chrome.runtime.sendMessage({ action: 'FOCUS_TAB', tabId }, (res) => {
    if (chrome.runtime?.lastError || !res?.overlaySent) fallbackOverlay();
  });
}

export function setupIdentify() {
  let lastMenuAt = 0;
  const tabId = chrome.devtools?.inspectedWindow?.tabId;
  if (tabId != null) {
    chrome.runtime?.sendMessage?.({ action: 'REGISTER_DEVTOOLS_TAB', tabId }, () => {
      void chrome.runtime?.lastError;
    });
  }
  window.addEventListener(
    'keydown',
    (e) => {
      if (!e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
      if (e.code !== 'KeyA' && e.key !== 'a' && e.key !== 'A') return;
      e.preventDefault();
      e.stopPropagation();
      identifyTargetTab();
    },
    true,
  );
  window.addEventListener('contextmenu', () => {
    lastMenuAt = Date.now();
  }, true);
  window.addEventListener('blur', () => {
    lastMenuAt = 0;
  });
  chrome.runtime?.onMessage?.addListener?.((msg, sender, sendResponse) => {
    if (msg?.action === 'IDENTIFY_TAB') {
      if (document.hasFocus() || (lastMenuAt && Date.now() - lastMenuAt < 10000)) {
        lastMenuAt = 0;
        identifyTargetTab();
      }
      return;
    }
    const fromTabId = msg?.tabId ?? sender?.tab?.id;
    if (msg?.action === 'IDENTIFY_DEVTOOLS' && fromTabId === tabId) {
      focusDevtoolsWindow();
      if (!document.hidden) showLocateOverlay(document);
      sendResponse?.({ ok: true });
    }
  });
}
