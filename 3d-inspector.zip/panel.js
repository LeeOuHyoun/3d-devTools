import { announceModule, cachedBundles, clearBundleCache, consumeInspectorAction, fileScope, findBundle, findBundleByUrl, listenInspectorAction, loadBundles, openSourceLocation, renderLinkedText, setFileScope, setupIdentify } from './devtools-lib.js';
import { toLineColumn, toOffset } from './core.js';
import { iconSvg, setIcon } from './icons.js';
import { setupInfo } from './info.js';
import { buildNlsIndex, bundleSummary, generatedLineToOffset, listModules, matchLengthAt, moduleOutline, moduleRelations, moduleView, offsetToGeneratedLine, originalView, searchMatcher, searchResults } from './tools.js';
import { applyTheme, bindResizer, copyWithFeedback, createFinder, el, highlightCodeLine, makeClearable, renderCode, renderHelp, renderResults, scrollToRow, setPressed, syncClearButton, togglePressed, transitionLayout } from './view.js';

const USAGE = [
  '검색어를 넣고 Enter. 방식(포함, 시작, 끝, 단어, 정규식)과 Aa(대소문자 구분)를 고를 수 있습니다.',
  '기본은 페이지에 로드된 파일 전체입니다. 파일 이름(쉼표 구분)과 종류(JS, HTML, JSON, CSS)로 좁힐 수 있습니다. ENOChg, ENOChange 파일의 결과가 먼저 나옵니다.',
  '결과 줄을 누르면 아래 왼쪽에 원본 코드, 오른쪽에 포맷 또는 이름 풀기 코드가 같은 위치로 열립니다. 줄 번호를 누르면 반대쪽 같은 위치로 맞춥니다.',
  '모듈 칸(Ctrl+K)에서 로드된 모듈을 자동완성으로 바로 열 수 있고, 오른쪽 헤더의 목차·의존 버튼으로 함수·이벤트·의존 모듈을 이동합니다.',
  '화면 요소에서 찾기: Elements 탭에서 요소를 선택(Ctrl+Shift+C)하고 오른쪽 사이드바의 "3D Inspector"를 봅니다.',
  '크롬 링크로 열기: 개발자도구 설정(F1) › Preferences › Extensions의 "Link handling"을 "3D Inspector"로 고르면, 크롬 Console·Network 등의 JS 파일:줄 링크를 눌렀을 때 이 탭이 열리며 그 위치로 갑니다. JS가 아닌 파일은 Sources에서 엽니다. 되돌리려면 "auto"로 고릅니다.',
];
const MIN_PANE_WIDTH = 260;
const MIN_PANE_HEIGHT = 100;
const HISTORY_KEY = '3di.history';
const EXTRA_HIDDEN_KEY = '3di.panel.hideFilters';
const MAX_HISTORY = 12;
const LOADING = '읽는 중...';
const $ = (id) => document.getElementById(id);
const out = $('out');
const handlers = { onLocation: showLocation, onModule: (id) => openModule(id), onMore: (limit) => run(() => search(limit)) };
const sourceFinder = createFinder('source', $('source'), $('source'));
const codeFinder = createFinder('code', $('code'), $('codeBody'));
let lastMatcher = null;
let source = null;
let codeTarget = null;
let codeViewData = null;
let selected = null;
let nlsCache = { size: -1, map: new Map() };
let suggestIdx = -1;
let suggestGen = 0;
let jsBundles = null;

function loadHistory() {
  try {
    const raw = JSON.parse(localStorage.getItem(HISTORY_KEY) ?? '[]');
    return Array.isArray(raw) ? raw : [];
  } catch {
    return [];
  }
}

function saveHistory(items) {
  try {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(items));
  } catch {}
  syncHistoryButton();
}

function pushHistory(q) {
  const term = q.trim();
  if (!term) return;
  saveHistory([term, ...loadHistory().filter((item) => item !== term)].slice(0, MAX_HISTORY));
}

function syncHistoryButton() {
  $('historyBtn').hidden = !loadHistory().length;
}

function getNlsMap() {
  const bundles = cachedBundles();
  if (nlsCache.size !== bundles.length) nlsCache = { size: bundles.length, map: buildNlsIndex(bundles) };
  return nlsCache.map;
}

function segValue(id) {
  return $(id).querySelector('.on')?.dataset.value;
}

function setSeg(id, value) {
  $(id).querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.value === value));
}

function bindSeg(id, onChange) {
  $(id).addEventListener('click', (e) => {
    const button = e.target.closest('button');
    if (!button || button.classList.contains('on')) return;
    setSeg(id, button.dataset.value);
    onChange();
  });
}

function scope() {
  return { names: $('files').value, mode: segValue('fileMode'), kinds: [...document.querySelectorAll('.chip.on[data-kind]')].map((c) => c.dataset.kind) };
}

function syncScopeBadge() {
  const s = scope();
  const chips = [...document.querySelectorAll('.chip[data-kind]')];
  const kinds = chips.filter((c) => s.kinds.includes(c.dataset.kind)).map((c) => c.textContent);
  const notes = [
    s.names.trim() && `파일 이름(${$('fileMode').querySelector('.on').textContent}): ${s.names.trim()}`,
    kinds.length < chips.length && `파일 종류: ${kinds.join(', ') || '없음'}`,
  ].filter(Boolean);
  const button = $('toggleScopeBtn');
  button.classList.toggle('scope-active-dot', notes.length > 0);
  button.title = ['파일 · 모듈 필터 접기/펼치기', ...(notes.length ? ['', '적용 중', ...notes] : [])].join('\n');
}

function saveScope() {
  setFileScope(scope());
  syncScopeBadge();
}

function restoreScope() {
  const saved = fileScope();
  $('files').value = saved.names;
  syncClearButton($('files'));
  setSeg('fileMode', saved.mode);
  document.querySelectorAll('.chip[data-kind]').forEach((c) => setPressed(c, saved.kinds.includes(c.dataset.kind)));
  syncScopeBadge();
}

function options() {
  return { mode: segValue('mode'), caseSensitive: $('caseSensitive').classList.contains('on') };
}

function setStatus(text) {
  $('status').textContent = text;
}

async function run(task) {
  const before = $('status').textContent;
  setStatus(LOADING);
  try {
    await task();
  } catch (e) {
    renderResults(out, { error: `오류: ${e.message}` }, handlers);
    setStatus('');
  }
  if ($('status').textContent === LOADING) setStatus(before);
}

async function search(limit) {
  const started = performance.now();
  const query = $('query').value;
  syncClearButton($('query'));
  const matcher = searchMatcher(query, options());
  lastMatcher = matcher.error ? null : matcher;
  const bundles = await loadBundles(scope());
  const result = searchResults(bundles, query, { ...options(), limit });
  if (!result.error) pushHistory(query);
  renderResults(out, result, handlers);
  out.scrollTop = 0;
  const found = result.error ? null : `결과 ${result.total}${result.truncated ? '+' : ''}곳`;
  setStatus([bundles.length ? bundleSummary(bundles) : null, found, `${((performance.now() - started) / 1000).toFixed(2)}초`].filter(Boolean).join('  ·  '));
}

async function intro() {
  renderHelp(out, USAGE);
  const bundles = await loadBundles(scope());
  setStatus(bundles.length ? bundleSummary(bundles) : '검색할 파일 없음');
}

function selectRow(row) {
  selected?.classList.remove('selected');
  selected = row ?? null;
  selected?.classList.add('selected');
}

async function showLocation(url, line, column, row) {
  selectRow(row);
  openLocation(await findBundleByUrl(url), line, column, lastMatcher);
}

function openLocation(bundle, line, column, matcher = null) {
  if (!bundle) return;
  const offset = toOffset(bundle.lineStarts, Number(line), Number(column));
  const inside = offset >= 0 && offset < bundle.text.length;
  openAt(bundle, inside ? offset : 0, inside ? matchLengthAt(bundle.text, offset, matcher) : 0);
}

async function openUrlLocation(url, line, column) {
  const bundle = await findBundleByUrl(url);
  if (!bundle) return renderResults(out, { error: `${url}: 로드된 파일에서 찾지 못했습니다.` }, handlers);
  openLocation(bundle, line, column);
}

async function openModule(id, line = null, column = 1) {
  const bundle = await findBundle(id);
  if (!bundle) return renderResults(out, { error: `${id}: 로드된 파일에서 모듈을 찾지 못했습니다.` }, handlers);
  const mod = bundle.modules.find((m) => m.id === id);
  const offset = line ? toOffset(bundle.lineStarts, Number(line), Number(column)) : mod.start;
  const inside = line && offset >= mod.start && offset < mod.end;
  openAt(bundle, inside ? offset : mod.start, inside ? matchLengthAt(bundle.text, offset, null) : 0);
}

function lineFirstOffset(bundle, lineNo) {
  const start = bundle.lineStarts[Math.max(0, lineNo - 1)] ?? 0;
  const next = bundle.lineStarts[lineNo] ?? bundle.text.length;
  const ws = bundle.text.slice(start, next).match(/^\s*/)?.[0].length ?? 0;
  return start + ws;
}

function syncSourceToCode(lineNo) {
  highlightCodeLine($('source'), lineNo);
  if (!source || !codeViewData?.marks) return;
  const offset = lineFirstOffset(source.bundle, lineNo);
  const genLine = offsetToGeneratedLine(codeViewData.modStart, codeViewData.marks, offset);
  if (!genLine) return;
  scrollToRow($('codeBody'), highlightCodeLine($('code'), genLine));
}

function syncCodeToSource(genLine) {
  highlightCodeLine($('code'), genLine);
  if (!source || !codeViewData?.marks) return;
  const offset = generatedLineToOffset(codeViewData.modStart, codeViewData.marks, genLine);
  const { line } = toLineColumn(source.bundle.lineStarts, offset);
  scrollToRow($('source'), highlightCodeLine($('source'), line));
}

function openAt(bundle, offset, length) {
  const view = originalView(bundle, offset, length);
  const { line, column } = toLineColumn(bundle.lineStarts, offset);
  source = { bundle, line, column, text: view.text };
  $('sourceTitle').textContent = `${bundle.name}:${line}:${column}`;
  const focus = renderCode($('source'), view.text, {
    kind: bundle.kind ?? 'js',
    firstLine: view.firstLine,
    focusLine: length ? view.line : null,
    mark: view.mark,
    nlsMap: getNlsMap(),
    onLineClick: syncSourceToCode,
  });
  sourceFinder.refresh();
  scrollToRow($('source'), focus);
  codeTarget = view.module ? { bundle, id: view.module, offset: length ? offset : null } : null;
  if (view.module) announceModule(view.module);
  renderCodePane(bundle);
}

function localsPattern() {
  const input = $('localsPattern');
  input.classList.remove('invalid');
  if (!$('locals').classList.contains('on')) return null;
  try {
    return new RegExp(input.value.trim());
  } catch (e) {
    input.classList.add('invalid');
    setStatus(`지역 이름 정규식 오류: ${e.message}`);
    return null;
  }
}

function syncCodeMode() {
  $('localsBox').hidden = segValue('codeMode') !== 'restore';
  $('localsPattern').hidden = !$('locals').classList.contains('on');
  if (codeTarget) renderCodePane();
}

function toggleLocals() {
  togglePressed($('locals'));
  syncCodeMode();
}

function showCodeNote(title, text) {
  codeViewData = null;
  $('codeTitle').textContent = title;
  $('codeHead').hidden = true;
  $('outlineBtn').hidden = true;
  $('relationsBtn').hidden = true;
  $('toggleHeadBtn').hidden = true;
  $('code').replaceChildren(el('div', 'placeholder', text));
  codeFinder.refresh();
}

function renderCodePane(bundle = source?.bundle) {
  closePopovers();
  if (!codeTarget) return showCodeNote(bundle?.name ?? '', 'AMD 모듈(define) 밖의 코드라 포맷/이름 풀기 보기를 지원하지 않습니다. 왼쪽 원본이나 "Sources"를 이용하세요.');
  const { id, offset } = codeTarget;
  const rename = segValue('codeMode') === 'restore';
  const view = moduleView(codeTarget.bundle, id, { rename, locals: rename ? localsPattern() : null, offset });
  if (view.error) return showCodeNote(id, view.error);
  codeViewData = view;
  $('codeTitle').textContent = id;
  $('codeHead').hidden = false;
  $('outlineBtn').hidden = false;
  $('relationsBtn').hidden = false;
  $('toggleHeadBtn').hidden = false;
  renderLinkedText($('codeHead'), view.head, { onModule: (m) => openModule(m) });
  const focus = renderCode($('code'), view.code, {
    focusLine: view.line,
    nlsMap: getNlsMap(),
    onLineClick: syncCodeToSource,
  });
  codeFinder.refresh();
  scrollToRow($('codeBody'), focus);
}

function toggleZoom(button) {
  const target = `zoom-${button.dataset.zoom}`;
  transitionLayout(() => {
    const on = !$('main').classList.contains(target);
    $('main').classList.remove('zoom-source', 'zoom-code');
    $('main').classList.toggle(target, on);
    document.querySelectorAll('.zoom').forEach((b) => setZoomButton(b, on && b === button));
  });
}

function setZoomButton(button, active) {
  setIcon(button, active ? 'zoomExit' : 'zoomEnter');
  button.title = active ? '원래 크기' : '전체화면';
  button.classList.toggle('on', active);
}

function viewModuleInput() {
  const id = $('moduleId').value.trim();
  closePopovers();
  if (id) openModule(id);
}

function closePopovers(except = null) {
  if (except !== $('moduleSuggest')) suggestGen += 1;
  document.querySelectorAll('.popover').forEach((p) => {
    if (p !== except) p.hidden = true;
  });
}

function renderHistoryMenu() {
  const menu = $('historyMenu');
  const items = loadHistory();
  if (!items.length) {
    menu.replaceChildren();
    return closePopovers();
  }
  const remove = (e, next) => {
    e.stopPropagation();
    saveHistory(next);
    renderHistoryMenu();
  };
  const clearAll = el('button', 'ghost', '기록 모두 지우기');
  clearAll.type = 'button';
  clearAll.addEventListener('click', (e) => remove(e, []));
  menu.replaceChildren(
    ...items.map((term) => {
      const del = setIcon(el('button', 'icon input-clear'), 'x', 12);
      del.type = 'button';
      del.title = '이 기록 지우기';
      del.addEventListener('click', (e) => remove(e, items.filter((item) => item !== term)));
      const row = el('div', 'pop-item', el('span', 'mono', term), del);
      row.addEventListener('click', () => {
        $('query').value = term;
        syncClearButton($('query'));
        closePopovers();
        run(search);
      });
      return row;
    }),
    el('div', 'pop-foot', clearAll),
  );
  menu.hidden = false;
}

function showHistoryMenu() {
  const menu = $('historyMenu');
  if (!loadHistory().length || !menu.hidden) return closePopovers();
  closePopovers(menu);
  renderHistoryMenu();
}

function loadJsBundles() {
  jsBundles = loadBundles({ names: '', mode: 'contains', kinds: ['js'] });
  return jsBundles;
}

async function updateModuleSuggest(reload = false) {
  const gen = ++suggestGen;
  const menu = $('moduleSuggest');
  if (!jsBundles) {
    closePopovers(menu);
    menu.replaceChildren(el('div', 'pop-empty', LOADING));
    menu.hidden = false;
  }
  const mods = listModules(await (reload || !jsBundles ? loadJsBundles() : jsBundles));
  if (gen !== suggestGen) return;
  const q = $('moduleId').value.trim().toLowerCase();
  const matched = (q ? mods.filter((m) => m.id.toLowerCase().includes(q) || m.file.toLowerCase().includes(q)) : mods).slice(0, 40);
  suggestIdx = -1;
  if (!matched.length) {
    menu.replaceChildren(el('div', 'pop-empty', '일치하는 모듈이 없습니다.'));
    menu.hidden = false;
    return;
  }
  closePopovers(menu);
  menu.replaceChildren(
    ...matched.map((m) => {
      const row = el('div', 'pop-item', el('span', 'mono', m.id), el('span', 'meta', m.file));
      row.dataset.id = m.id;
      row.addEventListener('click', () => {
        $('moduleId').value = m.id;
        syncClearButton($('moduleId'));
        closePopovers();
        openModule(m.id);
      });
      return row;
    }),
  );
  menu.hidden = false;
}

function jumpToModuleOffset(offset) {
  if (!codeTarget || !codeViewData) return;
  const genLine = offsetToGeneratedLine(codeViewData.modStart, codeViewData.marks, offset);
  const { line } = toLineColumn(codeTarget.bundle.lineStarts, offset);
  if (genLine) scrollToRow($('codeBody'), highlightCodeLine($('code'), genLine));
  scrollToRow($('source'), highlightCodeLine($('source'), line));
  closePopovers();
}

function toggleOutlineMenu() {
  const menu = $('outlineMenu');
  if (!codeTarget || !menu.hidden) return closePopovers();
  closePopovers(menu);
  const { methods, events, nls } = moduleOutline(codeTarget.bundle, codeTarget.id);
  const sections = [
    ['함수 · 메서드', methods],
    ['이벤트 (publish / subscribe)', events],
    ['NLS 키', nls],
  ].filter(([, list]) => list.length);
  if (!sections.length) {
    menu.replaceChildren(el('div', 'pop-empty', '추출된 항목이 없습니다.'));
    menu.hidden = false;
    return;
  }
  const nodes = sections.flatMap(([label, items]) => [
    el('div', 'pop-section', `${label} (${items.length})`),
    ...items.slice(0, 80).map((it) => {
      const genLine = offsetToGeneratedLine(codeViewData?.modStart ?? 0, codeViewData?.marks, it.offset);
      const row = el('div', 'pop-item', el('span', 'mono', it.name), el('span', 'meta', genLine ? `L${genLine}` : ''));
      row.addEventListener('click', () => jumpToModuleOffset(it.offset));
      return row;
    }),
  ]);
  menu.replaceChildren(...nodes);
  menu.hidden = false;
}

async function toggleRelationsMenu() {
  const menu = $('relationsMenu');
  if (!codeTarget || !menu.hidden) return closePopovers();
  closePopovers(menu);
  const target = codeTarget;
  menu.replaceChildren(el('div', 'pop-empty', LOADING));
  menu.hidden = false;
  const { deps, usedBy } = moduleRelations(await loadJsBundles(), target.id);
  if (codeTarget !== target || menu.hidden) return;
  const sections = [
    ['의존 모듈 (deps)', deps],
    ['이 모듈을 사용하는 모듈', usedBy],
  ].filter(([, list]) => list.length);
  if (!sections.length) {
    menu.replaceChildren(el('div', 'pop-empty', '연결된 모듈 정보가 없습니다.'));
    menu.hidden = false;
    return;
  }
  const nodes = sections.flatMap(([label, items]) => [
    el('div', 'pop-section', `${label} (${items.length})`),
    ...items.map((id) => {
      const row = el('div', 'pop-item', el('span', 'mono', id));
      row.addEventListener('click', () => {
        closePopovers();
        openModule(id);
      });
      return row;
    }),
  ]);
  menu.replaceChildren(...nodes);
  menu.hidden = false;
}

function setExtraOpen(open) {
  $('toolbarExtra').hidden = !open;
  setPressed($('toggleScopeBtn'), open);
  try {
    localStorage.setItem(EXTRA_HIDDEN_KEY, open ? 'false' : 'true');
  } catch {}
}

function initIcons() {
  setIcon($('historyBtn'), 'history', 13);
  setIcon($('toggleScopeBtn'), 'sliders', 14);
  setIcon($('refreshBundlesBtn'), 'refresh', 14);
  setIcon($('sourceWrapBtn'), 'wrap', 13);
  setIcon($('copySourceBtn'), 'copy', 13);
  setIcon($('codeWrapBtn'), 'wrap', 13);
  setIcon($('copyCodeBtn'), 'copy', 13);
  setIcon($('toggleHeadBtn'), 'braces', 13);
  $('search').innerHTML = `${iconSvg('search', 13)}<span>검색</span>`;
  $('openSources').innerHTML = `${iconSvg('external', 12)}<span>Sources</span>`;
  $('outlineBtn').innerHTML = `${iconSvg('list', 12)}<span>목차</span>`;
  $('relationsBtn').innerHTML = `${iconSvg('gitFork', 12)}<span>의존</span>`;
}

applyTheme();
initIcons();
makeClearable($('query'), { inline: true });
makeClearable($('files'), { inline: true });
makeClearable($('moduleId'), { inline: true });
makeClearable($('localsPattern'), { onClear: () => codeTarget && renderCodePane() });
setPressed($('toggleHeadBtn'), true);
syncHistoryButton();
restoreScope();
setExtraOpen(localStorage.getItem(EXTRA_HIDDEN_KEY) !== 'true');
$('sourceFind').replaceWith(sourceFinder.node);
$('codeFind').replaceWith(codeFinder.node);
$('files').addEventListener('input', saveScope);
bindSeg('fileMode', saveScope);
bindSeg('mode', () => {});
bindSeg('codeMode', syncCodeMode);
$('locals').addEventListener('click', toggleLocals);
$('localsPattern').addEventListener('change', () => codeTarget && renderCodePane());
document.querySelectorAll('.chip[data-kind]').forEach((c) =>
  c.addEventListener('click', () => {
    togglePressed(c);
    saveScope();
  }),
);
document.querySelectorAll('.zoom').forEach((b) => {
  setZoomButton(b, false);
  b.addEventListener('click', () => toggleZoom(b));
});
$('caseSensitive').addEventListener('click', () => togglePressed($('caseSensitive')));
$('search').addEventListener('click', () => run(search));
$('module').addEventListener('click', viewModuleInput);
$('openSources').addEventListener('click', () => source && openSourceLocation(source.bundle.url, source.line, source.column));
$('historyBtn').addEventListener('click', (e) => {
  e.stopPropagation();
  showHistoryMenu();
});
$('toggleScopeBtn').addEventListener('click', () => transitionLayout(() => setExtraOpen($('toolbarExtra').hidden)));
$('refreshBundlesBtn').addEventListener('click', () => {
  clearBundleCache();
  nlsCache = { size: -1, map: new Map() };
  jsBundles = null;
  run(async () => {
    const bundles = await loadBundles(scope());
    setStatus(`새로고침 완료  ·  ${bundles.length ? bundleSummary(bundles) : '검색할 파일 없음'}`);
  });
});
$('sourceWrapBtn').addEventListener('click', () => {
  togglePressed($('sourceWrapBtn'));
  $('source').classList.toggle('wrap', $('sourceWrapBtn').classList.contains('on'));
});
$('codeWrapBtn').addEventListener('click', () => {
  togglePressed($('codeWrapBtn'));
  $('codeBody').classList.toggle('wrap', $('codeWrapBtn').classList.contains('on'));
});
$('copySourceBtn').addEventListener('click', () => copyWithFeedback($('copySourceBtn'), () => source?.text ?? '', { iconOnly: true }));
$('copyCodeBtn').addEventListener('click', () => copyWithFeedback($('copyCodeBtn'), () => (codeViewData ? `${codeViewData.head}\n${codeViewData.code}` : ''), { iconOnly: true }));
$('toggleHeadBtn').addEventListener('click', () => {
  $('codeHead').classList.toggle('collapsed');
  setPressed($('toggleHeadBtn'), !$('codeHead').classList.contains('collapsed'));
});
$('outlineBtn').addEventListener('click', (e) => {
  e.stopPropagation();
  toggleOutlineMenu();
});
$('relationsBtn').addEventListener('click', (e) => {
  e.stopPropagation();
  toggleRelationsMenu();
});
$('moduleId').addEventListener('focus', () => updateModuleSuggest(true));
$('moduleId').addEventListener('input', () => updateModuleSuggest());
chrome.devtools?.network?.onNavigated?.addListener(() => {
  jsBundles = null;
});
$('moduleId').addEventListener('keydown', (e) => {
  const menu = $('moduleSuggest');
  const items = [...menu.querySelectorAll('.pop-item')];
  if (e.key === 'Escape') return closePopovers();
  if ((e.key === 'ArrowDown' || e.key === 'ArrowUp') && !menu.hidden && items.length) {
    e.preventDefault();
    suggestIdx = (suggestIdx + (e.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length;
    items.forEach((it, i) => it.classList.toggle('active', i === suggestIdx));
    items[suggestIdx].scrollIntoView({ block: 'nearest' });
    return;
  }
  if (e.key === 'Enter') {
    if (!menu.hidden && suggestIdx >= 0 && items[suggestIdx]) {
      $('moduleId').value = items[suggestIdx].dataset.id;
    }
    viewModuleInput();
  }
});
[
  ['query', 'search'],
  ['files', 'search'],
].forEach(([input, button]) =>
  $(input).addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      closePopovers();
      $(button).click();
    } else if (e.key === 'Escape') {
      closePopovers();
    }
  }),
);
document.addEventListener('click', (e) => {
  if (!e.target.closest('.popover, .field, .pop-anchor')) closePopovers();
});
document.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
    e.preventDefault();
    setExtraOpen(true);
    $('moduleId').focus();
    $('moduleId').select();
    updateModuleSuggest();
  }
});
bindResizer($('vsplit'), '3di.panel.sourceWidth', 'x', (pct) => $('codeArea').style.setProperty('--left', `${pct}%`), 50, MIN_PANE_WIDTH);
bindResizer($('hsplit'), '3di.panel.codeHeight', 'y', (pct) => $('main').style.setProperty('--code', `${pct}%`), 55, MIN_PANE_HEIGHT);

async function handleInspectorAction(action) {
  if (action.type === 'openModule' && action.moduleId) {
    await run(() => openModule(action.moduleId, action.line ?? null, action.column ?? 1));
  } else if (action.type === 'openLocation' && action.url) {
    await run(() => openUrlLocation(action.url, action.line, action.column));
  } else if (action.type === 'search' && action.query) {
    $('query').value = action.query;
    syncClearButton($('query'));
    await run(() => search());
  }
}

listenInspectorAction(handleInspectorAction, { replay: false });
setupIdentify();
setupInfo(document.querySelector('.status-bar'));
run(async () => {
  await intro();
  const pending = consumeInspectorAction();
  if (pending) await handleInspectorAction(pending);
});
