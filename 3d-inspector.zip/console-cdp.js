import { cdpFrames, errorFrames, exceptionFrames, exceptionText, formatLogArgs, levelOf } from './core.js';

const PROTOCOL = '1.3';
const ASYNC_DEPTH = 16;
const ASYNC_HOPS = 4;
const MAX_TEXT = 10000;
const MAX_BODY = 2000;
const MAX_REMEMBERED = 2000;
const API_TYPES = new Set(['XHR', 'Fetch']);
const WORKER_TYPES = new Set(['worker', 'shared_worker', 'service_worker']);
const NETWORK_BUFFER = { maxTotalBufferSize: 10000000, maxResourceBufferSize: 2000000 };
const REPLAY_TAG = '[3D Console]';
const REPLAY_FN = 'function (...args) { console.log(...args); }';

const clip = (text, max) => (text.length > max ? `${text.slice(0, max)}…` : text);
const callArg = (a) => (a.objectId ? { objectId: a.objectId } : a.unserializableValue ? { unserializableValue: a.unserializableValue } : { value: a.value });

function isReplay(p) {
  const first = p.args?.[0];
  return first?.type === 'string' && first.value.startsWith(REPLAY_TAG) && !(p.stackTrace?.callFrames ?? []).some((f) => f.url);
}

function newSession(sessionId, info) {
  return { key: sessionId ?? '', sessionId, type: info.type, url: info.url ?? '', contexts: new Map(), frames: new Map(), mainFrame: null, framesReady: null };
}

export function createCdpSource({ tabId, onEntry, onRevoke, onClear, onState }) {
  const sessions = new Map();
  const requests = new Map();
  const apiRequests = new Set();
  const parents = new Map();
  let seq = 0;
  let order = Promise.resolve();

  const send = (s, method, params = {}) => chrome.debugger.sendCommand(s.sessionId ? { tabId, sessionId: s.sessionId } : { tabId }, method, params);
  const later = (task) => {
    order = order.then(task).catch(() => {});
  };

  async function refreshFrames(s) {
    const res = await send(s, 'Page.getFrameTree').catch(() => null);
    if (!res) return;
    s.mainFrame = res.frameTree.frame.id;
    const walk = (node) => {
      s.frames.set(node.frame.id, node.frame.url);
      (node.childFrames ?? []).forEach(walk);
    };
    walk(res.frameTree);
  }

  function placeOf(s, frameId) {
    if (WORKER_TYPES.has(s.type)) return { where: 'Worker', frameUrl: s.url };
    if (s.sessionId) return { where: 'iframe', frameUrl: s.url };
    if (!frameId) return { where: '', frameUrl: '' };
    return { where: frameId === s.mainFrame ? '최상위 문서' : 'iframe', frameUrl: s.frames.get(frameId) ?? '' };
  }

  function parentStack(s, id) {
    const key = `${s.key}:${id.id}:${id.debuggerId ?? ''}`;
    if (!parents.has(key)) {
      if (parents.size > 500) parents.clear();
      parents.set(key, send(s, 'Debugger.getStackTrace', { stackTraceId: id }).then((r) => r.stackTrace, () => null));
    }
    return parents.get(key);
  }

  async function asyncFrames(s, stack) {
    const out = [];
    let cur = stack;
    for (let hop = 0; hop < ASYNC_HOPS && cur; hop++) {
      cur = cur.parent ?? (cur.parentId ? await parentStack(s, cur.parentId) : null);
      const frames = cdpFrames(cur);
      if (frames.length) out.push({ ...frames[0], async: cur.description || 'async' }, ...frames.slice(1));
    }
    return out;
  }

  function emit(s, data, { contextId = null, frameId = null, stack = null, body = null } = {}) {
    const id = `${s.key || 'top'}:${++seq}`;
    const frame = frameId ?? s.contexts.get(contextId);
    const ready = Promise.all([asyncFrames(s, stack), body, s.framesReady]).then(([asyncStack, text]) => ({
      id,
      session: s.sessionId,
      contextId,
      ...placeOf(s, frame),
      ...data,
      text: clip(data.text, MAX_TEXT),
      asyncStack,
      ...(data.kind === 'network' ? { body: text ? clip(text, MAX_BODY) : null } : null),
    }));
    later(() => ready.then(onEntry));
  }

  function remember(key) {
    apiRequests.add(key);
    if (apiRequests.size > MAX_REMEMBERED) apiRequests.delete(apiRequests.values().next().value);
  }

  function settle(s, p, failed) {
    const key = `${s.key}:${p.requestId}`;
    const r = requests.get(key);
    requests.delete(key);
    if (!r || !API_TYPES.has(r.type) || (!failed && r.status < 400)) return;
    const duration = Math.max(0, Math.round((p.timestamp - r.started) * 1000));
    const result = failed ? (p.canceled ? '(canceled)' : '(failed)') : `${r.status} (${r.statusText || 'error'})`;
    const body = failed ? null : send(s, 'Network.getResponseBody', { requestId: p.requestId }).then((b) => (b.base64Encoded ? '[binary]' : b.body), () => null);
    emit(
      s,
      { kind: 'network', level: failed && p.canceled ? 'warn' : 'error', text: `${r.method} ${r.url} ${result}`, time: Math.round(r.wall * 1000) + duration, duration, rawStack: cdpFrames(r.stack), errorStack: [], args: [] },
      { frameId: r.frameId, stack: r.stack, body },
    );
  }

  const handlers = {
    'Runtime.executionContextCreated'(s, { context }) {
      const frameId = context.auxData?.frameId;
      s.contexts.set(context.id, frameId);
      if (!s.sessionId && frameId && !s.frames.has(frameId)) s.framesReady = refreshFrames(s);
    },
    'Runtime.executionContextsCleared'(s) {
      s.contexts.clear();
      if (!s.sessionId) later(onClear);
    },
    'Runtime.consoleAPICalled'(s, p) {
      if (p.type === 'endGroup' || p.type === 'clear' || isReplay(p)) return;
      const args = p.args ?? [];
      const text = formatLogArgs(args) || `console.${p.type}`;
      emit(
        s,
        { level: levelOf(p.type), text: p.type === 'assert' ? `Assertion failed: ${text}` : text, time: p.timestamp, rawStack: cdpFrames(p.stackTrace), errorStack: errorFrames(args.find((a) => a.subtype === 'error')?.description), args },
        { contextId: p.executionContextId, stack: p.stackTrace },
      );
    },
    'Runtime.exceptionThrown'(s, { timestamp, exceptionDetails: d }) {
      emit(
        s,
        { level: 'error', text: exceptionText(d), time: timestamp, rawStack: [], errorStack: exceptionFrames(d), args: d.exception ? [d.exception] : [], exceptionKey: `${s.key}:${d.exceptionId}` },
        { contextId: d.executionContextId, stack: d.stackTrace },
      );
    },
    'Runtime.exceptionRevoked'(s, { exceptionId }) {
      later(() => onRevoke(`${s.key}:${exceptionId}`));
    },
    'Log.entryAdded'(s, { entry: e }) {
      if (e.source === 'worker' && s.autoAttach) return;
      if (e.source === 'network' && apiRequests.has(`${s.key}:${e.networkRequestId}`)) return;
      const frames = cdpFrames(e.stackTrace);
      const at = !frames.length && e.url ? [{ fn: '', url: e.url, line: (e.lineNumber ?? 0) + 1, column: 1 }] : frames;
      emit(s, { kind: 'browser', level: levelOf(e.level), text: e.text, time: e.timestamp, rawStack: at, errorStack: [], args: e.args ?? [] }, { stack: e.stackTrace });
    },
    'Network.requestWillBeSent'(s, p) {
      const key = `${s.key}:${p.requestId}`;
      const prev = requests.get(key);
      requests.set(key, { method: p.request.method, url: p.request.url, type: p.type, frameId: p.frameId, started: prev?.started ?? p.timestamp, wall: prev?.wall ?? p.wallTime, stack: prev?.stack ?? p.initiator?.stack ?? null, status: 0, statusText: '' });
      if (API_TYPES.has(p.type)) remember(key);
    },
    'Network.responseReceived'(s, p) {
      const r = requests.get(`${s.key}:${p.requestId}`);
      if (r) Object.assign(r, { status: p.response.status, statusText: p.response.statusText });
    },
    'Network.loadingFinished'(s, p) {
      settle(s, p, false);
    },
    'Network.loadingFailed'(s, p) {
      settle(s, p, true);
    },
    'Target.attachedToTarget'(s, { sessionId, targetInfo }) {
      const child = newSession(sessionId, targetInfo);
      sessions.set(sessionId, child);
      enable(child);
    },
    'Target.detachedFromTarget'(s, { sessionId }) {
      sessions.delete(sessionId);
    },
  };

  async function enable(s) {
    const run = (method, params) => send(s, method, params).catch(() => null);
    s.autoAttach = Boolean(await run('Target.setAutoAttach', { autoAttach: true, waitForDebuggerOnStart: false, flatten: true }));
    await run('Runtime.setAsyncCallStackDepth', { maxDepth: ASYNC_DEPTH });
    if (!s.sessionId) s.framesReady = refreshFrames(s);
    await Promise.all([run('Runtime.enable'), run('Log.enable'), run('Network.enable', NETWORK_BUFFER)]);
  }

  async function attach() {
    try {
      await chrome.debugger.attach({ tabId }, PROTOCOL);
    } catch (e) {
      if (!/already attached/i.test(e.message)) throw e;
      await chrome.debugger.detach({ tabId }).catch(() => {});
      await chrome.debugger.attach({ tabId }, PROTOCOL);
    }
  }

  async function start() {
    if (!chrome.debugger) return onState('error', '이 확장에서 debugger 권한을 쓸 수 없습니다');
    onState('connecting');
    try {
      await attach();
    } catch (e) {
      onState('error', e.message);
      return;
    }
    sessions.clear();
    requests.clear();
    apiRequests.clear();
    parents.clear();
    const main = newSession(null, { type: 'page' });
    sessions.set('', main);
    onState('on');
    await enable(main);
  }

  function stop() {
    chrome.debugger?.detach({ tabId }).catch(() => {});
  }

  async function replay(entry) {
    const s = sessions.get(entry.session ?? '');
    if (!s) return false;
    const tag = { value: `${REPLAY_TAG} ${entry.level}` };
    const res =
      entry.contextId != null && entry.args.length
        ? await send(s, 'Runtime.callFunctionOn', { functionDeclaration: REPLAY_FN, executionContextId: entry.contextId, arguments: [tag, ...entry.args.map(callArg)] })
        : await send(s, 'Runtime.evaluate', { expression: `console.log(${JSON.stringify(tag.value)}, ${JSON.stringify(entry.text)})` });
    return !res.exceptionDetails;
  }

  chrome.debugger?.onEvent.addListener((source, method, params) => {
    if (source.tabId !== tabId) return;
    const s = sessions.get(source.sessionId ?? '');
    if (s) handlers[method]?.(s, params);
  });
  chrome.debugger?.onDetach.addListener((source, reason) => {
    if (source.tabId !== tabId) return;
    sessions.clear();
    onState('off', reason);
  });

  return { start, stop, replay };
}
