import { renderCode } from './view.js';

const MAX_TREE_CHARS = 350000;
const MAX_TREE_NODES = 4000;

export function tryParseJson(text) {
  if (typeof text !== 'string') return { ok: false, value: null };
  const trimmed = text.trim();
  if (!trimmed || (!trimmed.startsWith('{') && !trimmed.startsWith('['))) return { ok: false, value: null };
  try {
    const value = JSON.parse(trimmed);
    if (value && typeof value === 'object') return { ok: true, value };
  } catch {}
  return { ok: false, value: null };
}

export function formatPrettyText(text) {
  const parsed = tryParseJson(text);
  return parsed.ok ? JSON.stringify(parsed.value, null, 2) : String(text ?? '');
}

function detectCodeKind(contentType, text) {
  const ct = String(contentType ?? '').toLowerCase();
  if (ct.includes('json')) return 'json';
  if (ct.includes('html') || ct.includes('xml')) return 'html';
  if (ct.includes('javascript') || ct.includes('ecmascript')) return 'js';
  if (ct.includes('css')) return 'css';
  const trimmed = String(text ?? '').trimStart();
  if (trimmed.startsWith('<')) return 'html';
  if (trimmed.startsWith('{') || trimmed.startsWith('[')) return 'json';
  return null;
}

function escapeShellSingle(str) {
  return String(str ?? '').replace(/'/g, "'\\''");
}

export function buildCurlCommand(item) {
  if (!item) return '';
  const parts = [`curl '${escapeShellSingle(item.url)}'`];
  if (item.method && item.method !== 'GET') parts.push(`-X '${escapeShellSingle(item.method)}'`);
  for (const h of item.requestHeaders ?? []) {
    const name = String(h.name ?? '');
    if (!name || name.startsWith(':') || name.toLowerCase() === 'content-length') continue;
    parts.push(`-H '${escapeShellSingle(`${name}: ${h.value ?? ''}`)}'`);
  }
  if (item.postDataText) parts.push(`--data-raw '${escapeShellSingle(item.postDataText)}'`);
  return parts.join(' \\\n  ');
}

function isObjectValue(v) {
  return v !== null && typeof v === 'object';
}

function summarizeValue(v) {
  if (Array.isArray(v)) return `Array(${v.length})`;
  const keys = Object.keys(v);
  return `{${keys.length}}`;
}

function countTreeNodes(value, limit = MAX_TREE_NODES) {
  let count = 0;
  const stack = [value];
  while (stack.length) {
    const cur = stack.pop();
    count += 1;
    if (count > limit) return count;
    if (Array.isArray(cur)) {
      for (let i = cur.length - 1; i >= 0; i--) {
        if (isObjectValue(cur[i])) stack.push(cur[i]);
        else count += 1;
      }
    } else if (isObjectValue(cur)) {
      for (const v of Object.values(cur)) {
        if (isObjectValue(v)) stack.push(v);
        else count += 1;
      }
    }
  }
  return count;
}

function createPrimitiveSpan(value) {
  const span = document.createElement('span');
  if (value === null) {
    span.className = 'jv-val jv-null';
    span.textContent = 'null';
  } else if (typeof value === 'string') {
    span.className = 'jv-val jv-str';
    span.textContent = JSON.stringify(value);
  } else if (typeof value === 'number') {
    span.className = 'jv-val jv-num';
    span.textContent = String(value);
  } else if (typeof value === 'boolean') {
    span.className = 'jv-val jv-bool';
    span.textContent = String(value);
  } else {
    span.className = 'jv-val';
    span.textContent = String(value);
  }
  return span;
}

function formatJsonPath(parentPath, key, isArray) {
  if (!parentPath) return isArray ? `[${key}]` : String(key);
  if (isArray) return `${parentPath}[${key}]`;
  return /^[A-Za-z_$][\w$]*$/.test(String(key)) ? `${parentPath}.${key}` : `${parentPath}[${JSON.stringify(String(key))}]`;
}

function createCopyChip(getText, title) {
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'jv-copy-btn';
  btn.textContent = '복사';
  btn.title = title;
  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    const val = getText();
    navigator.clipboard?.writeText(val).catch(() => {});
    btn.textContent = '복사됨';
    setTimeout(() => {
      btn.textContent = '복사';
    }, 900);
  });
  return btn;
}

function buildJsonNode({ keyName, value, depth, path, isLast, isArrayItem, defaultExpandDepth }) {
  const wrap = document.createElement('div');
  wrap.className = 'jv-row';
  if (!isObjectValue(value)) {
    const line = document.createElement('div');
    line.className = 'jv-line jv-leaf';
    line.style.paddingLeft = `${depth * 14 + 14}px`;
    line.title = path;
    if (keyName !== undefined) {
      const keySpan = document.createElement('span');
      keySpan.className = isArrayItem ? 'jv-idx' : 'jv-key';
      keySpan.textContent = isArrayItem ? `${keyName}: ` : `${JSON.stringify(String(keyName))}: `;
      line.append(keySpan);
    }
    line.append(createPrimitiveSpan(value));
    if (!isLast) {
      const comma = document.createElement('span');
      comma.className = 'jv-punct';
      comma.textContent = ',';
      line.append(comma);
    }
    line.append(createCopyChip(() => (typeof value === 'string' ? value : JSON.stringify(value)), `${path} 값 복사`));
    wrap.append(line);
    return wrap;
  }
  const isArr = Array.isArray(value);
  const entries = isArr ? value.map((v, i) => [i, v]) : Object.entries(value);
  const openBracket = isArr ? '[' : '{';
  const closeBracket = isArr ? ']' : '}';
  const node = document.createElement('div');
  node.className = 'jv-node';
  node.dataset.depth = String(depth);
  const collapsed = entries.length === 0 || depth >= defaultExpandDepth;
  if (collapsed) node.classList.add('is-collapsed');
  const head = document.createElement('div');
  head.className = 'jv-line jv-head';
  head.style.paddingLeft = `${depth * 14}px`;
  head.title = path || 'root';
  const toggle = document.createElement('button');
  toggle.type = 'button';
  toggle.className = 'jv-toggle';
  toggle.textContent = entries.length ? (collapsed ? '▸' : '▾') : '·';
  toggle.disabled = entries.length === 0;
  head.append(toggle);
  if (keyName !== undefined) {
    const keySpan = document.createElement('span');
    keySpan.className = isArrayItem ? 'jv-idx' : 'jv-key';
    keySpan.textContent = isArrayItem ? `${keyName}: ` : `${JSON.stringify(String(keyName))}: `;
    head.append(keySpan);
  }
  const openSpan = document.createElement('span');
  openSpan.className = 'jv-punct';
  openSpan.textContent = openBracket;
  head.append(openSpan);
  const summary = document.createElement('span');
  summary.className = 'jv-summary';
  summary.textContent = entries.length ? ` ${summarizeValue(value)} ` : '';
  head.append(summary);
  const closeInline = document.createElement('span');
  closeInline.className = 'jv-punct jv-close-inline';
  closeInline.textContent = `${closeBracket}${isLast ? '' : ','}`;
  head.append(closeInline);
  head.append(createCopyChip(() => JSON.stringify(value, null, 2), `${path || 'root'} JSON 복사`));
  const childrenEl = document.createElement('div');
  childrenEl.className = 'jv-children';
  entries.forEach(([k, v], idx) => {
    childrenEl.append(
      buildJsonNode({
        keyName: k,
        value: v,
        depth: depth + 1,
        path: formatJsonPath(path, k, isArr),
        isLast: idx === entries.length - 1,
        isArrayItem: isArr,
        defaultExpandDepth,
      }),
    );
  });
  const foot = document.createElement('div');
  foot.className = 'jv-line jv-foot';
  foot.style.paddingLeft = `${depth * 14 + 14}px`;
  const closeFoot = document.createElement('span');
  closeFoot.className = 'jv-punct';
  closeFoot.textContent = `${closeBracket}${isLast ? '' : ','}`;
  foot.append(closeFoot);
  const setCollapsed = (next) => {
    if (!entries.length) return;
    node.classList.toggle('is-collapsed', next);
    toggle.textContent = next ? '▸' : '▾';
  };
  if (entries.length) {
    head.addEventListener('click', () => setCollapsed(!node.classList.contains('is-collapsed')));
  }
  node._setCollapsed = setCollapsed;
  node.append(head, childrenEl, foot);
  wrap.append(node);
  return wrap;
}

function clearHighlights(root) {
  const parents = new Set([...root.querySelectorAll('mark.jv-match')].map((mark) => mark.parentNode));
  for (const parent of parents) {
    const nodes = [];
    let run = null;
    for (const node of parent.childNodes) {
      if (node.nodeType === Node.TEXT_NODE || node.classList?.contains('jv-match')) {
        if (!run) nodes.push((run = []));
        run.push(node.textContent);
      } else {
        run = null;
        nodes.push(node);
      }
    }
    parent.replaceChildren(...nodes.map((node) => (Array.isArray(node) ? node.join('') : node)));
  }
}

function highlightInElement(el, needleLower, matches) {
  const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
  const textNodes = [];
  for (let n = walker.nextNode(); n; n = walker.nextNode()) {
    if (n.parentElement?.closest('.jv-copy-btn, .jv-toggle, .jv-summary, .jv-banner, .ln, .nls-hint')) continue;
    if (n.nodeValue && n.nodeValue.toLowerCase().includes(needleLower)) textNodes.push(n);
  }
  for (const node of textNodes) {
    const text = node.nodeValue;
    const lower = text.toLowerCase();
    const frag = document.createDocumentFragment();
    let pos = 0;
    for (let i = lower.indexOf(needleLower); i !== -1; i = lower.indexOf(needleLower, pos)) {
      if (i > pos) frag.append(document.createTextNode(text.slice(pos, i)));
      const mark = document.createElement('mark');
      mark.className = 'jv-match';
      mark.textContent = text.slice(i, i + needleLower.length);
      frag.append(mark);
      matches.push(mark);
      pos = i + needleLower.length;
    }
    if (pos < text.length) frag.append(document.createTextNode(text.slice(pos)));
    node.parentNode.replaceChild(frag, node);
  }
}

function expandAncestors(el) {
  for (let cur = el.parentElement; cur; cur = cur.parentElement) {
    if (cur.classList?.contains('jv-node') && cur._setCollapsed) cur._setCollapsed(false);
  }
}

function parseFormEncoded(text) {
  try {
    const params = new URLSearchParams(text);
    const rows = [...params.entries()];
    return rows.length ? rows : null;
  } catch {
    return null;
  }
}

function buildFormTable(rows) {
  const table = document.createElement('table');
  table.className = 'kv-table';
  for (const [k, v] of rows) {
    const tr = document.createElement('tr');
    const tdKey = document.createElement('td');
    tdKey.className = 'kv-key';
    tdKey.textContent = k;
    const tdVal = document.createElement('td');
    tdVal.className = 'kv-val';
    tdVal.textContent = v;
    tr.append(tdKey, tdVal);
    table.append(tr);
  }
  return table;
}

export function createViewerSearch({ input, count, prev, next }) {
  let viewer = null;
  let found = null;
  let index = 0;
  const show = () => {
    count.textContent = found?.count ? `${index + 1}/${found.count}` : input.value.trim() ? '0/0' : '';
  };
  const run = () => {
    if (!viewer) return;
    found = viewer.search(input.value);
    index = 0;
    if (found.count) found.focus(0);
    show();
  };
  const step = (delta) => {
    if (!found?.count) return;
    index = (index + delta + found.count) % found.count;
    found.focus(index);
    show();
  };
  input.addEventListener('input', run);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') step(e.shiftKey ? -1 : 1);
  });
  prev.addEventListener('click', () => step(-1));
  next.addEventListener('click', () => step(1));
  return {
    attach(nextViewer) {
      viewer = nextViewer;
      found = null;
      if (viewer && input.value.trim()) run();
      else count.textContent = '';
    },
  };
}

export function renderBodyViewer(container, { text, emptyMessage, mode = 'tree', contentType = '', defaultExpandDepth = 3, forceTree = false, onForceTree } = {}) {
  container.replaceChildren();
  if (!text) {
    const empty = document.createElement('div');
    empty.className = 'empty-msg';
    empty.textContent = emptyMessage ?? '내용 없음';
    container.append(empty);
    return { isTree: false, expandAll() {}, collapseToDepth1() {}, search: () => ({ count: 0, focus() {} }) };
  }
  const parsed = tryParseJson(text);
  const isForm = !parsed.ok && /application\/x-www-form-urlencoded/i.test(contentType);
  const formRows = isForm ? parseFormEncoded(text) : null;
  let isTree = false;
  if (mode === 'tree' && parsed.ok) {
    const large = !forceTree && (text.length > MAX_TREE_CHARS || countTreeNodes(parsed.value) > MAX_TREE_NODES);
    if (large) {
      const banner = document.createElement('div');
      banner.className = 'jv-banner';
      banner.textContent = `대용량 JSON (${Math.round(text.length / 1024)} KB) — 성능 보호를 위해 Raw 텍스트로 표시합니다. `;
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = '트리로 보기';
      btn.addEventListener('click', () => onForceTree?.());
      banner.append(btn);
      const codeBox = document.createElement('div');
      codeBox.className = 'code wrap';
      renderCode(codeBox, formatPrettyText(text), { kind: 'json' });
      container.append(banner, codeBox);
    } else {
      isTree = true;
      const tree = document.createElement('div');
      tree.className = 'jv-tree';
      tree.append(
        buildJsonNode({
          keyName: undefined,
          value: parsed.value,
          depth: 0,
          path: '',
          isLast: true,
          isArrayItem: false,
          defaultExpandDepth,
        }),
      );
      container.append(tree);
    }
  } else if (mode === 'tree' && formRows) {
    container.append(buildFormTable(formRows));
  } else {
    const formatted = mode === 'raw' ? String(text) : formatPrettyText(text);
    const kind = detectCodeKind(contentType, formatted);
    if (kind && formatted.length <= MAX_TREE_CHARS) {
      const codeBox = document.createElement('div');
      codeBox.className = 'code wrap';
      renderCode(codeBox, formatted, { kind });
      container.append(codeBox);
    } else {
      const pre = document.createElement('pre');
      pre.className = 'raw-body';
      pre.textContent = formatted;
      container.append(pre);
    }
  }
  const expandAll = () => {
    container.querySelectorAll('.jv-node').forEach((n) => n._setCollapsed?.(false));
  };
  const collapseToDepth1 = () => {
    container.querySelectorAll('.jv-node').forEach((n) => n._setCollapsed?.(Number(n.dataset.depth) >= 1));
  };
  const search = (query) => {
    clearHighlights(container);
    const needle = String(query ?? '').trim().toLowerCase();
    if (!needle) return { count: 0, focus() {} };
    const matches = [];
    highlightInElement(container, needle, matches);
    matches.forEach(expandAncestors);
    return {
      count: matches.length,
      focus(idx) {
        container.querySelectorAll('mark.jv-match.is-active').forEach((m) => m.classList.remove('is-active'));
        const target = matches[idx];
        if (!target) return;
        target.classList.add('is-active');
        target.scrollIntoView({ block: 'center', inline: 'nearest' });
      },
    };
  };
  return { isTree, expandAll, collapseToDepth1, search };
}
