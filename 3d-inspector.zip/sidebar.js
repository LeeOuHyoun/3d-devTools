import { cachedBundles, evalIn, FILE_KINDS, fileScope, findBundle, loadBundles, openSourceLocation, renderLinkedText, selectionFrame, sendInspectorAction, setupIdentify } from './devtools-lib.js';
import { iconSvg, setIcon } from './icons.js';
import { buildNlsIndex, elementClues, inspectResults, moduleView } from './tools.js';
import { applyTheme, copyWithFeedback, el, renderCode, renderInspect, transitionLayout } from './view.js';

const SELECTION_DELAY = 200;
const CLUES = `(${elementClues})($0)`;
const $ = (id) => document.getElementById(id);
const out = $('out');
const handlers = { onLocation: openSourceLocation, onModule: openModule };
let seq = 0;
let forceAllScope = false;
let currentModule = null;
let currentView = null;

function showCode(visible) {
  transitionLayout(() => {
    $('codePane').hidden = !visible;
    out.hidden = visible;
    $('scopeBar').hidden = visible;
  }, $('codePane').hidden === visible);
}

function syncScopeBar() {
  const saved = fileScope();
  const narrowed = Boolean(saved.names.trim()) || saved.kinds.length < FILE_KINDS.length;
  if (forceAllScope) {
    $('scopeText').textContent = '검색 범위: 전체 파일 (임시)';
    $('scopeAllBtn').textContent = '저장된 범위로';
    $('scopeAllBtn').hidden = false;
    return;
  }
  if (narrowed) {
    const parts = [saved.names.trim() || null, saved.kinds.length < FILE_KINDS.length ? saved.kinds.join(',').toUpperCase() : null].filter(Boolean);
    $('scopeText').textContent = `검색 범위: ${parts.join(' · ')}`;
    $('scopeAllBtn').textContent = '전체에서 찾기';
    $('scopeAllBtn').hidden = false;
    return;
  }
  $('scopeText').textContent = '검색 범위: 로드된 파일 전체';
  $('scopeAllBtn').hidden = true;
}

function renderCurrentModule() {
  if (!currentModule) return;
  const rename = $('codeMode').querySelector('.on')?.dataset.value === 'restore';
  const view = moduleView(currentModule.bundle, currentModule.id, { rename });
  currentView = view.error ? null : view;
  $('codeTitle').textContent = currentModule.id;
  renderLinkedText($('codeHead'), view.head, { onModule: openModule });
  if (view.error) $('code').replaceChildren(el('div', 'placeholder', view.error));
  else renderCode($('code'), view.code, { nlsMap: buildNlsIndex(cachedBundles()) });
  showCode(true);
  $('codeBody').scrollTop = 0;
}

async function openModule(id) {
  const bundle = await findBundle(id);
  if (!bundle) return renderInspect(out, { error: `${id}: 로드된 파일에서 모듈을 찾지 못했습니다.` }, handlers);
  currentModule = { bundle, id };
  renderCurrentModule();
}

async function update() {
  const current = ++seq;
  syncScopeBar();
  const show = (result) => {
    if (current !== seq) return;
    showCode(false);
    renderInspect(out, result, handlers);
  };
  try {
    const frame = await selectionFrame();
    const clue = frame ? await evalIn(CLUES, frame.url) : null;
    const scope = forceAllScope ? { names: '', mode: 'contains', kinds: FILE_KINDS } : fileScope();
    show(inspectResults(await loadBundles(scope), clue, 5));
  } catch (e) {
    show({ error: `오류: ${e.message}` });
  }
}

applyTheme();
setupIdentify();
$('back').innerHTML = `${iconSvg('arrowLeft', 12)}<span>결과</span>`;
setIcon($('copyCodeBtn'), 'copy', 13);
setIcon($('sendInspectorBtn'), 'external', 13);
$('back').addEventListener('click', () => showCode(false));
$('scopeAllBtn').addEventListener('click', () => {
  forceAllScope = !forceAllScope;
  update();
});
$('codeMode').addEventListener('click', (e) => {
  const btn = e.target.closest('button');
  if (!btn || btn.classList.contains('on')) return;
  $('codeMode').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b === btn));
  renderCurrentModule();
});
$('copyCodeBtn').addEventListener('click', () => copyWithFeedback($('copyCodeBtn'), () => (currentView ? `${currentView.head}\n${currentView.code}` : ''), { iconOnly: true }));
$('sendInspectorBtn').addEventListener('click', () => {
  if (!currentModule) return;
  sendInspectorAction({ type: 'openModule', moduleId: currentModule.id });
  $('sendInspectorBtn').classList.add('ghost-on');
  setTimeout(() => $('sendInspectorBtn').classList.remove('ghost-on'), 1200);
});
let selectionTimer = null;
chrome.devtools.panels.elements.onSelectionChanged.addListener(() => {
  clearTimeout(selectionTimer);
  selectionTimer = setTimeout(update, SELECTION_DELAY);
});
update();
