import { countModules, filterLogs, findModule, groupLogs, moduleSelected, stripQuery, toOffset } from './core.js';
import { createCdpSource } from './console-cdp.js';
import { cachedBundles, lastAnnouncedModule, listenModuleAnnounce, loadBundles, openSourceLocation, renderLinkedText, resolveStacks, sendInspectorAction, setupIdentify } from './devtools-lib.js';
import { iconSvg, setIcon } from './icons.js';
import { listModules } from './tools.js';
import { applyTheme, copyWithFeedback, el, findPattern, makeClearable, regexToggle, renderHelp, setPressed, syncClearButton, transitionLayout } from './view.js';

const RENDER_MS = 150;
const STATUS_NOTE_MS = 4000;
const MAX_LOGS = 5000;
const MAX_ROWS = 1500;
const KEYS = {
  modules: '3di.console.modules',
  excludes: '3di.console.excludes',
  levels: '3di.console.levels',
  group: '3di.console.group',
  preserve: '3di.console.preserve',
  follow: '3di.console.follow',
  browser: '3di.console.browser',
};
const DEFAULT_EXCLUDES = [
  { name: 'bundle-min.js', on: true },
  { name: 'AmdLoader.js', on: true },
];
const USAGE = [
  '크롬 Console과 같은 통로(크롬 디버거)로 페이지(iframe, Worker 포함)의 console 로그, 잡히지 않은 오류(Promise 포함), 브라우저 메시지(파일 로드 실패 등)를 받습니다. 이 탭을 처음 열면 그 전에 찍힌 로그도 가져옵니다. 다만 브라우저가 보관하는 최근 1,000건 안에서만 가져오므로, 로그가 아주 많은 화면은 이 탭을 연 채로 새로고침하면 처음부터 받습니다.',
  '실패한 API 호출(XHR/fetch의 4xx·5xx·연결 실패)은 API 표시와 함께 오류로, 취소된 요청은 경고로 남깁니다. 모듈은 요청을 보낸 시점의 호출 스택으로 판별하고, 펼치면 응답 본문 앞부분이 보입니다. 제외 목록과 상관없이 보입니다.',
  '모듈 칸(Ctrl+K)에서 모듈이나 패키지를 고르면, 그 모듈이 호출 스택 어디에든 있는 로그만 보여줍니다. 그 모듈이 직접 찍었거나 그 모듈을 거쳐 찍힌 로그입니다. setTimeout이나 Promise를 거쳐 나중에 찍힌 로그도 그 앞의 호출 스택(4단계까지)에서 모듈을 찾습니다.',
  '모듈을 고르지 않으면 제외 목록의 파일이 찍은 로그를 숨깁니다. API 줄과 브라우저 메시지는 숨기지 않습니다. 칩을 눌러 잠시 끄거나 X로 지우고, 오른쪽 칸에 파일 이름을 넣어 더할 수 있습니다. 칸의 .*를 켜고 넣으면 정규식(대소문자 무시, 예: ^bundle-.*\\.js$)으로 파일 이름을 비교하고, 칩에 /정규식/으로 표시됩니다.',
  '보기의 "브라우저"를 끄면 브라우저가 남긴 메시지(파일 로드 실패 등, 브라우저 표시 줄)를 숨깁니다. 숫자는 다른 조건에 맞는 브라우저 메시지 건수입니다.',
  '줄을 누르면 전체 문구와 호출 스택이 펼쳐집니다. 모듈 이름은 3D Inspector 탭에서, 파일:줄은 Sources 탭에서 엽니다. "Console에 원본 출력"은 객체를 펼쳐 볼 수 있게 크롬 Console에 다시 찍습니다.',
];
const RECONNECT_DELAY = 500;
const CHROME_FLAG = '--silent-debugger-extension-api';
const $ = (id) => document.getElementById(id);

function load(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw === null ? fallback : JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function save(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {}
}

const state = {
  modules: load(KEYS.modules, []),
  excludes: load(KEYS.excludes, DEFAULT_EXCLUDES),
  levels: load(KEYS.levels, ['error', 'warn', 'info', 'log']),
  group: load(KEYS.group, false),
  preserve: load(KEYS.preserve, false),
  follow: load(KEYS.follow, false),
  browser: load(KEYS.browser, true),
};
const entries = [];
const expanded = new Set();
const textRegex = regexToggle(render);
const excludeRegex = regexToggle(validateExclude);
let dropped = 0;
let renderTimer = null;
let statusNote = '';
let statusTimer = null;
let connection = { state: 'connecting', message: '' };

function fileOf(url) {
  return stripQuery(url ?? '').split('/').at(-1);
}

function ingest(ev) {
  const top = ev.rawStack[0] ?? ev.errorStack[0];
  const hasFrames = ev.rawStack.length > 0 || ev.errorStack.length > 0 || ev.asyncStack.length > 0;
  const entry = { ...ev, file: top ? fileOf(top.url) : '', line: top?.line ?? 0, column: top?.column ?? 0, chain: hasFrames ? null : [] };
  let at = entries.length;
  while (at > 0 && entries[at - 1].time > entry.time) at -= 1;
  entries.splice(at, 0, entry);
  if (entries.length > MAX_LOGS) dropped += entries.splice(0, entries.length - MAX_LOGS).length;
  resolveChains();
  scheduleRender();
}

function revoke(key) {
  const at = entries.findIndex((e) => e.exceptionKey === key);
  if (at === -1) return;
  entries.splice(at, 1);
  scheduleRender();
}

function handleNavigation() {
  if (!state.preserve) clearLogs();
}

function handleConnection(next, message = '') {
  connection = { state: next, message };
  if (next === 'off') setTimeout(reconnect, RECONNECT_DELAY);
  render();
}

let resolving = false;
let resolveQueued = false;

async function resolveChains() {
  if (resolving) {
    resolveQueued = true;
    return;
  }
  resolving = true;
  try {
    const pending = entries.filter((e) => !e.chain);
    if (!pending.length) return;
    const chains = await resolveStacks(pending.map((e) => [...e.errorStack, ...e.rawStack, ...e.asyncStack])).catch(() => null);
    pending.forEach((e, i) => {
      e.chain = chains?.[i] ?? [];
    });
    scheduleRender();
  } finally {
    resolving = false;
    if (resolveQueued) {
      resolveQueued = false;
      resolveChains();
    }
  }
}

const source = createCdpSource({ tabId: chrome.devtools.inspectedWindow.tabId, onEntry: ingest, onRevoke: revoke, onClear: handleNavigation, onState: handleConnection });

function clearLogs() {
  entries.length = 0;
  expanded.clear();
  dropped = 0;
  render();
}

function scheduleRender() {
  if (!renderTimer) renderTimer = setTimeout(render, RENDER_MS);
}

function timeText(t) {
  const d = new Date(t);
  return `${d.toTimeString().slice(0, 8)}.${String(d.getMilliseconds()).padStart(3, '0')}`;
}

function focusModule(e) {
  if (!e.chain?.length) return null;
  return (state.modules.length && e.chain.find((c) => moduleSelected([c], state.modules))) || e.chain[0];
}

function flashStatus(text) {
  statusNote = text;
  clearTimeout(statusTimer);
  statusTimer = setTimeout(() => {
    statusNote = '';
    render();
  }, STATUS_NOTE_MS);
  render();
}

let selfOpened = null;

function openInInspector(id, line = null, column = 1) {
  selfOpened = id;
  sendInspectorAction({ type: 'openModule', moduleId: id, line, column });
  flashStatus(`${id}: 3D Inspector 탭에 열었습니다. 탭을 눌러 확인하세요.`);
}

function anchor(cls, text, title, onClick) {
  const a = el('a', cls, text);
  a.href = '#';
  a.title = title;
  a.addEventListener('click', (ev) => {
    ev.preventDefault();
    ev.stopPropagation();
    onClick();
  });
  return a;
}

function frameLines(title, frames, bundles) {
  if (!frames.length) return [];
  return [
    title,
    ...frames.flatMap((f) => {
      const b = bundles.find((x) => stripQuery(x.url) === stripQuery(f.url));
      const mod = b && findModule(b.modules, toOffset(b.lineStarts, f.line, f.column));
      const line = `  ${f.fn || '(anonymous)'}  ${fileOf(f.url)}:${f.line}:${f.column}${mod ? `  ${mod.id}` : ''}`;
      return f.async ? [`  [${f.async}]`, line] : [line];
    }),
  ];
}

function stackText(e) {
  const bundles = cachedBundles();
  const title = { network: '요청을 보낸 호출 스택', browser: '브라우저가 알린 위치' }[e.kind] ?? '로그를 찍은 호출 스택';
  const lines = [...frameLines('오류가 난 위치', e.errorStack, bundles), ...frameLines(title, e.rawStack, bundles), ...frameLines('그 앞의 비동기 호출 스택', e.asyncStack, bundles)];
  return lines.length ? lines.join('\n') : '호출 스택 정보가 없습니다.';
}

function chromeFlagHelp() {
  const copy = actionButton('copy', '옵션 복사', '크롬 실행 옵션을 복사합니다', (b) => copyWithFeedback(b, CHROME_FLAG));
  return el(
    'span',
    null,
    '크롬 디버거 연결은 알아서 하고, 끊기면 알아서 다시 붙습니다. 연결된 동안 브라우저 위쪽에 뜨는 "디버깅을 시작함" 알림 줄은 크롬이 띄우는 것이라 확장이 숨길 수 없습니다. 거슬리면 크롬을 모두 닫고, 크롬 바로가기 → 속성 → 대상 끝에 한 칸 띄우고 아래 옵션을 붙여 그 바로가기로 실행하세요. 다른 확장의 디버거 알림 줄도 함께 숨겨집니다.',
    el('span', 'flag-row', el('code', null, CHROME_FLAG), copy),
  );
}

function actionButton(icon, label, title, onClick) {
  const button = el('button');
  button.innerHTML = `${iconSvg(icon, 12)}<span>${label}</span>`;
  button.title = title;
  button.addEventListener('click', () => onClick(button));
  return button;
}

function replay(e, button) {
  source
    .replay(e)
    .catch(() => false)
    .then((ok) => {
      const prev = button.innerHTML;
      button.textContent = ok ? 'Console에 출력함' : '원본이 페이지에서 지워졌습니다';
      setTimeout(() => (button.innerHTML = prev), 1500);
    });
}

function detailFor(e) {
  const stack = stackText(e);
  const pre = el('pre', 'log-stack');
  renderLinkedText(pre, stack, {
    onModule: (id) => {
      const c = e.chain?.find((x) => x.module === id);
      openInInspector(id, c?.line ?? null, c?.column ?? 1);
    },
  });
  const mod = focusModule(e);
  const where = e.where ? Object.assign(el('span', 'muted', e.where), { title: e.frameUrl }) : null;
  const actions = el(
    'div',
    'log-actions',
    actionButton('code', 'Console에 원본 출력', '객체를 펼쳐 볼 수 있게 크롬 Console에 원본 인자를 다시 찍습니다', (b) => replay(e, b)),
    mod ? actionButton('external', 'Inspector로', `${mod.module} 모듈을 3D Inspector 탭에서 엽니다`, () => openInInspector(mod.module, mod.line, mod.column)) : null,
    actionButton('copy', '복사', '문구와 호출 스택 복사', (b) => copyWithFeedback(b, [e.text, e.body && `응답 본문\n${e.body}`, stack].filter(Boolean).join('\n'))),
    e.kind === 'network' ? el('span', 'muted', `${e.duration}ms`) : null,
    where,
  );
  const body = e.kind === 'network' ? el('pre', 'log-full log-body', e.body ? `응답 본문\n${e.body}` : '응답 본문 없음') : null;
  return el('div', 'log-detail', el('pre', 'log-full', e.text), body, actions, pre);
}

function rowFor(g) {
  const e = g.entry;
  const mod = focusModule(e);
  const firstLine = e.text.split('\n')[0];
  const text = el('span', 'log-text', firstLine || ' ');
  text.title = e.text.length > 2000 ? `${e.text.slice(0, 2000)}…` : e.text;
  const line = el(
    'div',
    'log-line',
    el('span', 'log-time', timeText(e.time)),
    g.count > 1 ? el('span', 'count', String(g.count)) : null,
    e.kind ? el('span', 'log-kind', e.kind === 'network' ? 'API' : '브라우저') : null,
    text,
    mod ? anchor('link-mod log-mod', mod.module.split('/').at(-1), `${mod.module}\n3D Inspector 탭에서 열기`, () => openInInspector(mod.module, mod.line, mod.column)) : null,
    e.chain?.length > 1 ? el('span', 'muted log-more', `+${e.chain.length - 1}`) : null,
    e.file ? anchor('link-loc log-loc', `${e.file}:${e.line}:${e.column}`, 'Sources 탭에서 열기', () => openSourceLocation(e.file, e.line, e.column)) : null,
  );
  const row = el('div', `log-row lv-${e.level}${expanded.has(g.key) ? ' open' : ''}`, line, expanded.has(g.key) ? detailFor(e) : null);
  line.addEventListener('click', () => {
    if (getSelection().toString()) return;
    if (expanded.has(g.key)) expanded.delete(g.key);
    else expanded.add(g.key);
    const next = rowFor(g);
    next.classList.toggle('just-opened', expanded.has(g.key));
    row.replaceWith(next);
  });
  return row;
}

function excludePattern(x) {
  if (!x.regex) return x.name;
  try {
    return new RegExp(x.name, 'i');
  } catch {
    return null;
  }
}

function activeExcludes() {
  return state.excludes.filter((x) => x.on).map(excludePattern).filter(Boolean);
}

function renderStatus(lineCount) {
  const pending = entries.filter((e) => !e.chain).length;
  const basis = state.modules.length ? `모듈 ${state.modules.length}개 기준 (호출 스택에 있으면 표시)` : `제외 파일 ${activeExcludes().length}개`;
  const note = connection.state === 'error' && `크롬 디버거에 연결하지 못했습니다: ${connection.message}`;
  const parts = [note, `기록 ${entries.length}건`, `표시 ${lineCount}줄`, dropped && `누락 ${dropped}건`, pending && `모듈 확인 중 ${pending}건`, basis, statusNote];
  $('status').textContent = parts.filter(Boolean).join('  ·  ');
}

function render() {
  clearTimeout(renderTimer);
  renderTimer = null;
  const list = $('list');
  const atBottom = list.scrollHeight - list.scrollTop - list.clientHeight < 30;
  const text = findPattern($('textFilter'), textRegex, $('textFilter').value.trim());
  const { shown, counts } = filterLogs(entries, { modules: state.modules, excludes: activeExcludes(), levels: state.levels, browser: state.browser, text });
  document.querySelectorAll('[data-count]').forEach((c) => (c.querySelector('.n').textContent = counts[c.dataset.count] ? String(counts[c.dataset.count]) : ''));
  const groups = groupLogs(shown, state.group);
  renderStatus(groups.length);
  if (!entries.length) return renderHelp(list, [...USAGE, chromeFlagHelp()]);
  const omitted = groups.length - MAX_ROWS;
  const empty = state.modules.length
    ? '선택한 모듈이 호출 스택에 있는 로그가 아직 없습니다. 다른 모듈을 고르거나 선택을 해제하세요.'
    : '조건에 맞는 로그가 없습니다. 보기 · 제외 조건을 확인하세요.';
  list.replaceChildren(
    ...[
      omitted > 0 && el('div', 'message', `앞쪽 ${omitted}줄은 생략했습니다. 모듈이나 문구로 좁혀 보세요.`),
      ...groups.slice(-MAX_ROWS).map(rowFor),
      !groups.length && el('div', 'message', empty),
    ].filter(Boolean),
  );
  if (atBottom) list.scrollTop = list.scrollHeight;
}

function renderSelected() {
  $('selectedRow').hidden = !state.modules.length;
  $('selected').replaceChildren(
    ...state.modules.map((id) => {
      const x = setIcon(el('button', 'icon input-clear'), 'x', 12);
      x.title = '이 모듈 선택 해제';
      x.addEventListener('click', () => toggleModule(id));
      return el('span', 'sel-chip', el('span', 'mono', id.endsWith('/') ? `${id} (패키지 전체)` : id), x);
    }),
  );
  $('excludes').classList.toggle('dimmed', state.modules.length > 0);
  $('excludeNote').textContent = state.modules.length ? '모듈을 골랐으므로 제외 목록 대신 모듈 기준으로 보여줍니다' : '';
}

function setModules(list) {
  const hadModules = state.modules.length > 0;
  const next = [...new Set(list)];
  transitionLayout(() => {
    state.modules = next;
    save(KEYS.modules, state.modules);
    renderSelected();
    render();
  }, hadModules !== (next.length > 0));
}

function toggleModule(id) {
  setModules(state.modules.includes(id) ? state.modules.filter((m) => m !== id) : [...state.modules, id]);
}

function renderExcludes() {
  $('excludes').replaceChildren(
    ...state.excludes.map((x, i) => {
      const chip = el('button', 'chip ex-chip', x.regex ? `/${x.name}/` : x.name);
      setPressed(chip, x.on);
      chip.title = x.on ? `${x.regex ? '파일 이름이 이 정규식에 맞으면' : '이 파일이 찍은'} 로그를 숨깁니다 (눌러서 잠시 끄기)` : '꺼져 있습니다 (눌러서 다시 제외)';
      chip.addEventListener('click', () => updateExcludes(state.excludes.map((y, j) => (j === i ? { ...y, on: !y.on } : y))));
      const del = setIcon(el('button', 'icon input-clear'), 'x', 12);
      del.title = '제외 목록에서 지우기';
      del.addEventListener('click', () => updateExcludes(state.excludes.filter((_, j) => j !== i)));
      return el('span', 'ex-item', chip, del);
    }),
  );
}

function updateExcludes(next) {
  state.excludes = next;
  save(KEYS.excludes, next);
  renderExcludes();
  render();
}

function validateExclude() {
  return findPattern($('excludeInput'), excludeRegex, $('excludeInput').value.trim());
}

function addExclude() {
  const name = $('excludeInput').value.trim();
  const regex = excludeRegex.classList.contains('on');
  if (!name || !validateExclude()) return;
  if (!state.excludes.some((x) => Boolean(x.regex) === regex && x.name.toLowerCase() === name.toLowerCase())) updateExcludes([...state.excludes, { name, on: true, regex }]);
  $('excludeInput').value = '';
  syncClearButton($('excludeInput'));
}

function packageId(id) {
  const parts = id.split('/');
  return parts.length > 2 ? `${parts[0]}/${parts[1]}/` : null;
}

let suggestGen = 0;
let suggestIdx = -1;

function closeSuggest() {
  suggestGen += 1;
  $('moduleSuggest').hidden = true;
}

function suggestItem(id, meta) {
  const row = el('div', 'pop-item', el('span', 'mono', `${state.modules.includes(id) ? '✓ ' : ''}${id}`), el('span', 'meta', meta));
  row.dataset.id = id;
  row.addEventListener('click', () => {
    toggleModule(id);
    $('moduleInput').value = '';
    syncClearButton($('moduleInput'));
    closeSuggest();
  });
  return row;
}

let loadedModules = null;

function renderSuggest(all) {
  const q = $('moduleInput').value.trim().toLowerCase();
  const has = (id) => !q || id.toLowerCase().includes(q);
  const logged = countModules(entries).filter((m) => has(m.id));
  const loggedIds = new Set(logged.map((m) => m.id));
  const others = (all ?? []).filter((m) => !loggedIds.has(m.id) && (has(m.id) || m.file.toLowerCase().includes(q)));
  const packages = [...new Set([...logged, ...(all ?? [])].map((m) => packageId(m.id)))].filter((p) => p && has(p));
  const sections = [
    ['로그가 나온 모듈', logged.slice(0, 30).map((m) => suggestItem(m.id, `${m.count}건`))],
    ['패키지 전체', packages.slice(0, 8).map((p) => suggestItem(p, '패키지'))],
    ['로드된 모듈', others.slice(0, 40).map((m) => suggestItem(m.id, m.file))],
  ].filter(([, items]) => items.length);
  const menu = $('moduleSuggest');
  suggestIdx = -1;
  const note = all ? !sections.length && '일치하는 모듈이 없습니다. Enter를 누르면 입력한 이름을 그대로 추가합니다. (끝이 /면 패키지 전체)' : '로드된 모듈 목록을 읽는 중...';
  menu.replaceChildren(...sections.flatMap(([label, items]) => [el('div', 'pop-section', label), ...items]), ...(note ? [el('div', 'pop-empty', note)] : []));
  menu.hidden = false;
}

async function updateSuggest(reload = false) {
  const gen = ++suggestGen;
  if (reload || !loadedModules) {
    renderSuggest(null);
    loadedModules = loadBundles({ names: '', mode: 'contains', kinds: ['js'] }).then(listModules, () => []);
  }
  const all = await loadedModules;
  if (gen === suggestGen) renderSuggest(all);
}

function handleSuggestKey(e) {
  const menu = $('moduleSuggest');
  const items = [...menu.querySelectorAll('.pop-item')];
  if (e.key === 'Escape') return closeSuggest();
  if ((e.key === 'ArrowDown' || e.key === 'ArrowUp') && !menu.hidden && items.length) {
    e.preventDefault();
    suggestIdx = (suggestIdx + (e.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length;
    items.forEach((it, i) => it.classList.toggle('active', i === suggestIdx));
    items[suggestIdx].scrollIntoView({ block: 'nearest' });
    return;
  }
  if (e.key !== 'Enter') return;
  if (!menu.hidden && items[suggestIdx]) return items[suggestIdx].click();
  const raw = $('moduleInput').value.trim();
  if (!raw) return;
  toggleModule(raw);
  $('moduleInput').value = '';
  syncClearButton($('moduleInput'));
  closeSuggest();
}

function bindToggle(id, key, onChange = render) {
  setPressed($(id), state[key]);
  $(id).addEventListener('click', () => {
    state[key] = !state[key];
    save(KEYS[key], state[key]);
    setPressed($(id), state[key]);
    onChange();
  });
}

function followLatest() {
  const id = lastAnnouncedModule();
  if (state.follow && id) setModules([id]);
}

function handleAnnounce(id) {
  if (selfOpened === id) {
    selfOpened = null;
    return;
  }
  if (state.follow) setModules([id]);
}

function bindEvents() {
  document.querySelectorAll('#levels .chip').forEach((c) => {
    setPressed(c, state.levels.includes(c.dataset.level));
    c.addEventListener('click', () => {
      const lv = c.dataset.level;
      state.levels = state.levels.includes(lv) ? state.levels.filter((x) => x !== lv) : [...state.levels, lv];
      save(KEYS.levels, state.levels);
      setPressed(c, state.levels.includes(lv));
      render();
    });
  });
  bindToggle('groupBtn', 'group');
  bindToggle('browserBtn', 'browser');
  bindToggle('preserveBtn', 'preserve', () => {});
  bindToggle('followBtn', 'follow', followLatest);
  $('clearBtn').addEventListener('click', clearLogs);
  $('clearSelBtn').addEventListener('click', () => setModules([]));
  $('textFilter').addEventListener('input', render);
  $('excludeInput').addEventListener('input', validateExclude);
  $('excludeInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') addExclude();
  });
  $('moduleInput').addEventListener('focus', () => updateSuggest(true));
  $('moduleInput').addEventListener('input', () => updateSuggest());
  $('moduleInput').addEventListener('keydown', handleSuggestKey);
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.popover, .module-field')) closeSuggest();
  });
  document.addEventListener('keydown', (e) => {
    if (!(e.ctrlKey || e.metaKey) || e.shiftKey || e.altKey) return;
    const key = e.key.toLowerCase();
    if (key === 'k') {
      e.preventDefault();
      $('moduleInput').focus();
      updateSuggest();
    } else if (key === 'l') {
      e.preventDefault();
      clearLogs();
    }
  });
  listenModuleAnnounce(handleAnnounce);
  chrome.devtools?.network?.onNavigated?.addListener(() => {
    loadedModules = null;
  });
  window.addEventListener('pagehide', source.stop);
}

function reconnect() {
  clearLogs();
  source.start();
}

applyTheme();
setupIdentify();
$('clearBtn').innerHTML = `${iconSvg('trash', 13)}<span>비우기</span>`;
$('textFilter').dataset.title = '문구, 모듈 ID, 파일 이름에 이 글자가 있는 로그만 봅니다';
$('textFilter').title = $('textFilter').dataset.title;
makeClearable($('moduleInput'), { inline: true });
makeClearable($('textFilter'), { inline: true });
$('textFilter').parentElement.append(textRegex);
$('excludeInput').dataset.title = '파일 이름(스택 맨 위)에 이 글자가 있으면 그 파일이 찍은 로그를 숨깁니다. .*를 켜면 정규식(대소문자 무시)입니다';
$('excludeInput').title = $('excludeInput').dataset.title;
makeClearable($('excludeInput')).append(excludeRegex);
renderExcludes();
renderSelected();
bindEvents();
followLatest();
render();
source.start();
