(() => {
  const OVERLAY_ID = '_3di_locate_overlay';
  const SVG = '<svg width="132" height="132" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="2" y1="12" x2="5" y2="12"/><line x1="19" y1="12" x2="22" y2="12"/><line x1="12" y1="2" x2="12" y2="5"/><line x1="12" y1="19" x2="12" y2="22"/><circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="3"/></svg>';
  let active = false;

  function showOverlay() {
    const root = document.body || document.documentElement;
    if (!root) return;
    const prev = document.getElementById(OVERLAY_ID);
    if (prev && Date.now() - Number(prev.dataset.ts || 0) < 150) return;
    prev?.remove();
    const box = document.createElement('div');
    box.id = OVERLAY_ID;
    box.dataset.ts = String(Date.now());
    Object.assign(box.style, {
      position: 'fixed',
      bottom: 'clamp(12px, 4vh, 40px)',
      left: 'clamp(12px, 4vw, 40px)',
      width: 'min(220px, calc(100vw - 24px))',
      height: 'min(220px, calc(100vh - 24px))',
      backgroundColor: 'rgba(13, 56, 87, 0.88)',
      border: '1px solid rgba(255, 255, 255, 0.2)',
      borderRadius: '36px',
      boxShadow: '0 12px 32px rgba(0, 0, 0, 0.35)',
      zIndex: '2147483647',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: '8px',
      color: 'white',
      font: '600 13px/1.2 system-ui, sans-serif',
      pointerEvents: 'none',
      opacity: '0',
      transform: 'scale(0.6)',
      transition: 'opacity 0.35s ease, transform 0.35s cubic-bezier(0.34, 1.56, 0.64, 1)',
    });
    const label = document.createElement('span');
    label.textContent = '3D Inspector';
    box.innerHTML = SVG;
    box.append(label);
    root.append(box);
    const reveal = () => {
      box.style.opacity = '1';
      box.style.transform = 'scale(1)';
    };
    requestAnimationFrame(reveal);
    setTimeout(reveal, 40);
    setTimeout(() => {
      box.style.opacity = '0';
      box.style.transform = 'scale(1.15)';
      setTimeout(() => box.remove(), 350);
    }, 1800);
  }

  function cleanup() {
    window.removeEventListener('keydown', handleKeyDown, true);
    try {
      chrome.runtime?.onMessage?.removeListener(handleMessage);
    } catch {}
  }

  function syncActive() {
    try {
      if (!chrome?.runtime?.id) return;
      chrome.runtime.sendMessage({ action: 'GET_PAGE_ACTIVE' }, (res) => {
        if (!chrome.runtime.lastError && res) active = Boolean(res.active);
      });
    } catch {}
  }

  function isAltA(e) {
    if (!e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return false;
    return e.code === 'KeyA' || e.key === 'a' || e.key === 'A';
  }

  function isDashboardDom() {
    return /\/3ddashboard(?:\/|$|\?)/i.test(location.pathname) || Boolean(document.querySelector('script[src*="/webapps/"], script[src*="AmdLoader"]'));
  }

  function handleKeyDown(e) {
    if (!chrome?.runtime?.id) {
      cleanup();
      return;
    }
    if (!isAltA(e)) return;
    if (active || isDashboardDom()) {
      e.preventDefault();
      e.stopPropagation();
    }
    try {
      chrome.runtime.sendMessage({ action: 'IDENTIFY_DEVTOOLS' }, (res) => {
        if (!chrome.runtime.lastError && res?.ok) active = true;
      });
    } catch {
      cleanup();
    }
  }

  const handleMessage = (msg) => {
    if (msg?.action === '3DI_SET_ACTIVE') active = Boolean(msg.active);
    else if (msg?.action === 'SHOW_LOCATE_OVERLAY' && window.top === window.self) showOverlay();
  };

  if (window.__3diContentCleanup) {
    try {
      window.__3diContentCleanup();
    } catch {}
  }

  window.addEventListener('keydown', handleKeyDown, true);
  try {
    chrome.runtime?.onMessage?.addListener(handleMessage);
  } catch {}
  window.__3diContentCleanup = cleanup;

  syncActive();
})();
