const HOLO_POSE = ['--px', '--py', '--rx', '--ry', '--edge', '--shadow-x', '--shadow-y'];
const INFO_TILT = 14;
const CLOSE_MS = 200;
const DISMISSED_KEY = '3di.info.dismissedVersion';
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
const MARK = '<svg class="rs-mark" viewBox="0 0 956 504" aria-hidden="true"><use href="#rs-mark" /></svg>';
const ICON = new URL('icons/icon-128.png', import.meta.url).href;
const VCARD = {
  ko: "BEGIN:VCARD\nVERSION:3.0\nFN:(주)룰앤시스\nORG:(주)룰앤시스\nTEL;TYPE=WORK:02-6956-4761\nTEL;TYPE=FAX:02-6956-4769\nEMAIL:heeseok.jeong@rulensys.com\nADR;TYPE=WORK:;;법원로 127 (문정동) 대명벨리온 2층 212호;송파구;서울특별시;05836;대한민국\nNOTE:대표이사 정희석\nEND:VCARD",
  en: "BEGIN:VCARD\nVERSION:3.0\nFN:RuleNSys, INC.\nORG:RuleNSys, INC.\nTEL;TYPE=WORK:+82-2-6956-4761\nTEL;TYPE=FAX:+82-2-6956-4769\nEMAIL:heeseok.jeong@rulensys.com\nADR;TYPE=WORK:;;212, 2F, Daemyung Valion, 127 Beopwon-ro;Songpa-gu;Seoul;05836;Rep. of KOREA\nNOTE:CEO Heeseok Jeong\nEND:VCARD",
};

const SPRITE = `<svg class="sprite" aria-hidden="true">
  <defs>
    <mask id="rs-half" maskUnits="userSpaceOnUse" x="0" y="0" width="1300" height="700">
      <path d="M600 222C555 182 470 132 375 129C260 129 166 223 166 340C166 455 262 548 380 548C450 548 510 525 560 493L784 324" fill="none" stroke="#fff" stroke-width="72" />
      <polygon points="868,242 722,292 822,382" fill="#fff" />
      <polygon points="446,239 820,-21 906,102 532,362" fill="#000" />
    </mask>
    <symbol id="rs-mark" viewBox="130 88 956 504">
      <rect width="1300" height="700" fill="currentColor" mask="url(#rs-half)" />
      <rect width="1300" height="700" fill="currentColor" mask="url(#rs-half)" transform="rotate(180 607 340)" />
    </symbol>
    <symbol id="qr-ko" viewBox="0 0 61 61">
      <path d="M0 0h7v1h-7zM11 0h2v1h-2zM16 0h1v1h-1zM19 0h1v1h-1zM21 0h1v1h-1zM24 0h1v1h-1zM26 0h1v1h-1zM30 0h1v1h-1zM32 0h1v1h-1zM34 0h1v1h-1zM36 0h4v1h-4zM45 0h1v1h-1zM49 0h1v1h-1zM51 0h2v1h-2zM54 0h7v1h-7zM0 1h1v1h-1zM6 1h1v1h-1zM8 1h4v1h-4zM13 1h5v1h-5zM19 1h2v1h-2zM22 1h1v1h-1zM24 1h1v1h-1zM29 1h1v1h-1zM33 1h2v1h-2zM38 1h2v1h-2zM41 1h2v1h-2zM46 1h1v1h-1zM49 1h1v1h-1zM51 1h2v1h-2zM54 1h1v1h-1zM60 1h1v1h-1zM0 2h1v1h-1zM2 2h3v1h-3zM6 2h1v1h-1zM11 2h1v1h-1zM13 2h2v1h-2zM16 2h1v1h-1zM18 2h4v1h-4zM23 2h2v1h-2zM26 2h1v1h-1zM29 2h2v1h-2zM32 2h1v1h-1zM34 2h1v1h-1zM36 2h2v1h-2zM41 2h1v1h-1zM43 2h3v1h-3zM49 2h4v1h-4zM54 2h1v1h-1zM56 2h3v1h-3zM60 2h1v1h-1zM0 3h1v1h-1zM2 3h3v1h-3zM6 3h1v1h-1zM8 3h2v1h-2zM13 3h1v1h-1zM15 3h2v1h-2zM18 3h3v1h-3zM22 3h1v1h-1zM24 3h1v1h-1zM27 3h2v1h-2zM32 3h2v1h-2zM35 3h2v1h-2zM39 3h3v1h-3zM45 3h1v1h-1zM49 3h2v1h-2zM52 3h1v1h-1zM54 3h1v1h-1zM56 3h3v1h-3zM60 3h1v1h-1zM0 4h1v1h-1zM2 4h3v1h-3zM6 4h1v1h-1zM13 4h1v1h-1zM16 4h2v1h-2zM21 4h2v1h-2zM25 4h9v1h-9zM35 4h2v1h-2zM41 4h2v1h-2zM47 4h1v1h-1zM49 4h3v1h-3zM54 4h1v1h-1zM56 4h3v1h-3zM60 4h1v1h-1zM0 5h1v1h-1zM6 5h1v1h-1zM8 5h1v1h-1zM10 5h2v1h-2zM14 5h2v1h-2zM18 5h1v1h-1zM24 5h3v1h-3zM28 5h1v1h-1zM32 5h3v1h-3zM36 5h3v1h-3zM40 5h3v1h-3zM45 5h1v1h-1zM50 5h1v1h-1zM54 5h1v1h-1zM60 5h1v1h-1zM0 6h7v1h-7zM8 6h1v1h-1zM10 6h1v1h-1zM12 6h1v1h-1zM14 6h1v1h-1zM16 6h1v1h-1zM18 6h1v1h-1zM20 6h1v1h-1zM22 6h1v1h-1zM24 6h1v1h-1zM26 6h1v1h-1zM28 6h1v1h-1zM30 6h1v1h-1zM32 6h1v1h-1zM34 6h1v1h-1zM36 6h1v1h-1zM38 6h1v1h-1zM40 6h1v1h-1zM42 6h1v1h-1zM44 6h1v1h-1zM46 6h1v1h-1zM48 6h1v1h-1zM50 6h1v1h-1zM52 6h1v1h-1zM54 6h7v1h-7zM9 7h2v1h-2zM13 7h1v1h-1zM15 7h6v1h-6zM23 7h1v1h-1zM26 7h1v1h-1zM28 7h1v1h-1zM32 7h3v1h-3zM36 7h4v1h-4zM44 7h1v1h-1zM47 7h1v1h-1zM49 7h1v1h-1zM51 7h2v1h-2zM0 8h5v1h-5zM6 8h4v1h-4zM13 8h1v1h-1zM18 8h1v1h-1zM25 8h1v1h-1zM28 8h7v1h-7zM39 8h2v1h-2zM42 8h1v1h-1zM46 8h1v1h-1zM48 8h1v1h-1zM50 8h1v1h-1zM53 8h1v1h-1zM55 8h1v1h-1zM57 8h1v1h-1zM59 8h1v1h-1zM0 9h2v1h-2zM5 9h1v1h-1zM7 9h2v1h-2zM10 9h1v1h-1zM12 9h2v1h-2zM17 9h8v1h-8zM27 9h2v1h-2zM30 9h1v1h-1zM32 9h3v1h-3zM36 9h1v1h-1zM38 9h1v1h-1zM40 9h2v1h-2zM44 9h2v1h-2zM49 9h1v1h-1zM51 9h4v1h-4zM56 9h2v1h-2zM60 9h1v1h-1zM0 10h2v1h-2zM4 10h1v1h-1zM6 10h2v1h-2zM9 10h3v1h-3zM13 10h3v1h-3zM20 10h1v1h-1zM24 10h1v1h-1zM27 10h1v1h-1zM30 10h1v1h-1zM32 10h4v1h-4zM39 10h2v1h-2zM44 10h3v1h-3zM48 10h1v1h-1zM52 10h1v1h-1zM54 10h2v1h-2zM57 10h1v1h-1zM59 10h2v1h-2zM0 11h4v1h-4zM5 11h1v1h-1zM10 11h1v1h-1zM13 11h1v1h-1zM17 11h1v1h-1zM19 11h5v1h-5zM25 11h2v1h-2zM30 11h2v1h-2zM33 11h2v1h-2zM40 11h1v1h-1zM42 11h1v1h-1zM46 11h3v1h-3zM50 11h8v1h-8zM4 12h1v1h-1zM6 12h1v1h-1zM9 12h4v1h-4zM14 12h2v1h-2zM17 12h2v1h-2zM20 12h5v1h-5zM26 12h1v1h-1zM29 12h1v1h-1zM31 12h2v1h-2zM37 12h1v1h-1zM39 12h1v1h-1zM43 12h1v1h-1zM46 12h3v1h-3zM50 12h2v1h-2zM58 12h1v1h-1zM60 12h1v1h-1zM0 13h2v1h-2zM3 13h1v1h-1zM5 13h1v1h-1zM9 13h1v1h-1zM11 13h2v1h-2zM17 13h2v1h-2zM20 13h3v1h-3zM25 13h2v1h-2zM29 13h1v1h-1zM32 13h1v1h-1zM38 13h1v1h-1zM42 13h1v1h-1zM44 13h6v1h-6zM51 13h1v1h-1zM54 13h3v1h-3zM59 13h1v1h-1zM0 14h1v1h-1zM3 14h2v1h-2zM6 14h1v1h-1zM8 14h1v1h-1zM16 14h2v1h-2zM19 14h1v1h-1zM22 14h2v1h-2zM25 14h2v1h-2zM28 14h1v1h-1zM30 14h1v1h-1zM33 14h1v1h-1zM36 14h2v1h-2zM40 14h1v1h-1zM43 14h2v1h-2zM46 14h1v1h-1zM49 14h1v1h-1zM56 14h1v1h-1zM58 14h1v1h-1zM2 15h1v1h-1zM7 15h1v1h-1zM11 15h3v1h-3zM17 15h3v1h-3zM21 15h2v1h-2zM25 15h3v1h-3zM29 15h1v1h-1zM33 15h2v1h-2zM37 15h2v1h-2zM40 15h3v1h-3zM44 15h2v1h-2zM47 15h1v1h-1zM51 15h1v1h-1zM55 15h2v1h-2zM59 15h1v1h-1zM0 16h2v1h-2zM3 16h1v1h-1zM5 16h2v1h-2zM9 16h1v1h-1zM12 16h1v1h-1zM18 16h1v1h-1zM20 16h1v1h-1zM22 16h1v1h-1zM24 16h2v1h-2zM27 16h1v1h-1zM32 16h1v1h-1zM34 16h1v1h-1zM39 16h4v1h-4zM44 16h1v1h-1zM46 16h1v1h-1zM48 16h1v1h-1zM53 16h1v1h-1zM57 16h1v1h-1zM0 17h4v1h-4zM5 17h1v1h-1zM9 17h1v1h-1zM11 17h1v1h-1zM13 17h1v1h-1zM15 17h1v1h-1zM18 17h2v1h-2zM21 17h1v1h-1zM23 17h2v1h-2zM26 17h2v1h-2zM31 17h4v1h-4zM38 17h1v1h-1zM40 17h2v1h-2zM45 17h1v1h-1zM49 17h2v1h-2zM53 17h1v1h-1zM55 17h3v1h-3zM59 17h2v1h-2zM3 18h4v1h-4zM14 18h1v1h-1zM19 18h2v1h-2zM22 18h1v1h-1zM27 18h2v1h-2zM30 18h2v1h-2zM33 18h2v1h-2zM36 18h2v1h-2zM39 18h1v1h-1zM43 18h5v1h-5zM50 18h3v1h-3zM56 18h1v1h-1zM58 18h3v1h-3zM2 19h3v1h-3zM7 19h2v1h-2zM10 19h1v1h-1zM13 19h1v1h-1zM15 19h1v1h-1zM17 19h1v1h-1zM21 19h1v1h-1zM24 19h2v1h-2zM29 19h1v1h-1zM31 19h1v1h-1zM33 19h1v1h-1zM36 19h2v1h-2zM39 19h6v1h-6zM50 19h3v1h-3zM54 19h7v1h-7zM5 20h2v1h-2zM9 20h3v1h-3zM14 20h1v1h-1zM16 20h2v1h-2zM21 20h2v1h-2zM27 20h2v1h-2zM31 20h1v1h-1zM33 20h1v1h-1zM35 20h4v1h-4zM40 20h1v1h-1zM42 20h1v1h-1zM47 20h1v1h-1zM49 20h2v1h-2zM52 20h1v1h-1zM54 20h1v1h-1zM57 20h1v1h-1zM59 20h1v1h-1zM0 21h6v1h-6zM7 21h2v1h-2zM10 21h1v1h-1zM12 21h1v1h-1zM15 21h2v1h-2zM19 21h1v1h-1zM21 21h1v1h-1zM23 21h1v1h-1zM25 21h8v1h-8zM34 21h3v1h-3zM39 21h1v1h-1zM41 21h2v1h-2zM44 21h2v1h-2zM48 21h1v1h-1zM50 21h2v1h-2zM54 21h2v1h-2zM59 21h1v1h-1zM0 22h3v1h-3zM4 22h4v1h-4zM10 22h1v1h-1zM14 22h4v1h-4zM19 22h1v1h-1zM22 22h2v1h-2zM25 22h1v1h-1zM27 22h4v1h-4zM33 22h3v1h-3zM37 22h3v1h-3zM42 22h1v1h-1zM44 22h1v1h-1zM46 22h2v1h-2zM51 22h3v1h-3zM55 22h1v1h-1zM60 22h1v1h-1zM0 23h1v1h-1zM2 23h1v1h-1zM4 23h2v1h-2zM7 23h1v1h-1zM10 23h4v1h-4zM15 23h2v1h-2zM19 23h1v1h-1zM21 23h2v1h-2zM28 23h5v1h-5zM39 23h3v1h-3zM43 23h3v1h-3zM47 23h1v1h-1zM49 23h1v1h-1zM54 23h2v1h-2zM2 24h2v1h-2zM5 24h2v1h-2zM9 24h1v1h-1zM11 24h3v1h-3zM17 24h1v1h-1zM19 24h1v1h-1zM31 24h1v1h-1zM33 24h1v1h-1zM35 24h1v1h-1zM40 24h1v1h-1zM42 24h1v1h-1zM45 24h1v1h-1zM48 24h2v1h-2zM53 24h1v1h-1zM55 24h1v1h-1zM57 24h1v1h-1zM1 25h1v1h-1zM5 25h1v1h-1zM11 25h1v1h-1zM13 25h1v1h-1zM18 25h1v1h-1zM22 25h7v1h-7zM30 25h2v1h-2zM33 25h1v1h-1zM36 25h4v1h-4zM44 25h2v1h-2zM47 25h3v1h-3zM51 25h4v1h-4zM56 25h2v1h-2zM60 25h1v1h-1zM0 26h3v1h-3zM5 26h6v1h-6zM13 26h2v1h-2zM16 26h4v1h-4zM21 26h1v1h-1zM23 26h2v1h-2zM27 26h1v1h-1zM32 26h2v1h-2zM35 26h1v1h-1zM38 26h2v1h-2zM43 26h4v1h-4zM48 26h2v1h-2zM51 26h1v1h-1zM54 26h1v1h-1zM56 26h5v1h-5zM1 27h3v1h-3zM12 27h2v1h-2zM15 27h2v1h-2zM18 27h1v1h-1zM23 27h2v1h-2zM29 27h1v1h-1zM31 27h1v1h-1zM34 27h1v1h-1zM36 27h6v1h-6zM46 27h4v1h-4zM52 27h2v1h-2zM55 27h3v1h-3zM59 27h2v1h-2zM0 28h2v1h-2zM3 28h7v1h-7zM14 28h1v1h-1zM17 28h4v1h-4zM22 28h1v1h-1zM24 28h10v1h-10zM39 28h1v1h-1zM41 28h3v1h-3zM45 28h1v1h-1zM47 28h2v1h-2zM52 28h7v1h-7zM60 28h1v1h-1zM3 29h2v1h-2zM8 29h4v1h-4zM17 29h2v1h-2zM20 29h3v1h-3zM26 29h1v1h-1zM28 29h1v1h-1zM32 29h2v1h-2zM36 29h5v1h-5zM42 29h1v1h-1zM44 29h1v1h-1zM46 29h1v1h-1zM48 29h2v1h-2zM52 29h1v1h-1zM56 29h1v1h-1zM58 29h1v1h-1zM1 30h2v1h-2zM4 30h1v1h-1zM6 30h1v1h-1zM8 30h5v1h-5zM14 30h1v1h-1zM20 30h2v1h-2zM24 30h5v1h-5zM30 30h1v1h-1zM32 30h1v1h-1zM34 30h2v1h-2zM38 30h1v1h-1zM41 30h1v1h-1zM44 30h5v1h-5zM51 30h2v1h-2zM54 30h1v1h-1zM56 30h1v1h-1zM58 30h2v1h-2zM1 31h1v1h-1zM4 31h1v1h-1zM8 31h2v1h-2zM12 31h3v1h-3zM16 31h1v1h-1zM20 31h1v1h-1zM23 31h1v1h-1zM26 31h1v1h-1zM28 31h1v1h-1zM32 31h1v1h-1zM35 31h1v1h-1zM37 31h1v1h-1zM39 31h2v1h-2zM44 31h1v1h-1zM46 31h1v1h-1zM48 31h1v1h-1zM50 31h3v1h-3zM56 31h1v1h-1zM59 31h2v1h-2zM0 32h1v1h-1zM2 32h1v1h-1zM4 32h6v1h-6zM11 32h5v1h-5zM17 32h2v1h-2zM20 32h2v1h-2zM23 32h3v1h-3zM27 32h8v1h-8zM37 32h1v1h-1zM39 32h3v1h-3zM43 32h14v1h-14zM0 33h1v1h-1zM2 33h1v1h-1zM4 33h2v1h-2zM9 33h1v1h-1zM14 33h1v1h-1zM16 33h1v1h-1zM18 33h2v1h-2zM23 33h2v1h-2zM26 33h1v1h-1zM31 33h5v1h-5zM38 33h1v1h-1zM40 33h1v1h-1zM45 33h1v1h-1zM47 33h1v1h-1zM50 33h1v1h-1zM52 33h3v1h-3zM59 33h1v1h-1zM0 34h5v1h-5zM6 34h1v1h-1zM8 34h2v1h-2zM12 34h1v1h-1zM15 34h3v1h-3zM20 34h5v1h-5zM27 34h3v1h-3zM32 34h3v1h-3zM38 34h3v1h-3zM42 34h1v1h-1zM44 34h1v1h-1zM46 34h2v1h-2zM50 34h2v1h-2zM54 34h1v1h-1zM57 34h1v1h-1zM60 34h1v1h-1zM3 35h1v1h-1zM9 35h1v1h-1zM12 35h1v1h-1zM14 35h1v1h-1zM16 35h1v1h-1zM18 35h5v1h-5zM24 35h1v1h-1zM26 35h3v1h-3zM30 35h1v1h-1zM32 35h1v1h-1zM34 35h1v1h-1zM36 35h2v1h-2zM39 35h1v1h-1zM41 35h4v1h-4zM46 35h6v1h-6zM53 35h1v1h-1zM55 35h2v1h-2zM58 35h3v1h-3zM0 36h2v1h-2zM4 36h1v1h-1zM6 36h1v1h-1zM11 36h1v1h-1zM14 36h1v1h-1zM21 36h3v1h-3zM25 36h3v1h-3zM33 36h1v1h-1zM35 36h2v1h-2zM38 36h5v1h-5zM51 36h1v1h-1zM55 36h6v1h-6zM3 37h1v1h-1zM8 37h1v1h-1zM13 37h1v1h-1zM15 37h2v1h-2zM18 37h2v1h-2zM21 37h2v1h-2zM24 37h1v1h-1zM26 37h1v1h-1zM28 37h1v1h-1zM30 37h1v1h-1zM32 37h5v1h-5zM39 37h1v1h-1zM42 37h1v1h-1zM47 37h2v1h-2zM50 37h4v1h-4zM59 37h1v1h-1zM0 38h1v1h-1zM3 38h1v1h-1zM6 38h2v1h-2zM9 38h1v1h-1zM11 38h1v1h-1zM13 38h1v1h-1zM15 38h1v1h-1zM18 38h1v1h-1zM21 38h1v1h-1zM24 38h1v1h-1zM26 38h2v1h-2zM29 38h1v1h-1zM32 38h7v1h-7zM40 38h2v1h-2zM44 38h2v1h-2zM47 38h2v1h-2zM51 38h2v1h-2zM56 38h1v1h-1zM58 38h1v1h-1zM60 38h1v1h-1zM0 39h1v1h-1zM2 39h1v1h-1zM7 39h2v1h-2zM10 39h2v1h-2zM13 39h2v1h-2zM16 39h4v1h-4zM22 39h1v1h-1zM26 39h1v1h-1zM28 39h1v1h-1zM30 39h2v1h-2zM33 39h4v1h-4zM38 39h3v1h-3zM42 39h1v1h-1zM45 39h3v1h-3zM53 39h1v1h-1zM56 39h1v1h-1zM59 39h1v1h-1zM2 40h1v1h-1zM4 40h1v1h-1zM6 40h1v1h-1zM8 40h5v1h-5zM16 40h1v1h-1zM18 40h1v1h-1zM23 40h1v1h-1zM25 40h1v1h-1zM31 40h1v1h-1zM33 40h2v1h-2zM37 40h3v1h-3zM41 40h1v1h-1zM43 40h1v1h-1zM45 40h1v1h-1zM48 40h1v1h-1zM50 40h8v1h-8zM0 41h1v1h-1zM5 41h1v1h-1zM7 41h2v1h-2zM10 41h4v1h-4zM15 41h1v1h-1zM17 41h4v1h-4zM22 41h4v1h-4zM31 41h1v1h-1zM35 41h1v1h-1zM38 41h1v1h-1zM44 41h1v1h-1zM46 41h1v1h-1zM48 41h2v1h-2zM53 41h2v1h-2zM58 41h2v1h-2zM2 42h2v1h-2zM5 42h3v1h-3zM9 42h1v1h-1zM11 42h1v1h-1zM14 42h3v1h-3zM20 42h1v1h-1zM22 42h1v1h-1zM25 42h3v1h-3zM29 42h1v1h-1zM33 42h1v1h-1zM38 42h4v1h-4zM43 42h1v1h-1zM45 42h2v1h-2zM48 42h2v1h-2zM51 42h1v1h-1zM54 42h2v1h-2zM60 42h1v1h-1zM1 43h1v1h-1zM5 43h1v1h-1zM8 43h2v1h-2zM12 43h2v1h-2zM15 43h1v1h-1zM17 43h4v1h-4zM24 43h1v1h-1zM27 43h3v1h-3zM31 43h1v1h-1zM33 43h2v1h-2zM37 43h2v1h-2zM40 43h3v1h-3zM45 43h5v1h-5zM52 43h2v1h-2zM56 43h2v1h-2zM59 43h2v1h-2zM3 44h1v1h-1zM5 44h2v1h-2zM8 44h3v1h-3zM12 44h3v1h-3zM16 44h3v1h-3zM20 44h3v1h-3zM26 44h1v1h-1zM29 44h2v1h-2zM32 44h4v1h-4zM39 44h1v1h-1zM45 44h5v1h-5zM52 44h1v1h-1zM54 44h3v1h-3zM58 44h1v1h-1zM60 44h1v1h-1zM0 45h1v1h-1zM4 45h1v1h-1zM7 45h1v1h-1zM11 45h3v1h-3zM15 45h1v1h-1zM17 45h5v1h-5zM23 45h1v1h-1zM25 45h1v1h-1zM27 45h1v1h-1zM36 45h1v1h-1zM38 45h1v1h-1zM42 45h2v1h-2zM45 45h3v1h-3zM49 45h1v1h-1zM51 45h4v1h-4zM57 45h1v1h-1zM59 45h1v1h-1zM0 46h1v1h-1zM4 46h3v1h-3zM9 46h4v1h-4zM14 46h1v1h-1zM18 46h1v1h-1zM22 46h1v1h-1zM24 46h2v1h-2zM27 46h3v1h-3zM32 46h6v1h-6zM41 46h1v1h-1zM43 46h2v1h-2zM46 46h1v1h-1zM51 46h4v1h-4zM56 46h3v1h-3zM1 47h5v1h-5zM8 47h3v1h-3zM17 47h12v1h-12zM30 47h3v1h-3zM34 47h1v1h-1zM37 47h1v1h-1zM39 47h3v1h-3zM43 47h3v1h-3zM48 47h1v1h-1zM53 47h4v1h-4zM0 48h2v1h-2zM5 48h2v1h-2zM10 48h1v1h-1zM12 48h3v1h-3zM17 48h2v1h-2zM20 48h1v1h-1zM22 48h1v1h-1zM24 48h2v1h-2zM28 48h1v1h-1zM31 48h1v1h-1zM33 48h1v1h-1zM35 48h1v1h-1zM40 48h2v1h-2zM44 48h2v1h-2zM47 48h3v1h-3zM51 48h5v1h-5zM57 48h1v1h-1zM0 49h4v1h-4zM7 49h2v1h-2zM11 49h2v1h-2zM15 49h1v1h-1zM18 49h1v1h-1zM21 49h1v1h-1zM23 49h2v1h-2zM29 49h1v1h-1zM31 49h1v1h-1zM34 49h5v1h-5zM45 49h1v1h-1zM47 49h2v1h-2zM50 49h1v1h-1zM52 49h1v1h-1zM54 49h1v1h-1zM56 49h1v1h-1zM58 49h1v1h-1zM60 49h1v1h-1zM2 50h6v1h-6zM9 50h1v1h-1zM17 50h4v1h-4zM23 50h1v1h-1zM25 50h2v1h-2zM29 50h3v1h-3zM33 50h4v1h-4zM38 50h8v1h-8zM49 50h1v1h-1zM51 50h1v1h-1zM54 50h4v1h-4zM59 50h2v1h-2zM0 51h3v1h-3zM4 51h1v1h-1zM7 51h3v1h-3zM12 51h1v1h-1zM15 51h1v1h-1zM18 51h1v1h-1zM21 51h1v1h-1zM24 51h2v1h-2zM27 51h1v1h-1zM30 51h1v1h-1zM32 51h2v1h-2zM36 51h1v1h-1zM38 51h2v1h-2zM43 51h1v1h-1zM47 51h2v1h-2zM51 51h3v1h-3zM56 51h3v1h-3zM60 51h1v1h-1zM0 52h4v1h-4zM6 52h1v1h-1zM8 52h1v1h-1zM11 52h1v1h-1zM14 52h3v1h-3zM19 52h1v1h-1zM21 52h1v1h-1zM23 52h1v1h-1zM26 52h1v1h-1zM28 52h6v1h-6zM35 52h3v1h-3zM39 52h2v1h-2zM43 52h1v1h-1zM45 52h2v1h-2zM51 52h7v1h-7zM60 52h1v1h-1zM8 53h2v1h-2zM11 53h4v1h-4zM16 53h4v1h-4zM21 53h1v1h-1zM25 53h1v1h-1zM27 53h2v1h-2zM32 53h3v1h-3zM40 53h2v1h-2zM43 53h1v1h-1zM47 53h6v1h-6zM56 53h3v1h-3zM60 53h1v1h-1zM0 54h7v1h-7zM8 54h4v1h-4zM15 54h1v1h-1zM17 54h1v1h-1zM20 54h3v1h-3zM24 54h2v1h-2zM28 54h1v1h-1zM30 54h1v1h-1zM32 54h1v1h-1zM39 54h2v1h-2zM45 54h1v1h-1zM47 54h1v1h-1zM50 54h1v1h-1zM52 54h1v1h-1zM54 54h1v1h-1zM56 54h1v1h-1zM59 54h2v1h-2zM0 55h1v1h-1zM6 55h1v1h-1zM9 55h1v1h-1zM14 55h1v1h-1zM16 55h1v1h-1zM20 55h1v1h-1zM26 55h3v1h-3zM32 55h1v1h-1zM34 55h1v1h-1zM36 55h1v1h-1zM38 55h4v1h-4zM45 55h2v1h-2zM51 55h2v1h-2zM56 55h1v1h-1zM0 56h1v1h-1zM2 56h3v1h-3zM6 56h1v1h-1zM8 56h1v1h-1zM12 56h3v1h-3zM17 56h1v1h-1zM19 56h1v1h-1zM23 56h1v1h-1zM25 56h1v1h-1zM27 56h6v1h-6zM34 56h1v1h-1zM38 56h2v1h-2zM42 56h2v1h-2zM46 56h1v1h-1zM48 56h10v1h-10zM60 56h1v1h-1zM0 57h1v1h-1zM2 57h3v1h-3zM6 57h1v1h-1zM8 57h4v1h-4zM18 57h1v1h-1zM22 57h3v1h-3zM28 57h1v1h-1zM36 57h1v1h-1zM38 57h1v1h-1zM42 57h1v1h-1zM44 57h3v1h-3zM48 57h2v1h-2zM52 57h1v1h-1zM54 57h3v1h-3zM60 57h1v1h-1zM0 58h1v1h-1zM2 58h3v1h-3zM6 58h1v1h-1zM8 58h4v1h-4zM13 58h1v1h-1zM15 58h1v1h-1zM18 58h2v1h-2zM22 58h1v1h-1zM24 58h2v1h-2zM27 58h6v1h-6zM35 58h1v1h-1zM39 58h2v1h-2zM44 58h4v1h-4zM51 58h1v1h-1zM57 58h2v1h-2zM60 58h1v1h-1zM0 59h1v1h-1zM6 59h1v1h-1zM8 59h1v1h-1zM11 59h1v1h-1zM13 59h2v1h-2zM18 59h1v1h-1zM21 59h1v1h-1zM24 59h2v1h-2zM28 59h1v1h-1zM30 59h1v1h-1zM32 59h4v1h-4zM37 59h2v1h-2zM40 59h1v1h-1zM44 59h1v1h-1zM47 59h1v1h-1zM49 59h3v1h-3zM55 59h3v1h-3zM60 59h1v1h-1zM0 60h7v1h-7zM8 60h3v1h-3zM13 60h1v1h-1zM15 60h1v1h-1zM17 60h2v1h-2zM21 60h2v1h-2zM26 60h4v1h-4zM31 60h1v1h-1zM33 60h1v1h-1zM37 60h1v1h-1zM39 60h1v1h-1zM41 60h2v1h-2zM44 60h1v1h-1zM48 60h1v1h-1zM51 60h4v1h-4zM56 60h1v1h-1zM58 60h3v1h-3z" />
    </symbol>
    <symbol id="qr-en" viewBox="0 0 61 61">
      <path d="M0 0h7v1h-7zM11 0h3v1h-3zM15 0h1v1h-1zM19 0h1v1h-1zM21 0h1v1h-1zM23 0h1v1h-1zM26 0h1v1h-1zM30 0h1v1h-1zM32 0h1v1h-1zM35 0h1v1h-1zM40 0h4v1h-4zM45 0h1v1h-1zM51 0h2v1h-2zM54 0h7v1h-7zM0 1h1v1h-1zM6 1h1v1h-1zM8 1h1v1h-1zM11 1h2v1h-2zM19 1h2v1h-2zM25 1h2v1h-2zM29 1h1v1h-1zM31 1h1v1h-1zM33 1h4v1h-4zM38 1h2v1h-2zM46 1h1v1h-1zM51 1h2v1h-2zM54 1h1v1h-1zM60 1h1v1h-1zM0 2h1v1h-1zM2 2h3v1h-3zM6 2h1v1h-1zM9 2h1v1h-1zM11 2h2v1h-2zM14 2h2v1h-2zM17 2h1v1h-1zM19 2h2v1h-2zM23 2h1v1h-1zM25 2h1v1h-1zM29 2h2v1h-2zM34 2h1v1h-1zM36 2h2v1h-2zM39 2h1v1h-1zM41 2h4v1h-4zM50 2h3v1h-3zM54 2h1v1h-1zM56 2h3v1h-3zM60 2h1v1h-1zM0 3h1v1h-1zM2 3h3v1h-3zM6 3h1v1h-1zM8 3h5v1h-5zM15 3h5v1h-5zM25 3h1v1h-1zM27 3h2v1h-2zM31 3h6v1h-6zM41 3h2v1h-2zM45 3h2v1h-2zM48 3h3v1h-3zM52 3h1v1h-1zM54 3h1v1h-1zM56 3h3v1h-3zM60 3h1v1h-1zM0 4h1v1h-1zM2 4h3v1h-3zM6 4h1v1h-1zM9 4h1v1h-1zM12 4h1v1h-1zM14 4h2v1h-2zM17 4h3v1h-3zM21 4h1v1h-1zM23 4h2v1h-2zM26 4h7v1h-7zM34 4h3v1h-3zM39 4h5v1h-5zM47 4h1v1h-1zM50 4h2v1h-2zM54 4h1v1h-1zM56 4h3v1h-3zM60 4h1v1h-1zM0 5h1v1h-1zM6 5h1v1h-1zM8 5h1v1h-1zM10 5h1v1h-1zM12 5h1v1h-1zM14 5h4v1h-4zM19 5h1v1h-1zM23 5h2v1h-2zM27 5h2v1h-2zM32 5h2v1h-2zM36 5h4v1h-4zM42 5h4v1h-4zM50 5h1v1h-1zM54 5h1v1h-1zM60 5h1v1h-1zM0 6h7v1h-7zM8 6h1v1h-1zM10 6h1v1h-1zM12 6h1v1h-1zM14 6h1v1h-1zM16 6h1v1h-1zM18 6h1v1h-1zM20 6h1v1h-1zM22 6h1v1h-1zM24 6h1v1h-1zM26 6h1v1h-1zM28 6h1v1h-1zM30 6h1v1h-1zM32 6h1v1h-1zM34 6h1v1h-1zM36 6h1v1h-1zM38 6h1v1h-1zM40 6h1v1h-1zM42 6h1v1h-1zM44 6h1v1h-1zM46 6h1v1h-1zM48 6h1v1h-1zM50 6h1v1h-1zM52 6h1v1h-1zM54 6h7v1h-7zM10 7h2v1h-2zM13 7h1v1h-1zM19 7h2v1h-2zM23 7h3v1h-3zM27 7h2v1h-2zM32 7h1v1h-1zM34 7h1v1h-1zM36 7h1v1h-1zM40 7h1v1h-1zM42 7h2v1h-2zM46 7h1v1h-1zM49 7h1v1h-1zM51 7h1v1h-1zM0 8h5v1h-5zM6 8h5v1h-5zM12 8h2v1h-2zM17 8h1v1h-1zM19 8h1v1h-1zM27 8h6v1h-6zM34 8h3v1h-3zM38 8h2v1h-2zM43 8h1v1h-1zM47 8h2v1h-2zM50 8h1v1h-1zM52 8h2v1h-2zM55 8h1v1h-1zM57 8h1v1h-1zM59 8h1v1h-1zM3 9h2v1h-2zM8 9h1v1h-1zM11 9h3v1h-3zM18 9h1v1h-1zM21 9h5v1h-5zM28 9h1v1h-1zM30 9h1v1h-1zM41 9h2v1h-2zM44 9h1v1h-1zM47 9h3v1h-3zM51 9h1v1h-1zM53 9h2v1h-2zM56 9h1v1h-1zM60 9h1v1h-1zM6 10h1v1h-1zM8 10h1v1h-1zM10 10h2v1h-2zM15 10h1v1h-1zM17 10h3v1h-3zM22 10h1v1h-1zM24 10h1v1h-1zM27 10h1v1h-1zM29 10h1v1h-1zM31 10h2v1h-2zM37 10h3v1h-3zM41 10h1v1h-1zM44 10h1v1h-1zM46 10h3v1h-3zM51 10h1v1h-1zM54 10h2v1h-2zM57 10h4v1h-4zM1 11h2v1h-2zM5 11h1v1h-1zM8 11h5v1h-5zM17 11h1v1h-1zM21 11h1v1h-1zM23 11h1v1h-1zM28 11h3v1h-3zM32 11h6v1h-6zM40 11h1v1h-1zM42 11h1v1h-1zM45 11h1v1h-1zM48 11h4v1h-4zM53 11h2v1h-2zM57 11h1v1h-1zM5 12h2v1h-2zM12 12h2v1h-2zM16 12h6v1h-6zM24 12h2v1h-2zM27 12h2v1h-2zM31 12h2v1h-2zM36 12h1v1h-1zM39 12h1v1h-1zM43 12h1v1h-1zM45 12h1v1h-1zM47 12h2v1h-2zM51 12h1v1h-1zM53 12h1v1h-1zM55 12h1v1h-1zM58 12h1v1h-1zM60 12h1v1h-1zM2 13h1v1h-1zM4 13h2v1h-2zM12 13h1v1h-1zM15 13h1v1h-1zM18 13h1v1h-1zM22 13h3v1h-3zM28 13h1v1h-1zM30 13h2v1h-2zM35 13h2v1h-2zM42 13h1v1h-1zM44 13h1v1h-1zM47 13h2v1h-2zM54 13h1v1h-1zM60 13h1v1h-1zM1 14h3v1h-3zM5 14h3v1h-3zM10 14h1v1h-1zM13 14h3v1h-3zM17 14h1v1h-1zM20 14h2v1h-2zM24 14h8v1h-8zM33 14h1v1h-1zM36 14h1v1h-1zM40 14h1v1h-1zM44 14h2v1h-2zM47 14h1v1h-1zM49 14h2v1h-2zM53 14h1v1h-1zM55 14h1v1h-1zM58 14h3v1h-3zM0 15h3v1h-3zM4 15h1v1h-1zM8 15h1v1h-1zM12 15h1v1h-1zM14 15h6v1h-6zM23 15h5v1h-5zM30 15h3v1h-3zM34 15h2v1h-2zM37 15h2v1h-2zM40 15h2v1h-2zM44 15h2v1h-2zM47 15h1v1h-1zM55 15h2v1h-2zM1 16h6v1h-6zM9 16h1v1h-1zM12 16h4v1h-4zM18 16h1v1h-1zM20 16h2v1h-2zM23 16h3v1h-3zM29 16h2v1h-2zM32 16h1v1h-1zM34 16h3v1h-3zM42 16h2v1h-2zM46 16h1v1h-1zM48 16h1v1h-1zM50 16h1v1h-1zM53 16h1v1h-1zM57 16h1v1h-1zM60 16h1v1h-1zM0 17h1v1h-1zM2 17h1v1h-1zM4 17h1v1h-1zM8 17h3v1h-3zM16 17h1v1h-1zM18 17h2v1h-2zM24 17h1v1h-1zM26 17h2v1h-2zM29 17h4v1h-4zM36 17h1v1h-1zM41 17h2v1h-2zM44 17h2v1h-2zM49 17h1v1h-1zM54 17h3v1h-3zM59 17h2v1h-2zM0 18h1v1h-1zM4 18h6v1h-6zM14 18h3v1h-3zM18 18h3v1h-3zM22 18h4v1h-4zM27 18h5v1h-5zM33 18h2v1h-2zM36 18h1v1h-1zM38 18h3v1h-3zM43 18h1v1h-1zM45 18h3v1h-3zM51 18h3v1h-3zM56 18h1v1h-1zM59 18h2v1h-2zM0 19h1v1h-1zM3 19h3v1h-3zM10 19h1v1h-1zM16 19h1v1h-1zM21 19h1v1h-1zM24 19h3v1h-3zM29 19h3v1h-3zM33 19h1v1h-1zM36 19h2v1h-2zM41 19h1v1h-1zM44 19h2v1h-2zM50 19h7v1h-7zM59 19h2v1h-2zM0 20h3v1h-3zM6 20h2v1h-2zM9 20h2v1h-2zM12 20h1v1h-1zM14 20h8v1h-8zM23 20h1v1h-1zM25 20h1v1h-1zM27 20h2v1h-2zM30 20h2v1h-2zM35 20h4v1h-4zM47 20h2v1h-2zM51 20h4v1h-4zM57 20h1v1h-1zM59 20h1v1h-1zM0 21h4v1h-4zM5 21h1v1h-1zM9 21h2v1h-2zM12 21h1v1h-1zM22 21h9v1h-9zM32 21h2v1h-2zM35 21h2v1h-2zM41 21h2v1h-2zM44 21h1v1h-1zM47 21h1v1h-1zM49 21h1v1h-1zM51 21h1v1h-1zM54 21h1v1h-1zM59 21h1v1h-1zM0 22h2v1h-2zM3 22h2v1h-2zM6 22h1v1h-1zM8 22h1v1h-1zM12 22h3v1h-3zM16 22h1v1h-1zM18 22h2v1h-2zM22 22h2v1h-2zM25 22h7v1h-7zM35 22h1v1h-1zM37 22h3v1h-3zM42 22h1v1h-1zM47 22h1v1h-1zM50 22h1v1h-1zM52 22h2v1h-2zM55 22h1v1h-1zM60 22h1v1h-1zM0 23h2v1h-2zM3 23h1v1h-1zM7 23h3v1h-3zM12 23h3v1h-3zM16 23h4v1h-4zM21 23h3v1h-3zM26 23h2v1h-2zM29 23h3v1h-3zM33 23h1v1h-1zM36 23h2v1h-2zM40 23h7v1h-7zM49 23h1v1h-1zM52 23h1v1h-1zM54 23h2v1h-2zM59 23h2v1h-2zM3 24h1v1h-1zM5 24h3v1h-3zM9 24h1v1h-1zM12 24h1v1h-1zM14 24h1v1h-1zM18 24h1v1h-1zM25 24h2v1h-2zM28 24h1v1h-1zM31 24h1v1h-1zM33 24h2v1h-2zM36 24h4v1h-4zM41 24h2v1h-2zM47 24h3v1h-3zM51 24h3v1h-3zM55 24h1v1h-1zM57 24h1v1h-1zM59 24h1v1h-1zM0 25h4v1h-4zM5 25h1v1h-1zM7 25h1v1h-1zM9 25h1v1h-1zM14 25h1v1h-1zM17 25h4v1h-4zM22 25h3v1h-3zM27 25h1v1h-1zM29 25h1v1h-1zM31 25h1v1h-1zM39 25h1v1h-1zM41 25h2v1h-2zM44 25h1v1h-1zM47 25h3v1h-3zM51 25h1v1h-1zM53 25h2v1h-2zM56 25h3v1h-3zM60 25h1v1h-1zM1 26h1v1h-1zM5 26h3v1h-3zM9 26h3v1h-3zM13 26h2v1h-2zM16 26h2v1h-2zM20 26h5v1h-5zM26 26h1v1h-1zM29 26h1v1h-1zM33 26h1v1h-1zM35 26h1v1h-1zM38 26h2v1h-2zM43 26h2v1h-2zM46 26h1v1h-1zM48 26h2v1h-2zM51 26h1v1h-1zM54 26h1v1h-1zM56 26h1v1h-1zM59 26h2v1h-2zM1 27h5v1h-5zM7 27h3v1h-3zM11 27h1v1h-1zM13 27h5v1h-5zM19 27h2v1h-2zM22 27h4v1h-4zM27 27h1v1h-1zM29 27h3v1h-3zM34 27h1v1h-1zM36 27h6v1h-6zM45 27h3v1h-3zM50 27h1v1h-1zM52 27h4v1h-4zM57 27h1v1h-1zM0 28h3v1h-3zM4 28h5v1h-5zM10 28h5v1h-5zM16 28h6v1h-6zM23 28h3v1h-3zM28 28h6v1h-6zM35 28h1v1h-1zM38 28h2v1h-2zM41 28h2v1h-2zM45 28h2v1h-2zM48 28h9v1h-9zM58 28h3v1h-3zM0 29h5v1h-5zM8 29h4v1h-4zM14 29h2v1h-2zM17 29h2v1h-2zM22 29h3v1h-3zM27 29h2v1h-2zM32 29h2v1h-2zM37 29h4v1h-4zM42 29h3v1h-3zM47 29h3v1h-3zM51 29h2v1h-2zM56 29h1v1h-1zM58 29h3v1h-3zM0 30h1v1h-1zM3 30h2v1h-2zM6 30h1v1h-1zM8 30h2v1h-2zM11 30h4v1h-4zM16 30h1v1h-1zM19 30h2v1h-2zM22 30h1v1h-1zM25 30h4v1h-4zM30 30h1v1h-1zM32 30h1v1h-1zM34 30h2v1h-2zM41 30h1v1h-1zM43 30h1v1h-1zM45 30h5v1h-5zM52 30h1v1h-1zM54 30h1v1h-1zM56 30h1v1h-1zM58 30h3v1h-3zM2 31h3v1h-3zM8 31h4v1h-4zM14 31h3v1h-3zM21 31h2v1h-2zM26 31h3v1h-3zM32 31h1v1h-1zM34 31h2v1h-2zM40 31h1v1h-1zM43 31h1v1h-1zM46 31h1v1h-1zM48 31h2v1h-2zM51 31h2v1h-2zM56 31h1v1h-1zM59 31h1v1h-1zM0 32h3v1h-3zM4 32h6v1h-6zM12 32h3v1h-3zM17 32h2v1h-2zM20 32h1v1h-1zM22 32h1v1h-1zM24 32h2v1h-2zM27 32h10v1h-10zM41 32h3v1h-3zM45 32h4v1h-4zM50 32h7v1h-7zM59 32h1v1h-1zM0 33h1v1h-1zM4 33h1v1h-1zM11 33h1v1h-1zM13 33h3v1h-3zM18 33h2v1h-2zM21 33h1v1h-1zM23 33h1v1h-1zM26 33h1v1h-1zM28 33h1v1h-1zM33 33h1v1h-1zM35 33h1v1h-1zM37 33h1v1h-1zM40 33h3v1h-3zM45 33h1v1h-1zM47 33h1v1h-1zM51 33h2v1h-2zM55 33h1v1h-1zM57 33h1v1h-1zM59 33h1v1h-1zM0 34h1v1h-1zM2 34h1v1h-1zM4 34h1v1h-1zM6 34h2v1h-2zM10 34h3v1h-3zM14 34h1v1h-1zM17 34h2v1h-2zM20 34h3v1h-3zM25 34h1v1h-1zM27 34h1v1h-1zM29 34h1v1h-1zM31 34h5v1h-5zM39 34h1v1h-1zM46 34h2v1h-2zM50 34h2v1h-2zM54 34h3v1h-3zM60 34h1v1h-1zM0 35h3v1h-3zM4 35h2v1h-2zM9 35h1v1h-1zM13 35h1v1h-1zM15 35h1v1h-1zM17 35h4v1h-4zM22 35h2v1h-2zM25 35h1v1h-1zM27 35h1v1h-1zM34 35h1v1h-1zM36 35h2v1h-2zM39 35h1v1h-1zM41 35h6v1h-6zM49 35h1v1h-1zM51 35h1v1h-1zM53 35h1v1h-1zM55 35h3v1h-3zM59 35h2v1h-2zM0 36h1v1h-1zM3 36h4v1h-4zM8 36h1v1h-1zM10 36h1v1h-1zM12 36h2v1h-2zM15 36h4v1h-4zM27 36h1v1h-1zM29 36h1v1h-1zM31 36h6v1h-6zM38 36h1v1h-1zM42 36h1v1h-1zM45 36h1v1h-1zM47 36h3v1h-3zM51 36h1v1h-1zM54 36h4v1h-4zM59 36h2v1h-2zM0 37h3v1h-3zM4 37h2v1h-2zM9 37h2v1h-2zM12 37h2v1h-2zM17 37h1v1h-1zM19 37h1v1h-1zM23 37h4v1h-4zM28 37h1v1h-1zM30 37h3v1h-3zM34 37h3v1h-3zM40 37h1v1h-1zM42 37h1v1h-1zM45 37h1v1h-1zM47 37h3v1h-3zM51 37h2v1h-2zM0 38h5v1h-5zM6 38h1v1h-1zM8 38h2v1h-2zM11 38h1v1h-1zM13 38h1v1h-1zM15 38h1v1h-1zM17 38h1v1h-1zM21 38h1v1h-1zM23 38h2v1h-2zM27 38h1v1h-1zM29 38h1v1h-1zM32 38h2v1h-2zM35 38h5v1h-5zM41 38h1v1h-1zM44 38h1v1h-1zM46 38h3v1h-3zM50 38h2v1h-2zM54 38h1v1h-1zM56 38h1v1h-1zM58 38h1v1h-1zM60 38h1v1h-1zM3 39h2v1h-2zM7 39h1v1h-1zM9 39h1v1h-1zM11 39h1v1h-1zM15 39h1v1h-1zM22 39h4v1h-4zM28 39h1v1h-1zM31 39h1v1h-1zM39 39h3v1h-3zM51 39h3v1h-3zM56 39h1v1h-1zM0 40h1v1h-1zM5 40h6v1h-6zM12 40h3v1h-3zM16 40h2v1h-2zM19 40h1v1h-1zM23 40h1v1h-1zM28 40h4v1h-4zM34 40h1v1h-1zM36 40h1v1h-1zM39 40h1v1h-1zM42 40h2v1h-2zM47 40h2v1h-2zM50 40h3v1h-3zM55 40h3v1h-3zM60 40h1v1h-1zM0 41h1v1h-1zM3 41h1v1h-1zM7 41h2v1h-2zM10 41h2v1h-2zM13 41h1v1h-1zM15 41h1v1h-1zM18 41h1v1h-1zM22 41h4v1h-4zM28 41h4v1h-4zM33 41h1v1h-1zM35 41h1v1h-1zM37 41h1v1h-1zM39 41h1v1h-1zM41 41h2v1h-2zM44 41h1v1h-1zM48 41h2v1h-2zM51 41h2v1h-2zM59 41h2v1h-2zM2 42h1v1h-1zM5 42h2v1h-2zM11 42h2v1h-2zM14 42h3v1h-3zM18 42h2v1h-2zM21 42h1v1h-1zM25 42h5v1h-5zM31 42h2v1h-2zM34 42h1v1h-1zM36 42h1v1h-1zM40 42h1v1h-1zM43 42h1v1h-1zM45 42h5v1h-5zM51 42h1v1h-1zM53 42h3v1h-3zM60 42h1v1h-1zM0 43h2v1h-2zM4 43h1v1h-1zM7 43h2v1h-2zM11 43h1v1h-1zM14 43h2v1h-2zM21 43h1v1h-1zM24 43h1v1h-1zM26 43h2v1h-2zM29 43h1v1h-1zM31 43h1v1h-1zM33 43h4v1h-4zM40 43h3v1h-3zM44 43h1v1h-1zM48 43h2v1h-2zM54 43h4v1h-4zM59 43h2v1h-2zM0 44h2v1h-2zM5 44h3v1h-3zM11 44h1v1h-1zM13 44h9v1h-9zM24 44h2v1h-2zM29 44h2v1h-2zM32 44h3v1h-3zM36 44h2v1h-2zM39 44h1v1h-1zM43 44h1v1h-1zM47 44h2v1h-2zM51 44h1v1h-1zM54 44h3v1h-3zM58 44h1v1h-1zM60 44h1v1h-1zM0 45h1v1h-1zM4 45h2v1h-2zM11 45h1v1h-1zM13 45h3v1h-3zM18 45h1v1h-1zM22 45h1v1h-1zM24 45h1v1h-1zM27 45h2v1h-2zM35 45h2v1h-2zM42 45h1v1h-1zM44 45h1v1h-1zM48 45h2v1h-2zM53 45h2v1h-2zM57 45h1v1h-1zM60 45h1v1h-1zM0 46h11v1h-11zM14 46h3v1h-3zM18 46h1v1h-1zM21 46h1v1h-1zM25 46h1v1h-1zM29 46h1v1h-1zM33 46h2v1h-2zM36 46h2v1h-2zM41 46h1v1h-1zM43 46h4v1h-4zM48 46h2v1h-2zM51 46h4v1h-4zM56 46h5v1h-5zM1 47h1v1h-1zM4 47h2v1h-2zM8 47h1v1h-1zM10 47h2v1h-2zM15 47h4v1h-4zM20 47h1v1h-1zM23 47h1v1h-1zM25 47h2v1h-2zM28 47h1v1h-1zM31 47h2v1h-2zM34 47h1v1h-1zM38 47h1v1h-1zM41 47h1v1h-1zM44 47h2v1h-2zM48 47h9v1h-9zM59 47h1v1h-1zM1 48h1v1h-1zM4 48h1v1h-1zM6 48h1v1h-1zM9 48h1v1h-1zM13 48h3v1h-3zM17 48h2v1h-2zM20 48h2v1h-2zM23 48h3v1h-3zM28 48h3v1h-3zM32 48h1v1h-1zM35 48h3v1h-3zM41 48h1v1h-1zM45 48h1v1h-1zM47 48h2v1h-2zM51 48h1v1h-1zM54 48h1v1h-1zM57 48h1v1h-1zM1 49h3v1h-3zM7 49h1v1h-1zM9 49h1v1h-1zM12 49h3v1h-3zM16 49h1v1h-1zM18 49h1v1h-1zM24 49h1v1h-1zM28 49h1v1h-1zM31 49h2v1h-2zM35 49h3v1h-3zM39 49h7v1h-7zM47 49h2v1h-2zM53 49h3v1h-3zM57 49h2v1h-2zM60 49h1v1h-1zM2 50h5v1h-5zM8 50h1v1h-1zM10 50h1v1h-1zM13 50h4v1h-4zM18 50h3v1h-3zM23 50h2v1h-2zM26 50h3v1h-3zM30 50h1v1h-1zM32 50h1v1h-1zM34 50h3v1h-3zM40 50h1v1h-1zM43 50h1v1h-1zM45 50h1v1h-1zM50 50h1v1h-1zM54 50h1v1h-1zM56 50h5v1h-5zM0 51h3v1h-3zM4 51h1v1h-1zM8 51h2v1h-2zM12 51h1v1h-1zM16 51h1v1h-1zM18 51h1v1h-1zM21 51h1v1h-1zM24 51h3v1h-3zM28 51h4v1h-4zM33 51h1v1h-1zM36 51h1v1h-1zM38 51h2v1h-2zM43 51h4v1h-4zM49 51h1v1h-1zM51 51h2v1h-2zM54 51h3v1h-3zM60 51h1v1h-1zM0 52h4v1h-4zM6 52h1v1h-1zM8 52h1v1h-1zM10 52h1v1h-1zM12 52h5v1h-5zM18 52h2v1h-2zM25 52h1v1h-1zM27 52h6v1h-6zM35 52h3v1h-3zM45 52h5v1h-5zM51 52h7v1h-7zM60 52h1v1h-1zM8 53h4v1h-4zM13 53h1v1h-1zM15 53h1v1h-1zM19 53h1v1h-1zM23 53h3v1h-3zM27 53h2v1h-2zM32 53h2v1h-2zM39 53h7v1h-7zM47 53h1v1h-1zM49 53h1v1h-1zM51 53h2v1h-2zM56 53h4v1h-4zM0 54h7v1h-7zM8 54h2v1h-2zM11 54h2v1h-2zM14 54h3v1h-3zM18 54h2v1h-2zM21 54h3v1h-3zM25 54h2v1h-2zM28 54h1v1h-1zM30 54h1v1h-1zM32 54h1v1h-1zM41 54h2v1h-2zM44 54h3v1h-3zM48 54h3v1h-3zM52 54h1v1h-1zM54 54h1v1h-1zM56 54h1v1h-1zM60 54h1v1h-1zM0 55h1v1h-1zM6 55h1v1h-1zM9 55h2v1h-2zM13 55h1v1h-1zM16 55h3v1h-3zM20 55h1v1h-1zM24 55h1v1h-1zM26 55h3v1h-3zM32 55h3v1h-3zM36 55h1v1h-1zM39 55h4v1h-4zM46 55h1v1h-1zM48 55h1v1h-1zM51 55h2v1h-2zM56 55h1v1h-1zM59 55h2v1h-2zM0 56h1v1h-1zM2 56h3v1h-3zM6 56h1v1h-1zM8 56h1v1h-1zM10 56h2v1h-2zM13 56h1v1h-1zM18 56h1v1h-1zM23 56h1v1h-1zM25 56h12v1h-12zM38 56h2v1h-2zM41 56h3v1h-3zM45 56h13v1h-13zM59 56h1v1h-1zM0 57h1v1h-1zM2 57h3v1h-3zM6 57h1v1h-1zM8 57h2v1h-2zM12 57h3v1h-3zM17 57h4v1h-4zM22 57h3v1h-3zM28 57h1v1h-1zM30 57h1v1h-1zM32 57h1v1h-1zM37 57h1v1h-1zM39 57h4v1h-4zM44 57h1v1h-1zM48 57h2v1h-2zM51 57h1v1h-1zM54 57h3v1h-3zM60 57h1v1h-1zM0 58h1v1h-1zM2 58h3v1h-3zM6 58h1v1h-1zM8 58h1v1h-1zM10 58h1v1h-1zM12 58h1v1h-1zM14 58h2v1h-2zM20 58h1v1h-1zM24 58h1v1h-1zM27 58h4v1h-4zM35 58h1v1h-1zM38 58h1v1h-1zM40 58h1v1h-1zM42 58h1v1h-1zM44 58h3v1h-3zM48 58h1v1h-1zM53 58h2v1h-2zM57 58h2v1h-2zM60 58h1v1h-1zM0 59h1v1h-1zM6 59h1v1h-1zM8 59h2v1h-2zM12 59h2v1h-2zM17 59h1v1h-1zM19 59h2v1h-2zM24 59h3v1h-3zM28 59h1v1h-1zM30 59h1v1h-1zM32 59h3v1h-3zM36 59h3v1h-3zM40 59h1v1h-1zM44 59h1v1h-1zM46 59h3v1h-3zM50 59h1v1h-1zM52 59h1v1h-1zM54 59h4v1h-4zM60 59h1v1h-1zM0 60h7v1h-7zM8 60h1v1h-1zM10 60h2v1h-2zM14 60h1v1h-1zM16 60h1v1h-1zM18 60h4v1h-4zM29 60h1v1h-1zM31 60h1v1h-1zM33 60h1v1h-1zM35 60h1v1h-1zM38 60h2v1h-2zM41 60h3v1h-3zM46 60h4v1h-4zM51 60h1v1h-1zM53 60h1v1h-1zM56 60h5v1h-5z" />
    </symbol>
  </defs>
</svg>`;

const cardHtml = (version) => `<div id="info" hidden>
  <div class="info-panel">
    <div id="info-stage" class="holo holo-stage">
      <div class="holo-tilt">
        <div class="holo-flipper">
          <div class="holo-face holo-front">
            <div class="info-card" role="dialog" aria-label="3D Inspector 정보">
              <div class="info-card-bg" aria-hidden="true"></div>
              <div class="info-head">
                <h3 class="info-title">3D Inspector</h3>
                <div class="info-brand">
                  <button id="info-link" class="info-link" type="button" title="명함 보기" aria-label="명함 보기">
                    ${MARK}
                    <span class="brand-name mode-swap">
                      <span class="dark-only">Rule<span class="info-amp">&amp;</span>Sys</span>
                      <span class="brand-ko light-only"><span class="brand-ko-corp">(주)</span>룰앤시스</span>
                    </span>
                    <svg class="info-link-icon" viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><rect x="2" y="4" width="20" height="16" rx="2.5" /><circle cx="8.5" cy="10.5" r="2" /><path d="M5.5 16c.6-1.5 1.7-2.2 3-2.2s2.4.7 3 2.2" /><path d="M14.5 9.5h4.5" /><path d="M14.5 13h3.5" /></svg>
                  </button>
                  <span class="info-tagline">Your AX Service Partner</span>
                </div>
              </div>
              <div class="info-body">
                <div class="info-main">
                  <div class="info-icon-box">
                    <img class="info-icon" src="${ICON}" alt="3D Inspector" />
                  </div>
                  <div class="info-rows">
                    <div class="info-row"><span>버전</span><span class="info-value">${version}</span></div>
                    <div class="info-row"><span>테스트 환경</span><span class="info-value">R2026x</span></div>
                    <div class="info-row info-runtimes">
                      <span>실행 환경</span>
                      <span class="info-chips"><span class="info-chip">Chrome</span><span class="info-chip">Edge</span></span>
                    </div>
                  </div>
                </div>
                <div class="info-foot">
                  <div class="info-credit">Created with ✨ by <span class="mode-swap"><span class="dark-only">Lee Ou Hyoun</span><span class="credit-ko light-only">이우현</span></span></div>
                  <button class="info-lang-btn" type="button" title="한/영 전환" aria-label="한/영 전환"><span class="mode-swap"><span class="light-only">EN</span><span class="dark-only">한</span></span></button>
                </div>
              </div>
            </div>
            <div class="holo-foil" aria-hidden="true"></div>
            <div class="holo-shine" aria-hidden="true"></div>
          </div>
          <div class="holo-face holo-back" aria-hidden="true">
            <div class="biz-card" role="region" aria-label="Rule&amp;Sys 대표이사 명함">
              <div class="biz-top">
                <div class="biz-person">
                  <h4 class="biz-name biz-ko">정 희 석</h4>
                  <h4 class="biz-name biz-en">Heeseok Jeong</h4>
                  <span class="biz-role biz-ko">대표이사</span>
                  <span class="biz-role biz-en">CEO</span>
                </div>
                <button class="biz-brand" type="button" data-action="flip-back" title="정보 카드로 돌아가기" aria-label="정보 카드로 돌아가기">
                  <div class="biz-brand-row">
                    <span class="biz-mark-wrap">
                      ${MARK}
                      <span class="biz-mark-foil" aria-hidden="true"></span>
                      <span class="biz-mark-shine" aria-hidden="true"></span>
                    </span>
                    <span class="biz-wordmark">Rule&amp;Sys</span>
                  </div>
                  <span class="biz-tagline">Your AX Service Partner</span>
                </button>
              </div>
              <div class="biz-mid">
                <div class="biz-contact">
                  <button class="biz-copy-btn biz-ko" type="button" data-copy="02-6956-4761" data-label="대표전화">
                    <span class="biz-key">Tel.</span><span class="biz-val">02-6956-4761</span><svg class="biz-copy-ico" viewBox="0 0 24 24" width="10" height="10" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" /></svg>
                  </button>
                  <button class="biz-copy-btn biz-en" type="button" data-copy="+82-2-6956-4761" data-label="Tel">
                    <span class="biz-key">Tel.</span><span class="biz-val">+82-2-6956-4761</span><svg class="biz-copy-ico" viewBox="0 0 24 24" width="10" height="10" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" /></svg>
                  </button>
                  <button class="biz-copy-btn biz-ko" type="button" data-copy="02-6956-4769" data-label="팩스">
                    <span class="biz-key">Fax.</span><span class="biz-val">02-6956-4769</span><svg class="biz-copy-ico" viewBox="0 0 24 24" width="10" height="10" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" /></svg>
                  </button>
                  <button class="biz-copy-btn biz-en" type="button" data-copy="+82-2-6956-4769" data-label="Fax">
                    <span class="biz-key">Fax.</span><span class="biz-val">+82-2-6956-4769</span><svg class="biz-copy-ico" viewBox="0 0 24 24" width="10" height="10" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" /></svg>
                  </button>
                  <button class="biz-copy-btn" type="button" data-copy="heeseok.jeong@rulensys.com" data-label-ko="이메일" data-label-en="E-mail">
                    <span class="biz-key">E-mail.</span><span class="biz-val">heeseok.jeong@rulensys.com</span><svg class="biz-copy-ico" viewBox="0 0 24 24" width="10" height="10" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" /></svg>
                  </button>
                </div>
                <button class="biz-mini-qr" type="button" data-action="qr" title="QR 크게 보기 · vCard 저장" aria-label="QR 크게 보기">
                  <svg class="biz-ko" viewBox="0 0 61 61" aria-hidden="true"><use href="#qr-ko" /></svg>
                  <svg class="biz-en" viewBox="0 0 61 61" aria-hidden="true"><use href="#qr-en" /></svg>
                </button>
              </div>
              <div class="biz-footer">
                <div class="biz-org-row">
                  <span class="biz-org biz-ko">(주) 룰앤시스</span>
                  <span class="biz-org biz-en">RuleNSys, INC.</span>
                  <span class="biz-rule" aria-hidden="true"></span>
                  <div class="biz-tools">
                    <button class="biz-tool-btn" type="button" data-action="lang" title="한/영 명함 전환" aria-label="한/영 명함 전환"><span class="biz-ko">EN</span><span class="biz-en">한</span></button>
                  </div>
                </div>
                <button class="biz-copy-btn biz-addr biz-ko" type="button" data-copy="05836 서울특별시 송파구 법원로 127 (문정동) 대명벨리온 2층 212호" data-label="주소">
                  <span>05836 서울특별시 송파구 법원로 127 (문정동) 대명벨리온 2층 212호</span>
                </button>
                <button class="biz-copy-btn biz-addr biz-en" type="button" data-copy="212, 2F, Daemyung Valion, 127 Beopwon-ro, Songpa-gu, Seoul, 05836, Rep. of KOREA" data-label="Address">
                  <span>212, 2F, Daemyung Valion, 127 Beopwon-ro, Songpa-gu<br>Seoul, 05836, Rep. of KOREA</span>
                </button>
              </div>
              <div class="biz-qr-layer" aria-hidden="true">
                <div class="biz-qr-frame">
                  <svg class="biz-qr-svg biz-ko" viewBox="0 0 61 61" shape-rendering="crispEdges" role="img" aria-label="(주)룰앤시스 대표 연락처 QR 코드"><use href="#qr-ko" /></svg>
                  <svg class="biz-qr-svg biz-en" viewBox="0 0 61 61" shape-rendering="crispEdges" role="img" aria-label="RuleNSys Company Contact QR Code"><use href="#qr-en" /></svg>
                </div>
                <div class="biz-qr-info">
                  <span class="biz-qr-kicker">${MARK}Company Contact</span>
                  <h5 class="biz-qr-title biz-ko">(주) 룰앤시스</h5>
                  <h5 class="biz-qr-title biz-en">RuleNSys, INC.</h5>
                  <p class="biz-qr-desc biz-ko">대표전화·이메일·오피스 주소를 스마트폰에 바로 저장할 수 있습니다.</p>
                  <p class="biz-qr-desc biz-en">Save office phone, e-mail &amp; address to your contacts.</p>
                  <div class="biz-qr-actions">
                    <button class="biz-qr-btn" type="button" data-action="vcf"><span class="biz-ko">.vcf 저장</span><span class="biz-en">Save .vcf</span></button>
                    <button class="biz-qr-btn is-secondary" type="button" data-action="qr-close"><span class="biz-ko">닫기</span><span class="biz-en">Close</span></button>
                  </div>
                </div>
              </div>
              <div class="biz-toast" role="status" aria-live="polite"></div>
            </div>
            <div class="biz-sheen" aria-hidden="true"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>`;

const openerHtml = (version) => `<button id="info-open" class="info-open" type="button" title="3D Inspector 정보" aria-label="3D Inspector 정보">${MARK}<span>${version && `v${version}`}</span></button>`;

async function copyText(value) {
  if (navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(value);
      return true;
    } catch {}
  }
  const area = document.createElement('textarea');
  area.value = value;
  area.style.position = 'fixed';
  area.style.opacity = '0';
  document.body.appendChild(area);
  area.select();
  let ok = false;
  try {
    ok = document.execCommand('copy');
  } catch {}
  area.remove();
  return ok;
}

function downloadVcard(lang) {
  const blob = new Blob([VCARD[lang]], { type: 'text/vcard;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = lang === 'ko' ? 'RuleNSys_룰앤시스.vcf' : 'RuleNSys_Contact.vcf';
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function holoTracker(stage, tilt) {
  let frame = 0;
  const reset = () => {
    cancelAnimationFrame(frame);
    stage.classList.remove('is-active');
    for (const name of HOLO_POSE) stage.style.removeProperty(name);
  };
  const pose = (event) => {
    cancelAnimationFrame(frame);
    frame = requestAnimationFrame(() => {
      const rect = stage.getBoundingClientRect();
      if (reducedMotion.matches || !rect.width || !rect.height) return;
      const x = Math.min(1, Math.max(0, (event.clientX - rect.left) / rect.width));
      const y = Math.min(1, Math.max(0, (event.clientY - rect.top) / rect.height));
      const values = [
        `${x * 100}%`,
        `${y * 100}%`,
        `${(y - 0.5) * tilt * 1.2}deg`,
        `${(0.5 - x) * tilt * 2}deg`,
        String(Math.min(1, Math.hypot(x - 0.5, y - 0.5) * 2)),
        `${(x - 0.5) * 40}px`,
        `${20 + (y - 0.5) * 32}px`,
      ];
      HOLO_POSE.forEach((name, index) => stage.style.setProperty(name, values[index]));
      stage.classList.add('is-active');
    });
  };
  return { pose, reset };
}

function readDismissed() {
  try {
    return localStorage.getItem(DISMISSED_KEY) ?? '';
  } catch {
    return '';
  }
}

function markDismissed(value) {
  try {
    localStorage.setItem(DISMISSED_KEY, value);
  } catch {}
}

export function setupInfo(host) {
  const version = globalThis.chrome?.runtime?.getManifest?.()?.version ?? '';
  const dismissToken = version || '1';
  document.body.insertAdjacentHTML('afterbegin', SPRITE);
  document.body.insertAdjacentHTML('beforeend', cardHtml(version));
  host.insertAdjacentHTML('beforeend', openerHtml(version));

  const info = document.getElementById('info');
  const opener = document.getElementById('info-open');
  const panel = info.querySelector('.info-panel');
  const stage = document.getElementById('info-stage');
  const front = stage.querySelector('.holo-front');
  const back = stage.querySelector('.holo-back');
  const bizCard = stage.querySelector('.biz-card');
  const qrLayer = stage.querySelector('.biz-qr-layer');
  const toast = stage.querySelector('.biz-toast');
  const langBtn = stage.querySelector('.info-lang-btn');
  const holo = holoTracker(stage, INFO_TILT);
  let closeTimer = 0;
  let toastTimer = 0;

  const isOpen = () => !info.hidden && !info.classList.contains('closing');

  const syncLangToTheme = () => {
    stage.dataset.lang = document.documentElement.dataset.theme === 'dark' ? 'en' : 'ko';
  };

  const toggleLang = () => {
    stage.dataset.lang = stage.dataset.lang === 'ko' ? 'en' : 'ko';
  };

  const syncAria = () => {
    const flipped = stage.classList.contains('is-flipped');
    front.setAttribute('aria-hidden', String(flipped));
    back.setAttribute('aria-hidden', String(!flipped));
    qrLayer.setAttribute('aria-hidden', String(!bizCard.classList.contains('is-qr-open')));
  };

  const setQrOpen = (open) => {
    bizCard.classList.toggle('is-qr-open', open);
    syncAria();
  };

  const setFlipped = (flipped) => {
    if (!flipped) bizCard.classList.remove('is-qr-open');
    stage.classList.toggle('is-flipped', flipped);
    syncAria();
  };

  const showToast = (message) => {
    clearTimeout(toastTimer);
    toast.textContent = message;
    toast.classList.add('is-show');
    toastTimer = setTimeout(() => toast.classList.remove('is-show'), 1450);
  };

  const setOpen = (open) => {
    if (open === isOpen()) return;
    clearTimeout(closeTimer);
    if (open) {
      syncLangToTheme();
      setFlipped(false);
      info.classList.remove('closing');
      info.hidden = false;
      return;
    }
    if (readDismissed() !== dismissToken) markDismissed(dismissToken);
    holo.reset();
    info.classList.add('closing');
    closeTimer = setTimeout(() => {
      info.hidden = true;
      info.classList.remove('closing');
      setFlipped(false);
    }, CLOSE_MS);
  };

  syncLangToTheme();
  syncAria();
  new MutationObserver(syncLangToTheme).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });

  opener.addEventListener('click', () => {
    setOpen(!isOpen());
  });

  stage.addEventListener('click', () => {
    if (!stage.classList.contains('is-flipped')) setOpen(false);
  });

  document.getElementById('info-link').addEventListener('click', (event) => {
    event.stopPropagation();
    setFlipped(true);
  });

  langBtn.addEventListener('click', (event) => {
    event.stopPropagation();
    toggleLang();
  });

  back.addEventListener('click', async (event) => {
    event.stopPropagation();
    const copyBtn = event.target instanceof Element ? event.target.closest('.biz-copy-btn') : null;
    if (copyBtn) {
      const lang = stage.dataset.lang || 'ko';
      const label = copyBtn.dataset.label || (lang === 'ko' ? copyBtn.dataset.labelKo : copyBtn.dataset.labelEn);
      if (await copyText(copyBtn.dataset.copy)) {
        showToast(lang === 'ko' ? `${label} 복사됨 ✓` : `${label} copied ✓`);
      }
      return;
    }
    const actionBtn = event.target instanceof Element ? event.target.closest('[data-action]') : null;
    if (!actionBtn) return;
    const action = actionBtn.dataset.action;
    if (action === 'flip-back') setFlipped(false);
    else if (action === 'lang') toggleLang();
    else if (action === 'qr') setQrOpen(!bizCard.classList.contains('is-qr-open'));
    else if (action === 'qr-close') setQrOpen(false);
    else if (action === 'vcf') {
      const lang = stage.dataset.lang || 'ko';
      downloadVcard(lang);
      showToast(lang === 'ko' ? 'vCard 저장됨 ✓' : 'vCard saved ✓');
    }
  });

  for (const type of ['pointerenter', 'pointermove']) stage.addEventListener(type, holo.pose);
  for (const type of ['pointerleave', 'pointercancel']) stage.addEventListener(type, holo.reset);

  window.addEventListener('pointerdown', (event) => {
    if (!isOpen() || panel.contains(event.target) || opener.contains(event.target)) return;
    setOpen(false);
  }, true);

  window.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape' || !isOpen()) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (bizCard.classList.contains('is-qr-open')) setQrOpen(false);
    else if (stage.classList.contains('is-flipped')) setFlipped(false);
    else setOpen(false);
  }, true);

  window.addEventListener('storage', (event) => {
    if (event.key === DISMISSED_KEY && event.newValue === dismissToken) setOpen(false);
  });

  if (!location.protocol.startsWith('http') && readDismissed() !== dismissToken) setOpen(true);
}
