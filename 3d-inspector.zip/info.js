const HOLO_POSE = ['--px', '--py', '--rx', '--ry', '--edge', '--shadow-x', '--shadow-y'];
const INFO_TILT = 14;
const CLOSE_MS = 200;
const DISMISSED_KEY = '3di.info.dismissedVersion';
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
const MARK = '<svg class="rs-mark" viewBox="0 0 956 504" aria-hidden="true"><use href="#rs-mark" /></svg>';
const ICON = new URL('icons/icon-128.png', import.meta.url).href;

const SPRITE = `<svg class="sprite" aria-hidden="true">
  <defs>
    <mask id="rs-half" maskUnits="userSpaceOnUse" x="0" y="0" width="1300" height="700">
      <path d="M600 222C555 182 470 132 375 129C260 129 166 223 166 340C166 455 262 548 380 548C450 548 510 525 560 493L784 324" fill="none" stroke="#fff" stroke-width="72" />
      <polygon points="868,242 722,292 822,382" fill="#fff" />
      <polygon points="446,239 820,-21 906,102 532,362" fill="#000" />
    </mask>
    <symbol id="rs-mark" viewBox="130 88 956 504">
      <rect width="1300" height="700" fill="currentColor" mask="url(#rs-half)" />
      <rect width="1300" height="700" fill="currentColor" mask="url(#rs-half)" transform="rotate(180 607 340)" />
    </symbol>
  </defs>
</svg>`;

const cardHtml = (version) => `<div id="info" hidden>
  <div class="info-panel">
    <div id="info-stage" class="holo holo-stage">
      <div class="holo-card">
        <div class="info-card" role="dialog" aria-label="3D Inspector 정보">
          <div class="info-card-bg" aria-hidden="true"></div>
          <div class="info-head">
            <h3 class="info-title">3D Inspector</h3>
            <div class="info-brand">
              <button id="info-link" class="info-link" type="button">
                ${MARK}
                <span class="brand-name mode-swap">
                  <span class="dark-only">Rule<span class="info-amp">&amp;</span>Sys</span>
                  <span class="brand-ko light-only"><span class="brand-ko-corp">(주)</span>룰앤시스</span>
                </span>
                <svg class="info-link-icon" viewBox="0 0 24 24" width="13" height="13" aria-hidden="true"><path d="M15 3h6v6" /><path d="M10 14 21 3" /><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /></svg>
              </button>
              <span class="info-tagline">Your AX Service Partner</span>
            </div>
          </div>
          <div class="info-body">
            <div class="info-main">
              <div class="info-icon-box">
                <img class="info-icon" src="${ICON}" alt="3D Inspector" />
              </div>
              <div class="info-rows">
                <div class="info-row"><span>버전</span><span class="info-value">${version}</span></div>
                <div class="info-row"><span>테스트 환경</span><span class="info-value">R2026x</span></div>
                <div class="info-row info-runtimes">
                  <span>실행 환경</span>
                  <span class="info-chips"><span class="info-chip">Chrome</span><span class="info-chip">Edge</span></span>
                </div>
              </div>
            </div>
            <div class="info-credit">Created with ✨ by <span class="mode-swap"><span class="dark-only">Lee Ou Hyoun</span><span class="credit-ko light-only">이우현</span></span></div>
          </div>
        </div>
        <div class="holo-foil" aria-hidden="true"></div>
        <div class="holo-shine" aria-hidden="true"></div>
      </div>
    </div>
  </div>
</div>`;

const openerHtml = (version) => `<button id="info-open" class="info-open" type="button" title="3D Inspector 정보" aria-label="3D Inspector 정보">${MARK}<span>${version && `v${version}`}</span></button>`;

function holoTracker(stage, tilt) {
  let frame = 0;
  const reset = () => {
    cancelAnimationFrame(frame);
    stage.classList.remove('is-active');
    for (const name of HOLO_POSE) stage.style.removeProperty(name);
  };
  const pose = (event) => {
    cancelAnimationFrame(frame);
    frame = requestAnimationFrame(() => {
      const rect = stage.getBoundingClientRect();
      if (reducedMotion.matches || !rect.width || !rect.height) return;
      const x = Math.min(1, Math.max(0, (event.clientX - rect.left) / rect.width));
      const y = Math.min(1, Math.max(0, (event.clientY - rect.top) / rect.height));
      const values = [
        `${x * 100}%`,
        `${y * 100}%`,
        `${(y - 0.5) * tilt * 1.2}deg`,
        `${(0.5 - x) * tilt * 2}deg`,
        String(Math.min(1, Math.hypot(x - 0.5, y - 0.5) * 2)),
        `${(x - 0.5) * 40}px`,
        `${20 + (y - 0.5) * 32}px`,
      ];
      HOLO_POSE.forEach((name, index) => stage.style.setProperty(name, values[index]));
      stage.classList.add('is-active');
    });
  };
  return { pose, reset };
}

function readDismissed() {
  try {
    return localStorage.getItem(DISMISSED_KEY) ?? '';
  } catch {
    return '';
  }
}

function markDismissed(value) {
  try {
    localStorage.setItem(DISMISSED_KEY, value);
  } catch {}
}

export function setupInfo(host) {
  const version = globalThis.chrome?.runtime?.getManifest?.()?.version ?? '';
  const dismissToken = version || '1';
  document.body.insertAdjacentHTML('afterbegin', SPRITE);
  document.body.insertAdjacentHTML('beforeend', cardHtml(version));
  host.insertAdjacentHTML('beforeend', openerHtml(version));

  const info = document.getElementById('info');
  const opener = document.getElementById('info-open');
  const panel = info.querySelector('.info-panel');
  const stage = document.getElementById('info-stage');
  const holo = holoTracker(stage, INFO_TILT);
  let closeTimer = 0;

  const isOpen = () => !info.hidden && !info.classList.contains('closing');

  const setOpen = (open) => {
    if (open === isOpen()) return;
    clearTimeout(closeTimer);
    if (open) {
      info.classList.remove('closing');
      info.hidden = false;
      return;
    }
    if (readDismissed() !== dismissToken) markDismissed(dismissToken);
    holo.reset();
    info.classList.add('closing');
    closeTimer = setTimeout(() => {
      info.hidden = true;
      info.classList.remove('closing');
    }, CLOSE_MS);
  };

  opener.addEventListener('click', () => {
    setOpen(!isOpen());
  });

  stage.addEventListener('click', () => {
    setOpen(false);
  });

  document.getElementById('info-link').addEventListener('click', (event) => {
    event.stopPropagation();
  });

  for (const type of ['pointerenter', 'pointermove']) stage.addEventListener(type, holo.pose);
  for (const type of ['pointerleave', 'pointercancel']) stage.addEventListener(type, holo.reset);

  window.addEventListener('pointerdown', (event) => {
    if (!isOpen() || panel.contains(event.target) || opener.contains(event.target)) return;
    setOpen(false);
  }, true);

  window.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape' || !isOpen()) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    setOpen(false);
  }, true);

  window.addEventListener('storage', (event) => {
    if (event.key === DISMISSED_KEY && event.newValue === dismissToken) setOpen(false);
  });

  if (!location.protocol.startsWith('http') && readDismissed() !== dismissToken) setOpen(true);
}
