import { stripQuery } from './core.js';

export const GLYPH_FAMILIES = [
  {
    id: 'wux3ds',
    label: 'WebUX 3DS',
    font: 'dsfonticon',
    home: /\/webapps\/Core\//i,
    selector: /^\.wux-ui-3ds-([a-z0-9-]+)::?before$/,
    skip: /^(lg|[2-5]x|fw)$/,
    usage: (name) => [
      ['HTML', `<span class="wux-ui-3ds wux-ui-3ds-${name}"></span>`],
      ['WebUX Button', `icon: { iconName: '${name}', fontIconFamily: WUXManagedFontIcons.Font3DS }`],
      ['Dom.generateIcon', `Dom.generateIcon('${name}')`],
    ],
  },
  {
    id: 'uikit',
    label: 'UIKIT',
    font: 'entypo',
    home: /\/webapps\/UIKIT\//i,
    selector: /^\.fonticon-([a-z0-9-]+)::?before$/,
    skip: /^([2-5]x|spin)$/,
    usage: (name) => [
      ['HTML', `<span class="fonticon fonticon-${name}"></span>`],
      ['UIKIT Button', `icon: '${name}'`],
    ],
  },
  {
    id: 'fa',
    label: 'FontAwesome',
    font: 'fontawesome',
    home: /\/webapps\/Core\//i,
    selector: /^\.wux-ui-fa-([a-z0-9-]+)::?before$/,
    skip: /^$/,
    usage: (name) => [
      ['HTML', `<span class="wux-ui-fa wux-ui-fa-${name}"></span>`],
      ['WebUX Button (문자열)', `icon: '${name}'`],
      ['WebUX Button (객체)', `icon: { iconName: '${name}', fontIconFamily: WUXManagedFontIcons.FontAwesome }`],
    ],
  },
  {
    id: 'uwa',
    label: 'UWA',
    font: 'uwa-icons',
    home: /\/webapps\/UWA2\//i,
    selector: /^\.uwa-icon\.([a-z0-9-]+(?:\.small)?)::?before$/,
    skip: /^$/,
    usage: (name) => [['HTML', `<span class="uwa-icon ${name.replace('.', ' ')}"></span>`]],
  },
];

const FONT_ORDER = ['woff2', 'woff', 'truetype', 'opentype'];

function codeOf(raw) {
  const text = raw.trim().replace(/^['"]|['"]$/g, '');
  const escaped = text.match(/^\\([0-9a-fA-F]{1,6})$/);
  if (escaped) return parseInt(escaped[1], 16);
  return [...text].length === 1 ? text.codePointAt(0) : null;
}

function unquote(value) {
  return value.trim().replace(/^['"]|['"]$/g, '').trim().toLowerCase();
}

function fontFaces(css, cssUrl) {
  return [...css.matchAll(/@font-face\s*\{([^{}]*)\}/gi)].flatMap(([, body]) => {
    const family = body.match(/font-family\s*:\s*([^;]+)/i);
    if (!family) return [];
    const urls = [...body.matchAll(/url\(\s*(['"]?)([^'")]+)\1\s*\)(?:\s*format\(\s*['"]?([\w-]+)['"]?\s*\))?/gi)].flatMap(([, , path, format]) => {
      const ext = stripQuery(path).split('#')[0].split('.').pop().toLowerCase();
      const kind = format?.toLowerCase() ?? { woff2: 'woff2', woff: 'woff', ttf: 'truetype', otf: 'opentype' }[ext];
      if (!FONT_ORDER.includes(kind)) return [];
      try {
        return [{ url: new URL(path.split('#')[0], cssUrl).href, kind }];
      } catch {
        return [];
      }
    });
    return [{ family: unquote(family[1]), urls: urls.sort((a, b) => FONT_ORDER.indexOf(a.kind) - FONT_ORDER.indexOf(b.kind)).map((u) => u.url) }];
  });
}

export function parseGlyphCss(css, cssUrl) {
  const text = css.replace(/\/\*[\s\S]*?\*\//g, '');
  const icons = Object.fromEntries(GLYPH_FAMILIES.map((f) => [f.id, new Map()]));
  for (const [, selectors, body] of text.matchAll(/([^{}]+)\{([^{}]*)\}/g)) {
    const content = body.match(/content\s*:\s*(['"][^'"]*['"])/);
    const code = content && codeOf(content[1]);
    if (!code) continue;
    for (const raw of selectors.split(',')) {
      const selector = raw.trim().replace(/\s+/g, ' ').replace(/\.small ::?before$/, '.small:before');
      for (const family of GLYPH_FAMILIES) {
        const name = selector.match(family.selector)?.[1];
        if (name && !family.skip.test(name) && !icons[family.id].has(name)) icons[family.id].set(name, code);
      }
    }
  }
  return { url: cssUrl, icons, faces: fontFaces(text, cssUrl) };
}

function rank(family, url) {
  return (/\/3dspace\//i.test(url) ? 2 : 0) + (family.home.test(url) ? 1 : 0);
}

export function collectGlyphSources(sheets) {
  const parsed = sheets.map(({ url, text }) => parseGlyphCss(text, url));
  const allFaces = parsed.flatMap((p) => p.faces);
  return GLYPH_FAMILIES.map((family) => {
    const sources = parsed
      .filter((p) => p.icons[family.id].size)
      .map((p) => {
        const face = p.faces.find((f) => f.family === family.font) ?? allFaces.find((f) => f.family === family.font);
        return { url: p.url, icons: [...p.icons[family.id]].sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0)), fontUrls: face?.urls ?? [] };
      })
      .sort((a, b) => rank(family, b.url) - rank(family, a.url) || b.icons.length - a.icons.length);
    return { family, sources };
  });
}

export function filterGlyphs(icons, query) {
  const words = query.trim().toLowerCase().split(/\s+/).filter(Boolean);
  return words.length ? icons.filter(([name]) => words.every((word) => name.includes(word))) : icons;
}

export function base64ToBuffer(base64) {
  const bytes = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));
  return bytes.buffer;
}
