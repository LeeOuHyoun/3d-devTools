import { findMatchingNetworkIndex, findModule, matchesNetworkFilter, parseQueryParams, parseUrlParts, stripQuery, toOffset } from './core.js';
import { cachedBundles, createFramePoller, findBundle, findBundleByFile, openSourceLocation, renderLinkedText, resolveStacks, sendInspectorAction, setupIdentify } from './devtools-lib.js';
import { iconSvg, setIcon } from './icons.js';
import { buildCurlCommand, createViewerSearch, formatPrettyText, renderBodyViewer } from './network-viewer.js';
import { buildNlsIndex, moduleView, originalView } from './tools.js';
import { animateSize, applyTheme, bindClearButton, copyWithFeedback, createFinder, el, flashButton, makeClearable, renderCode, scrollToRow, syncClearButton, transitionLayout } from './view.js';
import { setupInfo } from './info.js';

const MAX_REQUESTS = 1000;
const POLL_MS = 150;
const HIDDEN_POLL_MS = 1000;
const SEARCH_RENDER_MS = 200;
const KEYS = {
  preserveLog: '3di.net.preserveLog',
  realtime: '3di.net.realtime',
  autoScroll: '3di.net.autoScroll',
  onlyXhr: '3di.net.onlyXhr',
  searchBody: '3di.net.searchBody',
  showRules: '3di.net.showRules',
  activePreset: '3di.net.activePreset',
  presets: '3di.net.presets',
  filterState: '3di.net.filterState',
  splitPct: '3di.net.splitPct',
  colWidths: '3di.net.colWidths',
};
const SPLIT_DEFAULT = 44;
const COLUMN_MIN = { status: 56, method: 50, name: 80, path: 60, init: 60, time: 50 };
const BUILTIN_PRESETS = [
  { id: 'all-xhr', name: '전체 XHR/Fetch', method: 'ALL', statusGroup: 'ALL', onlyXhr: true, include: '', exclude: '', builtin: true },
  { id: 'enovia-resources', name: 'ENOVIA API (/resources/)', method: 'ALL', statusGroup: 'ALL', onlyXhr: true, include: '/resources/', exclude: '/application/CSRF', builtin: true },
  { id: 'enovia-change', name: 'Change API (chg/change)', method: 'ALL', statusGroup: 'ALL', onlyXhr: true, include: 'chguxservices, modeler/change, changeaction, changeorder, changecontrol', exclude: '', builtin: true },
  { id: 'errors-only', name: '오류 요청만 (4xx/5xx/Fail)', method: 'ALL', statusGroup: 'error', onlyXhr: true, include: '', exclude: '', builtin: true },
];
const $ = (id) => document.getElementById(id);

function loadStorage(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw === null ? fallback : raw;
  } catch {
    return fallback;
  }
}

function saveStorage(key, value) {
  try {
    localStorage.setItem(key, String(value));
  } catch {}
}

function loadJson(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function saveJson(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {}
}

const savedFilter = loadJson(KEYS.filterState, {});
const state = {
  preserveLog: loadStorage(KEYS.preserveLog, 'false') === 'true',
  realtime: loadStorage(KEYS.realtime, 'true') !== 'false',
  autoScroll: loadStorage(KEYS.autoScroll, 'true') !== 'false',
  onlyXhr: savedFilter.onlyXhr ?? loadStorage(KEYS.onlyXhr, 'true') !== 'false',
  searchBody: loadStorage(KEYS.searchBody, 'false') === 'true',
  showRules: loadStorage(KEYS.showRules, 'true') !== 'false',
  query: savedFilter.query ?? '',
  method: savedFilter.method ?? 'ALL',
  statusGroup: savedFilter.statusGroup ?? 'ALL',
  include: savedFilter.include ?? '',
  exclude: savedFilter.exclude ?? '',
  activePreset: loadStorage(KEYS.activePreset, 'all-xhr'),
  presets: loadJson(KEYS.presets, []),
  detailTab: 'headers',
  bodyMode: 'tree',
  forceTree: false,
  fullscreen: false,
  sortKey: '',
  sortOrder: 'asc',
  splitPct: Math.min(80, Math.max(20, Number(loadStorage(KEYS.splitPct, String(SPLIT_DEFAULT))) || SPLIT_DEFAULT)),
  colWidths: loadJson(KEYS.colWidths, {}),
};
const requests = [];
const rowEls = new Map();
const modalFinder = createFinder('modal', $('moduleModalOut'), $('moduleModalOut'));
let resolving = null;
let resolveQueued = false;
let visibleRequests = [];
let selectedId = null;
let itemSeq = 0;
let activeViewer = null;
const viewerSearch = createViewerSearch({ input: $('detailSearchInput'), count: $('detailSearchCount'), prev: $('detailPrevBtn'), next: $('detailNextBtn') });
let pollTimer = null;
let pollInterval = POLL_MS;
let elapsedTimer = null;
let bodyQueueActive = 0;
let searchRenderTimer = null;
let droppedCount = 0;
let modalState = null;

function allPresets() {
  return [...BUILTIN_PRESETS, ...state.presets];
}

function persistFilterState() {
  saveJson(KEYS.filterState, {
    onlyXhr: state.onlyXhr,
    query: state.query,
    method: state.method,
    statusGroup: state.statusGroup,
    include: state.include,
    exclude: state.exclude,
  });
}

function currentFilter() {
  return {
    onlyXhr: state.onlyXhr,
    method: state.method,
    statusGroup: state.statusGroup,
    include: state.include,
    exclude: state.exclude,
    query: state.query,
    searchBody: state.searchBody,
  };
}

function headerValue(headers, targetName) {
  const lower = targetName.toLowerCase();
  return headers?.find((h) => h.name?.toLowerCase() === lower)?.value ?? '';
}

function extractPostDataText(postData) {
  if (!postData) return null;
  if (typeof postData.text === 'string' && postData.text.length) return postData.text;
  if (Array.isArray(postData.params) && postData.params.length) {
    return postData.params.map((p) => `${p.name ?? ''}=${p.value ?? ''}`).join('&');
  }
  return null;
}

function formatDuration(ms) {
  if (ms === null || ms === undefined || Number.isNaN(ms)) return '';
  if (ms < 1000) return `${Math.round(ms)} ms`;
  return `${(ms / 1000).toFixed(2)} s`;
}

function statusClass(item) {
  if (item.isPending) return 'status-pending';
  const code = Number(item.status);
  if (item.state === 'error' || item.state === 'aborted' || code === 0 || code >= 400) return 'status-err';
  if (code >= 300) return 'status-warn';
  if (code >= 200) return 'status-ok';
  return '';
}

function statusLabel(item) {
  if (item.isPending) return 'Pending';
  if (item.status === 0) return item.statusText || '(failed)';
  return String(item.status ?? '');
}

function isErrorItem(item) {
  if (item.isPending) return false;
  const code = Number(item.status);
  return item.state === 'error' || item.state === 'aborted' || code === 0 || code >= 400;
}

function initiatorSummary(item) {
  if (item.initiator?.length) return item.initiator[0].module.split('/').at(-1);
  if (item.rawStack?.length) return item.rawStack[0].url.split('/').at(-1).split('?')[0];
  return '';
}

function formatInitiatorLines(item) {
  if (item.initiator?.length) {
    return item.initiator.map((c, idx) => `${idx ? '← ' : ''}${c.module} (${c.fn || 'anonymous'})  ${c.file}:${c.line}:${c.column}`).join('\n');
  }
  if (item.rawStack?.length) {
    return item.rawStack.map((f, idx) => `${idx ? '← ' : ''}${f.fn || 'anonymous'}  ${f.url}:${f.line}:${f.column}`).join('\n');
  }
  return '';
}

function populatePresets() {
  const select = $('presetSelect');
  const presets = allPresets();
  const customOption = new Option('사용자 지정 (직접 입력)', '__custom__');
  select.replaceChildren(...presets.map((p) => new Option(p.builtin ? p.name : `★ ${p.name}`, p.id)), customOption);
  const exists = presets.some((p) => p.id === state.activePreset);
  select.value = exists ? state.activePreset : '__custom__';
  const selected = presets.find((p) => p.id === select.value);
  $('deletePresetBtn').disabled = !selected || Boolean(selected.builtin);
}

function syncRulesBadge() {
  const hasRules = Boolean(state.include.trim() || state.exclude.trim());
  $('rulesToggleBtn').classList.toggle('ghost-on', state.showRules);
  $('rulesToggleBtn').classList.toggle('scope-active-dot', hasRules);
}

function syncControlsFromState() {
  $('preserveLog').checked = state.preserveLog;
  $('realtimeTrack').checked = state.realtime;
  $('autoScroll').checked = state.autoScroll;
  $('searchBody').checked = state.searchBody;
  $('filterInput').value = state.query;
  $('methodFilter').value = state.method;
  $('statusFilter').value = state.statusGroup;
  $('typeFilter').value = state.onlyXhr ? 'xhr' : 'all';
  $('includeInput').value = state.include;
  $('excludeInput').value = state.exclude;
  syncClearButton($('filterInput'));
  syncClearButton($('includeInput'));
  syncClearButton($('excludeInput'));
  $('rulesBar').hidden = !state.showRules;
  syncRulesBadge();
  populatePresets();
}

function applyPreset(id) {
  const preset = allPresets().find((p) => p.id === id);
  state.activePreset = id;
  saveStorage(KEYS.activePreset, id);
  if (!preset) {
    populatePresets();
    return;
  }
  state.method = preset.method ?? 'ALL';
  state.statusGroup = preset.statusGroup ?? 'ALL';
  state.onlyXhr = preset.onlyXhr ?? true;
  state.include = preset.include ?? '';
  state.exclude = preset.exclude ?? '';
  persistFilterState();
  syncControlsFromState();
  renderList();
}

function markCustomPreset() {
  state.activePreset = '__custom__';
  saveStorage(KEYS.activePreset, '__custom__');
  syncRulesBadge();
  populatePresets();
}

function updateCountLabel() {
  $('countLabel').textContent = `${visibleRequests.length} / ${requests.length}건${droppedCount ? ` · 누락 ${droppedCount}건` : ''}`;
}

function scheduleSearchRender() {
  clearTimeout(searchRenderTimer);
  searchRenderTimer = setTimeout(renderList, SEARCH_RENDER_MS);
}

function syncElapsedTimer() {
  const hasPending = requests.some((r) => r.isPending);
  if (hasPending && !elapsedTimer) {
    elapsedTimer = setInterval(() => {
      let any = false;
      for (const item of visibleRequests) {
        if (!item.isPending) continue;
        any = true;
        const row = rowEls.get(item.id);
        const timeEl = row?.querySelector('.col-time');
        if (timeEl) timeEl.textContent = formatDuration(Date.now() - item.startedAt);
      }
      if (!any) syncElapsedTimer();
    }, 500);
  } else if (!hasPending && elapsedTimer) {
    clearInterval(elapsedTimer);
    elapsedTimer = null;
  }
}

function maxVisibleDuration() {
  let max = 0;
  for (const item of visibleRequests) {
    if (!item.isPending && item.duration > max) max = item.duration;
  }
  return max;
}

function fillRowElement(row, item, maxDur = 0) {
  row.className = 'net-row';
  if (item.id === selectedId) row.classList.add('is-selected');
  if (item.isPending) row.classList.add('is-pending');
  if (isErrorItem(item)) row.classList.add('is-error');
  row.dataset.id = item.id;
  row.title = item.url;
  const statusCol = document.createElement('div');
  statusCol.className = `col col-status ${statusClass(item)}`;
  if (item.isPending) statusCol.append(el('span', 'spinner'));
  statusCol.append(el('span', null, statusLabel(item)));
  const methodCol = el('div', `col col-method method-${item.method}`, el('span', 'method-badge', item.method));
  const nameCol = el('div', 'col col-name', item.name);
  const pathCol = el('div', 'col col-path', item.path);
  const initCol = el('div', 'col col-init', initiatorSummary(item));
  if (item.initiator?.length) initCol.title = item.initiator[0].module;
  const timeCol = el('div', 'col col-time', item.isPending ? formatDuration(Date.now() - item.startedAt) : formatDuration(item.duration));
  const barPct = !item.isPending && maxDur > 0 && item.duration > 0 ? Math.max(4, Math.round((item.duration / maxDur) * 100)) : 0;
  timeCol.style.setProperty('--bar', `${barPct}%`);
  row.replaceChildren(statusCol, methodCol, nameCol, pathCol, initCol, timeCol);
}

function createRowElement(item, maxDur = 0) {
  const row = document.createElement('div');
  fillRowElement(row, item, maxDur);
  row.addEventListener('click', () => toggleDetail(item.id));
  rowEls.set(item.id, row);
  return row;
}

function sortValue(item, key) {
  if (key === 'status') return item.isPending ? -1 : Number(item.status ?? 0);
  if (key === 'duration') return item.isPending ? Number.MAX_SAFE_INTEGER : Number(item.duration ?? -1);
  return String(item[key] ?? '').toLowerCase();
}

function sortItems(list) {
  if (!state.sortKey) return list;
  const dir = state.sortOrder === 'asc' ? 1 : -1;
  return [...list].sort((a, b) => {
    const va = sortValue(a, state.sortKey);
    const vb = sortValue(b, state.sortKey);
    if (va < vb) return -1 * dir;
    if (va > vb) return 1 * dir;
    return 0;
  });
}

function updateSortHeaders() {
  for (const h of document.querySelectorAll('.list-head .sortable')) {
    const key = h.dataset.sort;
    h.classList.toggle('sort-asc', state.sortKey === key && state.sortOrder === 'asc');
    h.classList.toggle('sort-desc', state.sortKey === key && state.sortOrder === 'desc');
  }
}

function scrollToBottom() {
  if (!state.autoScroll) return;
  const body = $('listBody');
  body.scrollTop = body.scrollHeight;
}

function renderList() {
  const filter = currentFilter();
  visibleRequests = sortItems(requests.filter((item) => matchesNetworkFilter(item, filter)));
  const maxDur = maxVisibleDuration();
  const frag = document.createDocumentFragment();
  const nextIds = new Set();
  for (const item of visibleRequests) {
    nextIds.add(item.id);
    const row = rowEls.get(item.id);
    if (row) {
      fillRowElement(row, item, maxDur);
      frag.append(row);
    } else {
      frag.append(createRowElement(item, maxDur));
    }
  }
  for (const id of rowEls.keys()) {
    if (!nextIds.has(id) && !requests.some((r) => r.id === id)) rowEls.delete(id);
  }
  $('listBody').replaceChildren(frag);
  updateCountLabel();
  syncElapsedTimer();
  if (state.searchBody && state.query.trim()) preloadBodiesForSearch();
}

function syncItemInList(item, isNew) {
  const matches = matchesNetworkFilter(item, currentFilter());
  const existingRow = rowEls.get(item.id);
  if (state.sortKey || (existingRow && !matches) || (!existingRow && matches && isNew === false)) {
    renderList();
    return;
  }
  const maxDur = maxVisibleDuration();
  if (matches) {
    if (existingRow) {
      fillRowElement(existingRow, item, maxDur);
    } else {
      visibleRequests.push(item);
      $('listBody').append(createRowElement(item, maxDur));
      scrollToBottom();
    }
  }
  updateCountLabel();
  syncElapsedTimer();
  if (state.searchBody && state.query.trim()) preloadBodiesForSearch();
}

function preloadBodiesForSearch() {
  const filter = { ...currentFilter(), query: '' };
  for (const item of requests) {
    if (bodyQueueActive >= 6) break;
    if (item.fullRequest && item.responseText === null && !item._loadingResponse && matchesNetworkFilter(item, filter)) {
      bodyQueueActive += 1;
      ensureResponseLoaded(item, true).finally(() => {
        bodyQueueActive -= 1;
        if (state.searchBody && state.query.trim()) preloadBodiesForSearch();
      });
    }
  }
}

function ensureResponseLoaded(item, fromSearch = false) {
  if (!item?.fullRequest || item.responseText !== null || item._loadingResponse) return Promise.resolve();
  item._loadingResponse = true;
  return new Promise((resolve) => {
    let settled = false;
    const finish = (content) => {
      if (settled) return;
      settled = true;
      item.responseText = content ?? '';
      item._loadingResponse = false;
      if (item.id === selectedId && state.detailTab === 'response') renderDetailBody();
      if (fromSearch && state.searchBody && state.query.trim()) scheduleSearchRender();
      resolve();
    };
    const timer = setTimeout(() => finish(''), 5000);
    try {
      item.fullRequest.getContent((content) => {
        clearTimeout(timer);
        finish(content);
      });
    } catch {
      clearTimeout(timer);
      finish('');
    }
  });
}

function selectedItem() {
  return requests.find((r) => r.id === selectedId) ?? null;
}

function applySplitLayout() {
  const pane = $('listPane');
  const detail = $('detailPane');
  if (!selectedId) {
    pane.style.flex = '1 1 auto';
    detail.hidden = true;
    $('resizer').hidden = true;
    return;
  }
  pane.style.flex = `0 0 ${state.splitPct}%`;
  detail.style.flex = `1 1 ${100 - state.splitPct}%`;
  detail.hidden = false;
  $('resizer').hidden = false;
}

function toggleDetail(id) {
  transitionLayout(() => selectRequest(id), !selectedId !== !id);
}

function selectRequest(id) {
  const prevId = selectedId;
  selectedId = id;
  state.forceTree = false;
  const maxDur = maxVisibleDuration();
  if (prevId && rowEls.has(prevId)) {
    const prev = requests.find((r) => r.id === prevId);
    if (prev) fillRowElement(rowEls.get(prevId), prev, maxDur);
  }
  if (id && rowEls.has(id)) {
    const cur = selectedItem();
    if (cur) fillRowElement(rowEls.get(id), cur, maxDur);
  }
  if (!id) state.fullscreen = false;
  $('detailPane').classList.toggle('is-fullscreen', state.fullscreen);
  applySplitLayout();
  const item = selectedItem();
  if (item) {
    ensureResponseLoaded(item);
    renderDetail();
  }
}

function createKvTable(rows) {
  const table = document.createElement('table');
  table.className = 'kv-table';
  for (const [k, v, renderValue] of rows) {
    const tr = document.createElement('tr');
    const tdKey = document.createElement('td');
    tdKey.className = 'kv-key';
    tdKey.textContent = k;
    const tdVal = document.createElement('td');
    if (renderValue) renderValue(tdVal, v);
    else tdVal.textContent = v ?? '';
    tr.append(tdKey, tdVal);
    table.append(tr);
  }
  return table;
}

function appendSection(container, title, contentEl) {
  const h = document.createElement('div');
  h.className = 'section-title';
  h.textContent = title;
  container.append(h, contentEl);
}

function linkHandlersForItem(item) {
  return {
    onModule: (modId) => {
      const hit = item?.initiator?.find((c) => c.module === modId);
      openModuleModal(modId, hit ? { url: hit.url, line: hit.line, column: hit.column } : null);
    },
    onLocation: (file, line, column) => {
      const frames = [...(item?.initiator ?? []), ...(item?.rawStack ?? [])];
      const hit = frames.find((f) => f.line === Number(line) && f.column === Number(column) && stripQuery(f.url).endsWith(`/${file}`));
      openLocationModal(file, Number(line), Number(column), hit?.url);
    },
  };
}

function renderHeadersTab(container, item) {
  const initText = item.initiator?.length ? `${item.initiator[0].module} (${item.initiator[0].file}:${item.initiator[0].line}:${item.initiator[0].column})` : initiatorSummary(item);
  const generalRows = [
    ['Request URL:', item.url],
    ['Request Method:', item.method],
    ['Status Code:', statusLabel(item)],
    ['Duration:', item.isPending ? 'Pending' : formatDuration(item.duration)],
    ...(item.frameUrl ? [['Frame URL:', item.frameUrl]] : []),
    ...(initText
      ? [
          [
            'Initiator:',
            initText,
            (cell, val) => {
              renderLinkedText(cell, val, linkHandlersForItem(item));
            },
          ],
        ]
      : []),
  ];
  appendSection(container, 'General', createKvTable(generalRows));
  const queryParams = parseQueryParams(item.url);
  if (queryParams.length) {
    appendSection(
      container,
      `Query String Parameters (${queryParams.length})`,
      createKvTable(queryParams.map((p) => [`${p.key}:`, p.value])),
    );
  }
  appendSection(
    container,
    `Response Headers (${item.responseHeaders?.length ?? 0})`,
    item.responseHeaders?.length
      ? createKvTable(item.responseHeaders.map((h) => [`${h.name}:`, h.value]))
      : Object.assign(document.createElement('div'), { className: 'empty-msg', textContent: item.isPending ? '응답 대기 중 (Pending)' : '헤더 정보 없음' }),
  );
  appendSection(
    container,
    `Request Headers (${item.requestHeaders?.length ?? 0})`,
    item.requestHeaders?.length
      ? createKvTable(item.requestHeaders.map((h) => [`${h.name}:`, h.value]))
      : Object.assign(document.createElement('div'), { className: 'empty-msg', textContent: '헤더 정보 없음' }),
  );
}

function renderDetailBody() {
  const item = selectedItem();
  const body = $('detailBody');
  activeViewer = null;
  viewerSearch.attach(null);
  if (!item) {
    body.replaceChildren();
    return;
  }
  const tab = state.detailTab;
  if (tab === 'headers') {
    body.replaceChildren();
    renderHeadersTab(body, item);
    $('treeActions').hidden = true;
    $('detailSearchBox').hidden = true;
    return;
  }
  if (tab === 'initiator') {
    body.replaceChildren();
    const lines = formatInitiatorLines(item);
    if (!lines) {
      const msg = document.createElement('div');
      msg.className = 'empty-msg';
      msg.textContent = state.realtime ? '호출 스택 정보가 기록되지 않은 요청입니다.' : 'Real-time을 켜면 호출 모듈(DS/...) 정보를 함께 추적합니다.';
      body.append(msg);
    } else {
      const pre = document.createElement('pre');
      pre.className = 'init-block';
      renderLinkedText(pre, lines, linkHandlersForItem(item));
      body.append(pre);
    }
    $('treeActions').hidden = true;
    $('detailSearchBox').hidden = true;
    return;
  }
  const isPayload = tab === 'payload';
  const text = isPayload ? item.postDataText : item.responseText;
  const emptyMessage = isPayload
    ? 'Payload 없음'
    : item.isPending
      ? '요청 진행 중 (Pending)...'
      : item.fullRequest
        ? item._loadingResponse
          ? '응답 불러오는 중...'
          : '응답 본문 없음'
        : '응답 본문 없음';
  activeViewer = renderBodyViewer(body, {
    text,
    emptyMessage,
    mode: state.bodyMode,
    contentType: isPayload ? item.contentType : item.responseContentType,
    defaultExpandDepth: isPayload ? 2 : 3,
    forceTree: state.forceTree,
    onForceTree: () => {
      state.forceTree = true;
      renderDetailBody();
    },
  });
  $('treeActions').hidden = !text;
  $('expandBtn').hidden = !activeViewer.isTree;
  $('collapseBtn').hidden = !activeViewer.isTree;
  $('modeToggleBtn').textContent = state.bodyMode === 'tree' ? 'Raw' : 'Tree';
  $('detailSearchBox').hidden = !text;
  viewerSearch.attach(text ? activeViewer : null);
}

function renderDetail() {
  for (const btn of document.querySelectorAll('.detail-tabs .tab-btn')) {
    btn.classList.toggle('is-active', btn.dataset.tab === state.detailTab);
  }
  $('fullscreenBtn').classList.toggle('is-active', state.fullscreen);
  setIcon($('fullscreenBtn'), state.fullscreen ? 'zoomExit' : 'zoomEnter', 14);
  $('fullscreenBtn').title = state.fullscreen ? '창 복원' : '상세 전체화면 전환';
  renderDetailBody();
}

function textForCopy(item) {
  if (!item) return '';
  if (state.detailTab === 'headers') {
    return [
      `Request URL: ${item.url}`,
      `Request Method: ${item.method}`,
      `Status Code: ${statusLabel(item)}`,
      '',
      '[Response Headers]',
      ...(item.responseHeaders ?? []).map((h) => `${h.name}: ${h.value}`),
      '',
      '[Request Headers]',
      ...(item.requestHeaders ?? []).map((h) => `${h.name}: ${h.value}`),
    ].join('\n');
  }
  if (state.detailTab === 'payload') return formatPrettyText(item.postDataText ?? '');
  if (state.detailTab === 'response') return formatPrettyText(item.responseText ?? '');
  return formatInitiatorLines(item);
}

function modalCodeMode() {
  return $('modalCodeMode').querySelector('.on')?.dataset.value ?? 'restore';
}

function renderModalContent() {
  if (!modalState) return;
  const { bundle, moduleId, line, column, offset } = modalState;
  $('moduleModalSourcesBtn').hidden = !bundle;
  if (!bundle) {
    $('moduleModalHead').hidden = true;
    $('moduleModalOut').replaceChildren(el('div', 'placeholder', `${moduleId}: 대상 번들에서 모듈을 찾지 못했습니다.`));
    modalFinder.refresh();
    return;
  }
  if (moduleId) {
    const rename = modalCodeMode() === 'restore';
    const locals = rename && $('modalLocalsBtn').classList.contains('on') ? /^.$/ : null;
    const view = moduleView(bundle, moduleId, { rename, locals, offset });
    $('moduleModalTitle').textContent = line ? `${moduleId} (${bundle.name}:${line}:${column})` : `${moduleId} (${bundle.name})`;
    if (view.error) {
      modalState.codeText = '';
      $('moduleModalHead').hidden = true;
      $('moduleModalOut').replaceChildren(el('div', 'placeholder', view.error));
      modalFinder.refresh();
      return;
    }
    modalState.codeText = `${view.head}\n${view.code}`;
    $('moduleModalHead').hidden = false;
    renderLinkedText($('moduleModalHead'), view.head, { onModule: (id) => openModuleModal(id) });
    const focus = renderCode($('moduleModalOut'), view.code, { focusLine: view.line, nlsMap: buildNlsIndex(cachedBundles()) });
    modalFinder.refresh();
    scrollToRow($('moduleModalOut'), focus);
    return;
  }
  const orig = originalView(bundle, offset, 1);
  modalState.codeText = orig.text;
  $('moduleModalTitle').textContent = `${bundle.name}:${line}:${column}`;
  $('moduleModalHead').hidden = true;
  const focus = renderCode($('moduleModalOut'), orig.text, { kind: bundle.kind ?? 'js', firstLine: orig.firstLine, focusLine: orig.line, mark: orig.mark, nlsMap: buildNlsIndex(cachedBundles()) });
  modalFinder.refresh();
  scrollToRow($('moduleModalOut'), focus);
}

async function openModuleModal(moduleId, loc = null) {
  $('moduleModal').hidden = false;
  $('moduleModalTitle').textContent = moduleId;
  $('moduleModalHead').hidden = true;
  $('moduleModalOut').replaceChildren(el('div', 'placeholder', '모듈 불러오는 중...'));
  try {
    const bundle = (loc?.url && (await findBundleByFile(loc.url))) || (await findBundle(moduleId));
    const offset = bundle && loc?.line ? toOffset(bundle.lineStarts, loc.line, loc.column ?? 1) : null;
    modalState = { bundle, moduleId, line: loc?.line ?? null, column: loc?.column ?? 1, offset, codeText: '' };
    $('modalCodeMode').hidden = false;
    $('modalLocalsBtn').hidden = false;
    $('moduleModalSendBtn').hidden = !bundle;
    renderModalContent();
  } catch (e) {
    $('moduleModalOut').replaceChildren(el('div', 'placeholder', `오류: ${e.message}`));
  }
}

async function openLocationModal(file, line, column, url = file) {
  $('moduleModal').hidden = false;
  $('moduleModalTitle').textContent = `${file}:${line}:${column}`;
  $('moduleModalHead').hidden = true;
  $('moduleModalOut').replaceChildren(el('div', 'placeholder', '소스 불러오는 중...'));
  try {
    const bundle = await findBundleByFile(url);
    if (!bundle) {
      modalState = { bundle: null, moduleId: file, line, column, offset: null, codeText: '' };
      return renderModalContent();
    }
    const offset = toOffset(bundle.lineStarts, line, column);
    const mod = findModule(bundle.modules, offset);
    modalState = { bundle, moduleId: mod?.id ?? null, line, column, offset, codeText: '' };
    $('modalCodeMode').hidden = !mod;
    $('modalLocalsBtn').hidden = !mod;
    $('moduleModalSendBtn').hidden = !mod;
    renderModalContent();
  } catch (e) {
    $('moduleModalOut').replaceChildren(el('div', 'placeholder', `오류: ${e.message}`));
  }
}

function ingestPageEvent(ev, frameUrl) {
  const parts = parseUrlParts(ev.url);
  const idx = findMatchingNetworkIndex(requests, {
    source: 'page',
    pageId: ev.id,
    method: ev.method,
    url: ev.url,
    startedAt: ev.startedAt,
    postDataText: ev.postDataText ?? null,
  });
  const isPending = ev.state === 'pending';
  const status = isPending ? 'Pending' : ev.state === 'aborted' ? 0 : ev.httpStatus ?? (ev.state === 'error' ? 0 : 200);
  const statusText = ev.state === 'aborted' ? '(canceled)' : ev.state === 'error' && !ev.httpStatus ? '(failed)' : '';
  if (idx !== -1) {
    const item = requests[idx];
    item.pageId = ev.id;
    item.pageMatched = true;
    item.fromPageHook = true;
    item.frameUrl = frameUrl ?? item.frameUrl;
    if (ev.rawStack?.length && !item.rawStack?.length) item.rawStack = ev.rawStack;
    if (!item.postDataText && ev.postDataText) item.postDataText = ev.postDataText;
    if (!item.harMatched) {
      item.isPending = isPending;
      item.status = status;
      item.statusText = statusText;
      item.state = ev.state;
      if (ev.duration !== null && ev.duration !== undefined) item.duration = ev.duration;
    }
    syncItemInList(item, false);
    if (item.id === selectedId) renderDetail();
    return;
  }
  const item = {
    id: `r_${++itemSeq}`,
    pageId: ev.id,
    pageMatched: true,
    harMatched: false,
    fromPageHook: true,
    frameUrl: frameUrl ?? null,
    method: ev.method,
    url: ev.url,
    name: parts.name,
    path: parts.path,
    resourceType: ev.resourceType,
    status,
    statusText,
    state: ev.state,
    isPending,
    startedAt: ev.startedAt,
    duration: ev.duration,
    requestHeaders: [],
    responseHeaders: [],
    postDataText: ev.postDataText ?? null,
    responseText: null,
    contentType: '',
    responseContentType: '',
    initiator: [],
    rawStack: ev.rawStack ?? [],
    initiatorText: '',
    fullRequest: null,
  };
  requests.push(item);
  trimOverflow();
  syncItemInList(item, true);
}

function ingestHar(request) {
  const method = String(request.request?.method || 'GET').toUpperCase();
  const url = String(request.request?.url || '');
  const parts = parseUrlParts(url);
  const startedAt = request.startedDateTime ? Date.parse(request.startedDateTime) : Date.now();
  const duration = typeof request.time === 'number' && request.time >= 0 ? Math.round(request.time) : null;
  const requestHeaders = request.request?.headers ?? [];
  const responseHeaders = request.response?.headers ?? [];
  const postDataText = extractPostDataText(request.request?.postData);
  const contentType = headerValue(requestHeaders, 'content-type');
  const responseContentType = headerValue(responseHeaders, 'content-type');
  const status = request.response?.status ?? 0;
  const canceled = status === 0 && /ERR_ABORTED/.test(request.response?._error ?? '');
  const statusText = request.response?.statusText || (canceled ? '(canceled)' : status === 0 ? '(failed)' : '');
  const state = canceled ? 'aborted' : status === 0 || status >= 400 ? 'error' : 'done';
  const resourceType = request._resourceType || '';
  const idx = findMatchingNetworkIndex(requests, { source: 'har', method, url, startedAt, postDataText });
  if (idx !== -1) {
    const item = requests[idx];
    item.harMatched = true;
    item.isPending = false;
    item.status = status;
    item.statusText = statusText;
    item.state = state;
    if (duration !== null) item.duration = duration;
    item.requestHeaders = requestHeaders;
    item.responseHeaders = responseHeaders;
    item.contentType = contentType;
    item.responseContentType = responseContentType;
    if (resourceType) item.resourceType = resourceType;
    if (postDataText !== null) item.postDataText = postDataText;
    item.fullRequest = request;
    syncItemInList(item, false);
    if (item.id === selectedId) {
      ensureResponseLoaded(item);
      renderDetail();
    }
    return;
  }
  const item = {
    id: `r_${++itemSeq}`,
    pageId: null,
    pageMatched: false,
    harMatched: true,
    fromPageHook: false,
    frameUrl: null,
    method,
    url,
    name: parts.name,
    path: parts.path,
    resourceType,
    status,
    statusText,
    state,
    isPending: false,
    startedAt,
    duration,
    requestHeaders,
    responseHeaders,
    postDataText,
    responseText: null,
    contentType,
    responseContentType,
    initiator: [],
    rawStack: [],
    initiatorText: '',
    fullRequest: request,
  };
  requests.push(item);
  trimOverflow();
  syncItemInList(item, true);
}

function trimOverflow() {
  if (requests.length <= MAX_REQUESTS) return;
  const removed = requests.splice(0, requests.length - MAX_REQUESTS);
  let needRender = false;
  for (const r of removed) {
    if (rowEls.has(r.id)) {
      rowEls.get(r.id).remove();
      rowEls.delete(r.id);
    }
    if (r.id === selectedId) selectRequest(null);
    needRender = true;
  }
  if (needRender) renderList();
}

function clearLogs() {
  requests.length = 0;
  droppedCount = 0;
  visibleRequests = [];
  rowEls.clear();
  $('listBody').replaceChildren();
  selectRequest(null);
  updateCountLabel();
  syncElapsedTimer();
}

async function resolveInitiators() {
  if (resolving) {
    resolveQueued = true;
    return resolving;
  }
  resolving = (async () => {
    const candidates = requests.filter((r) => !r.initiator?.length && r.rawStack?.length);
    if (!candidates.length) return;
    const resolved = await resolveStacks(candidates.map((r) => r.rawStack)).catch(() => null);
    if (!resolved) return;
    let detailDirty = false;
    candidates.forEach((item, i) => {
      const chain = resolved[i];
      if (!chain?.length || item.initiator?.length) return;
      item.initiator = chain;
      item.initiatorText = chain[0].module.split('/').at(-1);
      syncItemInList(item, false);
      if (item.id === selectedId) detailDirty = true;
    });
    if (detailDirty) renderDetail();
  })().finally(() => {
    resolving = null;
    if (resolveQueued) {
      resolveQueued = false;
      resolveInitiators();
    }
  });
  return resolving;
}

const poller = createFramePoller('net', (results) => {
  for (const { frameUrl, res } of results) {
    if (res.dropped) {
      droppedCount += res.dropped;
      updateCountLabel();
    }
    for (const ev of res.events ?? []) ingestPageEvent(ev, frameUrl);
  }
  if (results.some(({ res }) => res.events?.some((ev) => ev.rawStack?.length))) resolveInitiators();
});

function pollTick() {
  if (state.realtime) poller.tick();
}

function startPolling() {
  if (pollTimer || !state.realtime) return;
  poller.track(true).then(() => pollTick());
  pollTimer = setInterval(pollTick, pollInterval);
}

function setPollInterval(ms) {
  pollInterval = ms;
  if (!pollTimer) return;
  clearInterval(pollTimer);
  pollTimer = setInterval(pollTick, pollInterval);
}

function initIcons() {
  $('clearBtn').innerHTML = `${iconSvg('trash', 13)}<span>비우기</span>`;
  $('rulesToggleBtn').innerHTML = `${iconSvg('filter', 13)}<span>맞춤 필터</span>`;
  setIcon($('filterClearBtn'), 'x', 12);
  setIcon($('closeDetailBtn'), 'x', 14);
  setIcon($('detailPrevBtn'), 'chevronUp', 13);
  setIcon($('detailNextBtn'), 'chevronDown', 13);
  $('searchInInspectorBtn').innerHTML = `${iconSvg('search', 12)}<span>Inspector</span>`;
  $('copyBtn').innerHTML = `${iconSvg('copy', 12)}<span>복사</span>`;
  $('curlBtn').innerHTML = `${iconSvg('code', 12)}<span>cURL</span>`;
  setIcon($('fullscreenBtn'), 'zoomEnter', 14);
  $('moduleModalSendBtn').innerHTML = `${iconSvg('external', 12)}<span>Inspector로</span>`;
  setIcon($('moduleModalCloseBtn'), 'x', 14);
}

function bindEvents() {
  $('clearBtn').addEventListener('click', clearLogs);
  $('preserveLog').addEventListener('change', (e) => {
    state.preserveLog = e.target.checked;
    saveStorage(KEYS.preserveLog, state.preserveLog);
  });
  $('realtimeTrack').addEventListener('change', (e) => {
    state.realtime = e.target.checked;
    saveStorage(KEYS.realtime, state.realtime);
    if (state.realtime) {
      startPolling();
    } else {
      clearInterval(pollTimer);
      pollTimer = null;
      poller.track(false);
    }
  });
  $('autoScroll').addEventListener('change', (e) => {
    state.autoScroll = e.target.checked;
    saveStorage(KEYS.autoScroll, state.autoScroll);
    if (state.autoScroll) scrollToBottom();
  });
  $('filterInput').addEventListener('input', (e) => {
    state.query = e.target.value;
    persistFilterState();
    renderList();
  });
  $('searchBody').addEventListener('change', (e) => {
    state.searchBody = e.target.checked;
    saveStorage(KEYS.searchBody, state.searchBody);
    renderList();
  });
  $('methodFilter').addEventListener('change', (e) => {
    state.method = e.target.value;
    markCustomPreset();
    persistFilterState();
    renderList();
  });
  $('statusFilter').addEventListener('change', (e) => {
    state.statusGroup = e.target.value;
    markCustomPreset();
    persistFilterState();
    renderList();
  });
  $('typeFilter').addEventListener('change', (e) => {
    state.onlyXhr = e.target.value === 'xhr';
    saveStorage(KEYS.onlyXhr, state.onlyXhr);
    markCustomPreset();
    persistFilterState();
    renderList();
  });
  $('rulesToggleBtn').addEventListener('click', () =>
    transitionLayout(() => {
      state.showRules = !state.showRules;
      saveStorage(KEYS.showRules, state.showRules);
      $('rulesBar').hidden = !state.showRules;
      syncRulesBadge();
    }),
  );
  $('presetSelect').addEventListener('change', (e) => applyPreset(e.target.value));
  $('includeInput').addEventListener('input', (e) => {
    state.include = e.target.value;
    markCustomPreset();
    persistFilterState();
    renderList();
  });
  $('excludeInput').addEventListener('input', (e) => {
    state.exclude = e.target.value;
    markCustomPreset();
    persistFilterState();
    renderList();
  });
  const setPresetSaveOpen = (open) => {
    $('savePresetBtn').hidden = open;
    $('presetSaveWrap').hidden = !open;
    if (open) {
      $('presetNameInput').value = '';
      syncClearButton($('presetNameInput'));
      $('presetNameInput').focus();
    }
  };
  const commitPresetSave = () => {
    const name = $('presetNameInput').value.trim();
    if (!name) return;
    const preset = {
      id: `user_${Date.now().toString(36)}`,
      name,
      method: state.method,
      statusGroup: state.statusGroup,
      onlyXhr: state.onlyXhr,
      include: state.include,
      exclude: state.exclude,
      builtin: false,
    };
    state.presets.push(preset);
    state.activePreset = preset.id;
    saveJson(KEYS.presets, state.presets);
    saveStorage(KEYS.activePreset, preset.id);
    setPresetSaveOpen(false);
    populatePresets();
  };
  $('savePresetBtn').addEventListener('click', () => setPresetSaveOpen(true));
  $('confirmPresetBtn').addEventListener('click', commitPresetSave);
  $('cancelPresetBtn').addEventListener('click', () => setPresetSaveOpen(false));
  $('presetNameInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') commitPresetSave();
    else if (e.key === 'Escape') {
      e.stopPropagation();
      setPresetSaveOpen(false);
    }
  });
  $('deletePresetBtn').addEventListener('click', () => {
    const target = state.presets.find((p) => p.id === state.activePreset);
    if (!target) return;
    state.presets = state.presets.filter((p) => p.id !== target.id);
    saveJson(KEYS.presets, state.presets);
    applyPreset('all-xhr');
  });
  $('resetFilterBtn').addEventListener('click', () => {
    state.query = '';
    state.searchBody = false;
    saveStorage(KEYS.searchBody, false);
    applyPreset('all-xhr');
  });
  for (const col of document.querySelectorAll('.list-head .sortable')) {
    col.addEventListener('click', () => {
      const key = col.dataset.sort;
      if (state.sortKey === key) {
        if (state.sortOrder === 'asc') state.sortOrder = 'desc';
        else state.sortKey = '';
      } else {
        state.sortKey = key;
        state.sortOrder = 'asc';
      }
      updateSortHeaders();
      renderList();
    });
  }
  $('closeDetailBtn').addEventListener('click', () => toggleDetail(null));
  for (const btn of document.querySelectorAll('.detail-tabs .tab-btn')) {
    btn.addEventListener('click', () => {
      state.detailTab = btn.dataset.tab;
      state.forceTree = false;
      renderDetail();
    });
  }
  $('expandBtn').addEventListener('click', () => activeViewer?.expandAll());
  $('collapseBtn').addEventListener('click', () => activeViewer?.collapseToDepth1());
  $('modeToggleBtn').addEventListener('click', () => {
    state.bodyMode = state.bodyMode === 'tree' ? 'raw' : 'tree';
    renderDetailBody();
  });
  $('searchInInspectorBtn').addEventListener('click', () => {
    const item = selectedItem();
    const seg = item?.path?.split('/').filter(Boolean).at(-1);
    if (!seg) return;
    sendInspectorAction({ type: 'search', query: seg });
    flashButton($('searchInInspectorBtn'), '전송됨');
  });
  $('copyBtn').addEventListener('click', () => copyWithFeedback($('copyBtn'), () => textForCopy(selectedItem())));
  $('curlBtn').addEventListener('click', () => copyWithFeedback($('curlBtn'), () => buildCurlCommand(selectedItem())));
  $('fullscreenBtn').addEventListener('click', () => transitionLayout(() => setFullscreen(!state.fullscreen)));
  $('modalCodeMode').addEventListener('click', (e) => {
    const btn = e.target.closest('button');
    if (!btn || btn.classList.contains('on')) return;
    $('modalCodeMode').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b === btn));
    renderModalContent();
  });
  $('modalLocalsBtn').addEventListener('click', () => {
    const on = !$('modalLocalsBtn').classList.contains('on');
    $('modalLocalsBtn').classList.toggle('on', on);
    $('modalLocalsBtn').setAttribute('aria-pressed', String(on));
    renderModalContent();
  });
  $('moduleModalSendBtn').addEventListener('click', () => {
    if (!modalState?.moduleId) return;
    sendInspectorAction({ type: 'openModule', moduleId: modalState.moduleId, line: modalState.line, column: modalState.column });
    flashButton($('moduleModalSendBtn'), '전송됨');
  });
  $('moduleModalSourcesBtn').addEventListener('click', () => {
    if (modalState?.bundle) openSourceLocation(modalState.bundle.name, modalState.line ?? 1, modalState.column ?? 1);
  });
  $('moduleModalCloseBtn').addEventListener('click', () => {
    $('moduleModal').hidden = true;
  });
  $('moduleModal').addEventListener('click', (e) => {
    if (e.target === $('moduleModal')) $('moduleModal').hidden = true;
  });
  $('moduleModalCopyBtn').addEventListener('click', () => copyWithFeedback($('moduleModalCopyBtn'), () => modalState?.codeText ?? ''));
  bindResizer();
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey && (e.key === 'l' || e.key === 'L')) {
      e.preventDefault();
      clearLogs();
      return;
    }
    if (e.key === 'Escape') {
      if (!$('moduleModal').hidden) {
        $('moduleModal').hidden = true;
      } else if (state.fullscreen) {
        transitionLayout(() => setFullscreen(false));
      } else if (selectedId) {
        toggleDetail(null);
      }
      return;
    }
    if ((e.key === 'ArrowDown' || e.key === 'ArrowUp') && !e.target.closest('input, select, textarea')) {
      if (!visibleRequests.length) return;
      e.preventDefault();
      const idx = visibleRequests.findIndex((r) => r.id === selectedId);
      const nextIdx = idx === -1 ? (e.key === 'ArrowDown' ? 0 : visibleRequests.length - 1) : Math.min(visibleRequests.length - 1, Math.max(0, idx + (e.key === 'ArrowDown' ? 1 : -1)));
      const next = visibleRequests[nextIdx];
      if (next) {
        toggleDetail(next.id);
        rowEls.get(next.id)?.scrollIntoView({ block: 'nearest' });
      }
    }
  });
}

function setFullscreen(on) {
  state.fullscreen = on;
  $('detailPane').classList.toggle('is-fullscreen', on);
  renderDetail();
}

function bindResizer() {
  const resizer = $('resizer');
  const workspace = $('workspace');
  resizer.addEventListener('dblclick', () => {
    state.splitPct = SPLIT_DEFAULT;
    saveStorage(KEYS.splitPct, state.splitPct);
    animateSize(applySplitLayout);
  });
  resizer.addEventListener('mousedown', (e) => {
    e.preventDefault();
    resizer.classList.add('is-dragging');
    document.body.classList.add('resizing-x');
    const onMove = (ev) => {
      const rect = workspace.getBoundingClientRect();
      if (rect.width <= 0) return;
      const pct = Math.min(80, Math.max(20, ((ev.clientX - rect.left) / rect.width) * 100));
      state.splitPct = Math.round(pct * 10) / 10;
      applySplitLayout();
    };
    const onUp = () => {
      resizer.classList.remove('is-dragging');
      document.body.classList.remove('resizing-x');
      saveStorage(KEYS.splitPct, state.splitPct);
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  });
}

function applyColumnWidths() {
  for (const [key, width] of Object.entries(state.colWidths)) {
    if (COLUMN_MIN[key]) $('listPane').style.setProperty(`--w-${key}`, `${Math.max(COLUMN_MIN[key], width)}px`);
  }
}

function bindColumnResizers() {
  const head = document.querySelector('.list-head');
  $('listBody').addEventListener('scroll', () => {
    head.scrollLeft = $('listBody').scrollLeft;
  });
  for (const col of head.querySelectorAll('.col')) {
    const key = col.dataset.col;
    const grip = document.createElement('span');
    grip.className = 'col-grip';
    grip.title = '끌어서 너비 조절, 더블클릭하면 기본 너비';
    grip.addEventListener('click', (e) => e.stopPropagation());
    grip.addEventListener('dblclick', (e) => {
      e.stopPropagation();
      delete state.colWidths[key];
      animateSize(() => $('listPane').style.removeProperty(`--w-${key}`));
      saveJson(KEYS.colWidths, state.colWidths);
    });
    grip.addEventListener('mousedown', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const startX = e.clientX;
      const startWidth = col.getBoundingClientRect().width;
      grip.classList.add('is-dragging');
      document.body.classList.add('col-resizing');
      const onMove = (ev) => {
        state.colWidths[key] = Math.max(COLUMN_MIN[key], Math.round(startWidth + ev.clientX - startX));
        applyColumnWidths();
      };
      const onUp = () => {
        grip.classList.remove('is-dragging');
        document.body.classList.remove('col-resizing');
        saveJson(KEYS.colWidths, state.colWidths);
        window.removeEventListener('mousemove', onMove);
        window.removeEventListener('mouseup', onUp);
      };
      window.addEventListener('mousemove', onMove);
      window.addEventListener('mouseup', onUp);
    });
    col.append(grip);
  }
}

const client = {
  onHar(request) {
    ingestHar(request);
  },
  onHarBatch(list) {
    for (const request of list) ingestHar(request);
  },
  onNavigated() {
    poller.reset();
    if (!state.preserveLog) clearLogs();
    if (state.realtime) poller.track(true);
    else poller.track(false);
  },
  onShown() {
    setPollInterval(POLL_MS);
    if (state.realtime) pollTick();
  },
  onHidden() {
    setPollInterval(HIDDEN_POLL_MS);
  },
};

applyTheme();
setupInfo(document.querySelector('.toolbar'));
initIcons();
setupIdentify();
bindClearButton($('filterInput'), $('filterClearBtn'));
makeClearable($('includeInput'));
makeClearable($('excludeInput'));
makeClearable($('presetNameInput'));
makeClearable($('detailSearchInput'));
$('modalFind').replaceWith(modalFinder.node);
syncControlsFromState();
updateSortHeaders();
applySplitLayout();
applyColumnWidths();
bindColumnResizers();
bindEvents();
if (state.realtime) startPolling();
else poller.track(false);

if (window.__3diDevtoolsHost) {
  window.__3diDevtoolsHost.attach(client);
} else {
  window.__3diOnHostReady = (host) => host.attach(client);
}
