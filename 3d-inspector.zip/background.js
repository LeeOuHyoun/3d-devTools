const CONNECTED_KEY = '3di.connectedTabs';
const INJECTED_KEY = '3di.injectedOpenTabs';
const PORT_PREFIX = '3di-devtools-';
const PAGE_MENU_ID = '3di-focus-devtools';
const PANEL_MENU_ID = '3di-find-tab';
const PAGE_MENU_TITLE = '개발자 도구에 포커스 (Alt+A)';
const PANEL_MENU_TITLE = '본 화면 찾기 (Alt+A)';

const ports = new Map();
const connectedTabs = new Set();
let menuChain = Promise.resolve();
let pageMenuVisible = false;

const ready = loadConnectedTabs();

async function loadConnectedTabs() {
  if (!chrome.storage?.session) return;
  try {
    const data = await chrome.storage.session.get(CONNECTED_KEY);
    const ids = data[CONNECTED_KEY];
    connectedTabs.clear();
    if (Array.isArray(ids)) ids.forEach((id) => connectedTabs.add(String(id)));
  } catch {}
}

async function saveConnectedTabs() {
  if (!chrome.storage?.session) return;
  try {
    await chrome.storage.session.set({ [CONNECTED_KEY]: [...connectedTabs] });
  } catch {}
}

async function isTabConnected(tabId) {
  if (tabId == null) return false;
  await ready;
  return connectedTabs.has(String(tabId));
}

function injectContentScript(tabId) {
  const id = Number(tabId);
  if (!Number.isFinite(id)) return;
  chrome.scripting?.executeScript?.({ target: { tabId: id, allFrames: true }, files: ['content.js'] }).catch(() => {});
}

async function injectOpenTabs() {
  if (!chrome.scripting?.executeScript || !chrome.tabs?.query) return;
  try {
    const data = await chrome.storage.session.get(INJECTED_KEY);
    if (data[INJECTED_KEY]) return;
    await chrome.storage.session.set({ [INJECTED_KEY]: true });
  } catch {}
  try {
    const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] });
    for (const tab of tabs) {
      if (tab?.id != null) injectContentScript(tab.id);
    }
  } catch {}
}

async function setTabConnected(tabId, active) {
  if (tabId == null) return;
  await ready;
  const id = String(tabId);
  const changed = active ? !connectedTabs.has(id) : connectedTabs.has(id);
  if (active) connectedTabs.add(id);
  else connectedTabs.delete(id);
  if (changed) await saveConnectedTabs();
  if (active && changed) injectContentScript(tabId);
  chrome.tabs.sendMessage(Number(tabId), { action: '3DI_SET_ACTIVE', active: Boolean(active) }).catch(() => {
    if (active) injectContentScript(tabId);
  });
  await syncPageMenuForCurrentTab();
}

function enqueueMenu(task) {
  const next = menuChain.then(task, task);
  menuChain = next.catch(() => {});
  return next;
}

async function upsertMenu(id, updateProps, createProps) {
  try {
    await chrome.contextMenus.update(id, updateProps);
    return;
  } catch {}
  try {
    await chrome.contextMenus.create({ id, ...createProps });
  } catch {
    await chrome.contextMenus.update(id, updateProps).catch(() => {});
  }
}

function syncPageMenu(visible) {
  if (visible !== undefined) pageMenuVisible = Boolean(visible);
  return enqueueMenu(() =>
    upsertMenu(
      PAGE_MENU_ID,
      { title: PAGE_MENU_TITLE, visible: pageMenuVisible },
      {
        title: PAGE_MENU_TITLE,
        contexts: ['page', 'frame', 'selection', 'link', 'editable', 'image', 'video', 'audio'],
        documentUrlPatterns: ['http://*/*', 'https://*/*'],
        visible: pageMenuVisible,
      },
    ),
  );
}

function syncPanelMenu() {
  const base = chrome.runtime.getURL('');
  return enqueueMenu(() =>
    upsertMenu(
      PANEL_MENU_ID,
      { title: PANEL_MENU_TITLE },
      {
        title: PANEL_MENU_TITLE,
        contexts: ['page', 'frame', 'selection', 'link', 'editable'],
        documentUrlPatterns: [`${base}*`],
      },
    ),
  );
}

async function syncPageMenuForCurrentTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    await syncPageMenu(await isTabConnected(tab?.id));
  } catch {
    await syncPageMenu(false);
  }
}

async function rebuildMenus() {
  await enqueueMenu(async () => {
    try {
      await chrome.contextMenus.removeAll();
    } catch {}
  });
  await syncPageMenuForCurrentTab();
  await syncPanelMenu();
}

async function focusWindowById(windowId) {
  const id = Number(windowId);
  if (!Number.isFinite(id) || !chrome.windows?.get) return;
  try {
    const win = await chrome.windows.get(id);
    const updateInfo = win.state === 'minimized' ? { focused: true, state: 'normal' } : { focused: true };
    await chrome.windows.update(id, updateInfo);
  } catch {}
}

async function identifyDevtools(tabId) {
  if (tabId == null) return false;
  const id = Number(tabId);
  if (!Number.isFinite(id)) return false;
  const payload = { action: 'IDENTIFY_DEVTOOLS', tabId: id };
  let delivered = false;
  const port = ports.get(String(id));
  if (port) {
    try {
      port.postMessage(payload);
      delivered = true;
    } catch {
      ports.delete(String(id));
    }
  }
  try {
    const res = await chrome.runtime.sendMessage(payload);
    if (res?.ok) delivered = true;
  } catch {}
  if (delivered) await setTabConnected(id, true);
  return delivered || (await isTabConnected(id));
}

async function focusTargetTab(tabId) {
  const id = Number(tabId);
  if (!Number.isFinite(id)) return { ok: false, overlaySent: false };
  await setTabConnected(id, true);
  try {
    const tab = await chrome.tabs.update(id, { active: true });
    if (tab?.windowId != null) await focusWindowById(tab.windowId);
    let overlaySent = false;
    try {
      await chrome.tabs.sendMessage(id, { action: 'SHOW_LOCATE_OVERLAY' }, { frameId: 0 });
      overlaySent = true;
    } catch {}
    return { ok: true, overlaySent };
  } catch {
    return { ok: false, overlaySent: false };
  }
}

chrome.runtime.onConnect.addListener((port) => {
  if (!port.name.startsWith(PORT_PREFIX)) return;
  const tabId = port.name.slice(PORT_PREFIX.length);
  ports.set(tabId, port);
  port.onMessage.addListener((msg) => {
    if (msg?.action === 'SET_DASHBOARD_ACTIVE') setTabConnected(tabId, msg.active);
  });
  port.onDisconnect.addListener(() => {
    if (ports.get(tabId) !== port) return;
    ports.delete(tabId);
    chrome.debugger?.detach({ tabId: Number(tabId) }).catch(() => {});
    setTabConnected(tabId, false);
  });
  setTabConnected(tabId, true);
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.action === 'GET_PAGE_ACTIVE') {
    isTabConnected(sender?.tab?.id).then((active) => sendResponse({ active }));
    return true;
  }
  if (msg?.action === 'REGISTER_DEVTOOLS_TAB') {
    setTabConnected(msg.tabId, true).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (msg?.action === 'FOCUS_DEVTOOLS_WINDOW') {
    focusWindowById(msg.windowId).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (msg?.action === 'IDENTIFY_DEVTOOLS') {
    identifyDevtools(msg.tabId ?? sender?.tab?.id).then((ok) => sendResponse({ ok }));
    return true;
  }
  if (msg?.action === 'FOCUS_TAB') {
    focusTargetTab(msg.tabId).then(sendResponse);
    return true;
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  ports.delete(String(tabId));
  setTabConnected(tabId, false);
});

chrome.tabs.onActivated.addListener(() => {
  syncPageMenuForCurrentTab();
});

chrome.windows.onFocusChanged.addListener((windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) syncPageMenu(false);
  else syncPageMenuForCurrentTab();
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === PAGE_MENU_ID) identifyDevtools(tab?.id);
  else if (info.menuItemId === PANEL_MENU_ID) chrome.runtime.sendMessage({ action: 'IDENTIFY_TAB' }).catch(() => {});
});

chrome.runtime.onInstalled.addListener(() => {
  rebuildMenus();
});
chrome.runtime.onStartup.addListener(() => {
  rebuildMenus();
});
syncPageMenuForCurrentTab();
syncPanelMenu();
injectOpenTabs();
